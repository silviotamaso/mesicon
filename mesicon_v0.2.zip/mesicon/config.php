<?php session_start();

$ok = 0;

error_reporting(0);
	if ($_SESSION['user']['status'] != "") {
		$ok = 1;
	}
error_reporting(1);

if ($ok = 1) {

	// connect to database
		
    
    
    
    
        ////////////////////////////////////////
        ////////////////////////////////////////
        ////////////////////////////////////////
        ////////////////////////////////////////
        ////////////////////////////////////////
        ////////////////////////////////////////
        ////////////////////////////////////////
        ////////////////////////////////////////
        
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    ///////////// CHANGE BELOW ACCORDING TO YOUR NEEDS !!!!!!!!!!!!!!!!
    
        // $conn = mysqli_connect("localhost","my_user","my_password","my_db");
		
    
    
    
    
    
    
    
    
    
    
    
    
    
        if (!$conn) {
			die("Error connecting to database: " . mysqli_connect_error());
		}
		
		//define ('ROOT_PATH', realpath(dirname(__FILE__))); // last one commented; it was breaking
		

	// echo "Initial character set is: " . $conn -> character_set_name() . "<br>";

	$conn -> set_charset("utf8"); // Change character set to utf8

	// echo "Current character set is: " . $conn -> character_set_name();

	// echo "<br>";
    // $conn -> close();

	//header('Content-Type: text/html; charset=UTF-8');
	//header('Content-Type: text/html; charset=ISO-8859-1');
	
}

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->
