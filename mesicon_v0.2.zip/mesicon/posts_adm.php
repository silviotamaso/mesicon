<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

// se não tiver ordenação definida, vai por data de cadastro
if (!$_GET['o']) $order = "created_at";
else $order = $_GET['o'];

// se não tiver sentido de ordenação, vai por ascendente
if (!$_GET['o2']) $asc_or_desc = "DESC";
else $asc_or_desc = $_GET['o2'];

$table = "1"; // corresponde a books, books_temp, manuscripts e manuscripts_temp

$posts = getAllBAM($table, $order, $asc_or_desc);

$contador = 1;
$contabela = 0;

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Posts ADM</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<!-- mt_rand(min,max), função php na linha abaixo, é 4 vezes mais rápida que a default "rand()". Ambas geram 10 caracteres e em "mt" se max < min dá pau.-->
<table width="100%"><tr><td align="center">
<h1>Postagens<?php if ($_SESSION['user']['role'] == "Administrator") echo " <a href=posts_adm.php>Usuários</a>"; ?><br></h1><h3><a href="control_panel.php">&lt;&lt; Volta Painel</a></h3></td>
<td align="center" valign="middle"><a href='create_book.php?i=0'><h1>+L</h1></a></td>
<td align="center" valign="middle"><a href='create_manuscript.php?i=0'><h1>+M</h1></a></td>
<td align="center">
<?php
echo "<font size='-1'>";
echo "<a href='posts_adm.php?o=created_at&o2=DESC'>data</a><br>";
echo "<a href='posts_adm.php?o=author&o2=ASC'>autoria</a><br>";
echo "<a href='posts_adm.php?o=title&o2=ASC'>título</a><br>";
echo "</font>";
?>
</td>
</tr></table> <!-- tabela superior: título, links de ordenamento -->

<?php include('incl_messages.php') ?>

<?php if (empty($posts)): 
// esta condição aqui só vai existir se o banco estiver completamente vazio - pay attention vacilão
else: ?>



<br><table border="1" cellspacing="0" cellpadding="0" bordercolor="#cccccc" align="center" width="100%">

<tr>
<td align="center">&nbsp;</td>
<td align="center"><font size="-1">id</font></td>
<td align="center"><font size="-1">creator</font></td>
<td align="center"><font size="-1">title</font></td>
<td align="center"><font size="-1">author</font></td>
<td align="center"><font size="-1">publish</font></td>
<td align="center"><font size="-1">del</font></td>
<td align="center"><font size="-1">edit</font></td>
</tr> <!-- cabeçalho da tabela -->





    
    
    
<!-- abaixo:
- foreach roda número de vezes igual à qtde de tabelas, atualmente 2, indicadas por $key;
- count($posts) retorna o número de tabelas também;
- count($post) retorna o número de itens dentro de cada tabela, em cada foreach;
- $key: nome da tabela em questão
-->
<?php foreach ($posts as $key => $post): ?>

    
    
    <?php
    ///////////// ABRE DEBUG ////////////////////// - funcionando perfecto: reproduz em escala menor o que deve rodar abaixo
    //if ($key == "02_mesicon_books") $contabela = 0; // leu todas as linhas da primeira tabela, quando entrar na segunda zera o contador
    //echo "<br>tabela: " . $key . "<br>";
    //while ($contabela < count($post)) {
        //echo "contabela: " . $contabela . "<br>"; // está indo de 0 a 1, afinal são 2 tabelas
        //echo "post[$contabela]['author']: " . $post[$contabela]['author'] . "<br>";
        //$contabela++;
    //}
    ///////////// FECHA DEBUG //////////////////////////////////////////////////////////////
    ?>
    
    
    
    <?php
    if ($key == "02_mesicon_books_temp") $tabela = 0;

    if ($key == "02_mesicon_books") {
        $contabela = 0; // leu todas as linhas da primeira tabela, quando entrar na segunda zera o contador
        $tabela = 1;
    }

    if ($key == "02_mesicon_manuscripts_temp") {
        $contabela = 0; // leu todas as linhas da segunda tabela, quando entrar na terceira zera o contador
        $tabela = 2;
    }

    if ($key == "02_mesicon_manuscripts") {
        $contabela = 0; // leu todas as linhas da terceira tabela, quando entrar na quarta zera o contador
        $tabela = 3;
    }
    
    while ($contabela < count($post)) {
    ?>

        <!-- linha abaixo significa: mostrar registros se u usuário é o criador dos posts e o post está com published != 4 OOOOUUUUU é o admin e published = (0 ou 1 ou 3 ou 4) -->
        <?php if (($_SESSION['user']['role'] == "Administrator") && ($post[$contabela]['published'] == 0 || $post[$contabela]['published'] == 1 || $post[$contabela]['published'] == 3 || $post[$contabela]['published'] == 4)) : ?>
        <tr style="height: 50px;">

            <td align=center><font size="-2">
            <?php
            if ($tabela == 0 || $tabela == 1) echo "L"; // print L for BOOKS
            if ($tabela == 2 || $tabela == 3) echo "M"; // print M for MANUSCRIPTS
            ?>
            </font></td>

            <!-- id post -->
            <td align=center><font size="-2"><?= $post[$contabela]['id'] ?></font></td>

            <!-- creator (mesicon poster) -->
            <td align="center"><font size="-1">
                <?= "<a href='user.php?id=" . $post[$contabela]['creator_id'] . "&v=p'>" . $post[$contabela]['creator'] . "</a>" ?>
            </font></td>

            <!-- title of the book/document -->
            <td><font size="-1"><a href=# onclick="javascript:alert('MESICON\n\nPostado em: <?= $post[$contabela]['created_at'] ?>');">
                <?php
                // echo $post[$contabela]['title'];
                if (strlen($post[$contabela]['title']) > 13) {
                    echo substr($post[$contabela]['title'],0,13) . "...";
                    if ($post[$contabela]['ed_number'] != 0) echo "<sup>" . $post[$contabela]['ed_number'] . "<font size='-2'>ed</font></sup>";
                }
                else if (strlen($post[$contabela]['title']) < 2 || $post[$contabela]['title'] == "") echo "-";
                else echo $post[$contabela]['title'];
                ?>
            </a></font></td>

            <!-- author/creator posted ("t" at the link points to which table the register is) -->
            <td><font size="-1"><a href="<?= 'post.php?id=' . $post[$contabela]['id'] . '&t=' . $tabela ?>">
                <?php
                if (strlen($post[$contabela]['author']) > 16) echo substr($post[$contabela]['author'],0,15) . "...";
                else echo $post[$contabela]['author'];
                //echo $post[$contabela]['author'];
                ?>
            </a></font></td>

            <!-- publish or not -->
            <td align="center"><font size="-1">
            <?php if ($post[$contabela]['published'] == "1") : ?>
                <a href="posts_adm.php?unpublish=<?= $post[$contabela]['id'] ?>&t=<?= $tabela ?>">unpub</a>
            <?php else: ?>
                <a href="posts_adm.php?publish=<?= $post[$contabela]['id'] ?>&t=<?= $tabela ?>&c=<?= $post[$contabela]['creator_id'] ?>&a=<?= myUrlEncode($post[$contabela]['author']) ?>">
                    <?php 
                    if ($post[$contabela]['published'] == "0") echo "pub<sup>s</sup>";
                    else if ($post[$contabela]['published'] == "4") echo "</a>wait";
                    else echo "pub";
                    ?>
                </a>
            <?php endif ?>
            </font></td>
            
            <!-- del -->
            <td align="center">
                <script> function vai(i) {return confirm('Excluir - ' + i + ' - ?');} </script>
                <a href="posts_adm.php?delete_post=<?= $post[$contabela]['id'] ?>&t=<?= $tabela ?>&go2=posts_adm" onclick="return vai('<?= $post[$contabela]['title'] ?>');"><font size='-1'>del</font></a>
            </td>
            
            <!-- edit -->
            <td align="center">
                <!-- <a href="edit_book.php?i=<?= $post[$contabela]['id'] ?>&t=<?= $tabela ?>">edit</a> OLD -->
                <?php
                if ($tabela == 0 || $tabela == 1) echo "<a href='edit_book.php?i=" . $post[$contabela]['id'] . "&t=" . $tabela . "'><font size='-1'>edit</font></a>";
                if ($tabela == 2 || $tabela == 3) echo "<a href='edit_manuscript.php?i=" . $post[$contabela]['id'] . "&t=" . $tabela . "'><font size='-1'>edit</font></a>";
                ?>
            </td>

        </tr> <!-- closes main content -->
        <?php endif ?>    

    <?php
        //echo "post[$contabela]['author']: " . $post[$contabela]['author'] . "<br>";
        $contabela++;
    }
    ?>





    
    
<?php endforeach ?>











</table> <!-- tabela princial, é onde está o principal da pg -->












<?php
    endif;
?> <!-- controla se exibe conteúdo total ou não a depender das postagens, se não há nenhuma, exibe nada, se há de uma para mais, exibe tudo -->

<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>


