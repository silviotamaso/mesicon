<?php
include('config.php'); // start session, open conn, set charset
// include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');
?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Comments / Comentários</title>
<script>
function reject() { return confirm('MESICON\n\nConfirma rejeitar?\n\nReject, confirm?'); }
function approve() {
    <?php 
    //$_SESSION['message'] = "Comentário aprovado 2";
    ?>
    return confirm('MESICON\n\nConfirma aprovar?\n\nApprove, confirm?');
}
</script>

<?php include('incl_navbar.php'); ?> <!-- close head, open body, open pagediv -->

    <h1><?= txt('comentarios') ?></h1><h3><a href="control_panel.php">&lt;&lt; <?= txt('voltar') ?> <?= txt('paineldecontrole') ?></a></h3>
	
	<?php
    include('incl_messages.php');
	?>

    <h3><br>
    <?php

        if ($_SESSION['user']['role'] == "Administrator" || $_SESSION['user']['role'] == "Manager") {
        if ($_SESSION['user']['status'] == "Authorized") {
            
            // echo "Feitos Por e Para Mim (em construção)"; // TODO: message GOD MODE

            //global $conn;
            //$sql = "SELECT * FROM 02_mesicon_comments_temp WHERE creator_id=" . $_SESSION['user']['id'] . " ORDER BY created_at";

            //if ($table == 0) $table = "02_mesicon_books_temp";
            //if ($table == 1) $table = "02_mesicon_books";
            //$sql = "SELECT author, title FROM " . $table . " WHERE id = " . $field['id_post'];
            //$originalpost = mysqli_fetch_assoc(mysqli_query($conn, $sql));
    
            if ($_SESSION['user']['role'] == "Administrator") $comments = getComments("todos", "todos"); // GOD ve todos os comments
            else $comments = getComments($_SESSION['user']['id'], 1); // user sees only the ones who belongs to him and are pending
            //echo $comments;
            $count = 0;
            $table = 1;

            foreach ($comments as $key => $comment) {
        
                        if ($table == 1) $table = "02_mesicon_books";
                        $sql = "SELECT author, title FROM " . $table . " WHERE id = " . $comment['id_post'];
                        $io = mysqli_fetch_assoc(mysqli_query($conn, $sql));

                echo "<br><br>(" . txt('comentario') . " " . $count+1 . ")";
                if ($_SESSION['user']['role'] == "Administrator") echo " id: " . $comment['id'];
                echo "<br>" . txt('quemcomentou') . "? <a href='user.php?id=" . $comment['id_commenter'] . "&v=p' target='_blank'>" . $comment['username_commenter'] . "</a><br>";
                echo txt('quando') . "? " . $comment['created_at'] . "<br>";
                echo txt('onde') . "?<br><a href='post.php?id=" . $comment['id_post'] . "&t=1' target='_blank'>" . $io['author']. ". <i>" . $io['title'] . "</i>.</a><br>";
                echo txt('conteudo') . ": </h3><h2>";
                if (($comment['status'] == 1) && ($_SESSION['user']['role'] == "Administrator")) echo "<font color='#999999'>";
                else echo "<font color='#990000'>";
                echo $comment['txt'] . "</font></h2><h3>";
                
                if ($_SESSION['user']['role'] == "Administrator") {
                    if ($comment['status'] == 1) {
                        echo "É meu: <a href='comments.php?approve_comments=" . $comment['id'] . "&t=2' onclick='return approve();'>" .  txt('aprovar_M') . "</a> ----- <a href='comments.php?delete_post=" . $comment['id'] . "&t=4&go2=comments' onclick='return reject();'>" . txt('rejeitar_M') . "</a><br>";
                        echo "<font size='-1'>Aguardar, se demorar, <a href='comments.php?delete_post=" . $comment['id'] . "&t=4&go2=comments' onclick='return reject();'>del</a></font>";
                    }
                    if ($comment['status'] == 2) echo "<br><a href='comments.php?approve_comments=" . $comment['id'] . "&t=2' onclick='return approve();'>" .  txt('aprovar_M') . "</a> ----- <a href='comments.php?delete_post=" . $comment['id'] . "&t=4&go2=comments' onclick='return reject();'>" . txt('rejeitar_M') . "</a><br><br><br>";
                }
                if ($_SESSION['user']['role'] == "Manager") {
                    echo "<br><a href='comments.php?approve_comments=" . $comment['id'] . "&t=1' onclick='return approve();'>" .  txt('aprovar_M') . "</a> ----- <a href='comments.php?delete_post=" . $comment['id'] . "&t=4&go2=comments' onclick='return reject();'>" .  txt('rejeitar_M') . "</a><br><br><br>";
                }
                $count++;
        
            }
            
            if ($count == 0) echo txt('semcomentarios') . ".<br>";
            
        
        } else echo txt('proibido') . ".";
    } else echo txt('proibido') . ".";

    ?>
    </h3>
	
<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>

