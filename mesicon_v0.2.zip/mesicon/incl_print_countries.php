<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<?php if ($id != 0):
if ($country == "0") echo "<option value='0' selected>Country/País?</option>";
if ($country == "Brasil") echo "<option value='Brasil' selected>Brasil</option>";
if ($country == "Afganistan") echo "<option value='Afganistan' selected>Afghanistan</option>";
if ($country == "Albania") echo "<option value='Albania' selected>Albania</option>";
if ($country == "Algeria") echo "<option value='Algeria' selected>Algeria</option>";
if ($country == "Angola") echo "<option value='Angola' selected>Angola</option>";
if ($country == "Argentina") echo "<option value='Argentina' selected>Argentina</option>";
if ($country == "Armenia") echo "<option value='Armenia' selected>Armenia</option>";
if ($country == "Aruba") echo "<option value='Aruba' selected>Aruba</option>";
if ($country == "Australia") echo "<option value='Australia' selected>Australia</option>";
if ($country == "Austria") echo "<option value='Austria' selected>Austria</option>";
if ($country == "Azerbaijan") echo "<option value='Azerbaijan' selected>Azerbaijan</option>";
if ($country == "Bahamas") echo "<option value='Bahamas' selected>Bahamas</option>";
if ($country == "Bahrain") echo "<option value='Bahrain' selected>Bahrain</option>";
if ($country == "Barbados") echo "<option value='Barbados' selected>Barbados</option>";
if ($country == "Belarus") echo "<option value='Belarus' selected>Belarus</option>";
if ($country == "Belgium") echo "<option value='Belgium' selected>Belgium</option>";
if ($country == "Bolivia") echo "<option value='Bolivia' selected>Bolivia</option>";
if ($country == "Bosnia & Herzegovina") echo "<option value='Bosnia & Herzegovina' selected>Bosnia & Herzegovina</option>";
if ($country == "Brasil") echo "<option value='Brasil' selected>Brasil</option>";
if ($country == "Bulgaria") echo "<option value='Bulgaria' selected>Bulgaria</option>";
if ($country == "Cambodia") echo "<option value='Cambodia' selected>Cambodia</option>";
if ($country == "Cameroon") echo "<option value='Cameroon' selected>Cameroon</option>";
if ($country == "Canada") echo "<option value='Canada' selected>Canada</option>";
if ($country == "Cape Verde") echo "<option value='Cape Verde' selected>Cape Verde</option>";
if ($country == "Chile") echo "<option value='Chile' selected>Chile</option>";
if ($country == "China") echo "<option value='China' selected>China</option>";
if ($country == "Colombia") echo "<option value='Colombia' selected>Colombia</option>";
if ($country == "Congo") echo "<option value='Congo' selected>Congo</option>";
if ($country == "Costa Rica") echo "<option value='Costa Rica' selected>Costa Rica</option>";
if ($country == "Cote DIvoire") echo "<option value='Cote DIvoire' selected>Cote DIvoire</option>";
if ($country == "Croatia") echo "<option value='Croatia' selected>Croatia</option>";
if ($country == "Cuba") echo "<option value='Cuba' selected>Cuba</option>";
if ($country == "Cyprus") echo "<option value='Cyprus' selected>Cyprus</option>";
if ($country == "Czech Republic") echo "<option value='Czech Republic' selected>Czech Republic</option>";
if ($country == "Denmark") echo "<option value='Denmark' selected>Denmark</option>";
if ($country == "East Timor") echo "<option value='East Timor' selected>East Timor</option>";
if ($country == "Ecuador") echo "<option value='Ecuador' selected>Ecuador</option>";
if ($country == "Egypt") echo "<option value='Egypt' selected>Egypt</option>";
if ($country == "El Salvador") echo "<option value='El Salvador' selected>El Salvador</option>";
if ($country == "Estonia") echo "<option value='Estonia' selected>Estonia</option>";
if ($country == "Finland") echo "<option value='Finland' selected>Finland</option>";
if ($country == "France") echo "<option value='France' selected>France</option>";
if ($country == "French Guiana") echo "<option value='French Guiana' selected>French Guiana</option>";
if ($country == "Germany") echo "<option value='Germany' selected>Germany</option>";
if ($country == "Great Britain") echo "<option value='Great Britain' selected>Great Britain</option>";
if ($country == "Greece") echo "<option value='Greece' selected>Greece</option>";
if ($country == "Grenada") echo "<option value='Grenada' selected>Grenada</option>";
if ($country == "Guatemala") echo "<option value='Guatemala' selected>Guatemala</option>";
if ($country == "Guinea") echo "<option value='Guinea' selected>Guinea</option>";
if ($country == "Guyana") echo "<option value='Guyana' selected>Guyana</option>";
if ($country == "Haiti") echo "<option value='Haiti' selected>Haiti</option>";
if ($country == "Hawaii") echo "<option value='Hawaii' selected>Hawaii</option>";
if ($country == "Honduras") echo "<option value='Honduras' selected>Honduras</option>";
if ($country == "Hong Kong") echo "<option value='Hong Kong' selected>Hong Kong</option>";
if ($country == "Hungary") echo "<option value='Hungary' selected>Hungary</option>";
if ($country == "Iceland") echo "<option value='Iceland' selected>Iceland</option>";
if ($country == "Indonesia") echo "<option value='Indonesia' selected>Indonesia</option>";
if ($country == "India") echo "<option value='India' selected>India</option>";
if ($country == "Iran") echo "<option value='Iran' selected>Iran</option>";
if ($country == "Iraq") echo "<option value='Iraq' selected>Iraq</option>";
if ($country == "Ireland") echo "<option value='Ireland' selected>Ireland</option>";
if ($country == "Israel") echo "<option value='Israel' selected>Israel</option>";
if ($country == "Italy") echo "<option value='Italy' selected>Italy</option>";
if ($country == "Jamaica") echo "<option value='Jamaica' selected>Jamaica</option>";
if ($country == "Japan") echo "<option value='Japan' selected>Japan</option>";
if ($country == "Kazakhstan") echo "<option value='Kazakhstan' selected>Kazakhstan</option>";
if ($country == "Korea South") echo "<option value='Korea South' selected>Korea South</option>";
if ($country == "Latvia") echo "<option value='Latvia' selected>Latvia</option>";
if ($country == "Lebanon") echo "<option value='Lebanon' selected>Lebanon</option>";
if ($country == "Libya") echo "<option value='Libya' selected>Libya</option>";
if ($country == "Liechtenstein") echo "<option value='Liechtenstein' selected>Liechtenstein</option>";
if ($country == "Lithuania") echo "<option value='Lithuania' selected>Lithuania</option>";
if ($country == "Luxembourg") echo "<option value='Luxembourg' selected>Luxembourg</option>";
if ($country == "Macau") echo "<option value='Macau' selected>Macau</option>";
if ($country == "Macedonia") echo "<option value='Macedonia' selected>Macedonia</option>";
if ($country == "Malaysia") echo "<option value='Malaysia' selected>Malaysia</option>";
if ($country == "Maldives") echo "<option value='Maldives' selected>Maldives</option>";
if ($country == "Mali") echo "<option value='Mali' selected>Mali</option>";
if ($country == "Malta") echo "<option value='Malta' selected>Malta</option>";
if ($country == "Martinique") echo "<option value='Martinique' selected>Martinique</option>";
if ($country == "Mexico") echo "<option value='Mexico' selected>Mexico</option>";
if ($country == "Moldova") echo "<option value='Moldova' selected>Moldova</option>";
if ($country == "Monaco") echo "<option value='Monaco' selected>Monaco</option>";
if ($country == "Mongolia") echo "<option value='Mongolia' selected>Mongolia</option>";
if ($country == "Morocco") echo "<option value='Morocco' selected>Morocco</option>";
if ($country == "Mozambique") echo "<option value='Mozambique' selected>Mozambique</option>";
if ($country == "Nepal") echo "<option value='Nepal' selected>Nepal</option>";
if ($country == "Netherlands") echo "<option value='Netherlands' selected>Netherlands (Holland)</option>";
if ($country == "New Zealand") echo "<option value='New Zealand' selected>New Zealand</option>";
if ($country == "Nigeria") echo "<option value='Nigeria' selected>Nigeria</option>";
if ($country == "Norway") echo "<option value='Norway' selected>Norway</option>";
if ($country == "Pakistan") echo "<option value='Pakistan' selected>Pakistan</option>";
if ($country == "Panama") echo "<option value='Panama' selected>Panama</option>";
if ($country == "Paraguay") echo "<option value='Paraguay' selected>Paraguay</option>";
if ($country == "Peru") echo "<option value='Peru' selected>Peru</option>";
if ($country == "Phillipines") echo "<option value='Phillipines' selected>Philippines</option>";
if ($country == "Poland") echo "<option value='Poland' selected>Poland</option>";
if ($country == "Portugal") echo "<option value='Portugal' selected>Portugal</option>";
if ($country == "Puerto Rico") echo "<option value='Puerto Rico' selected>Puerto Rico</option>";
if ($country == "Qatar") echo "<option value='Qatar' selected>Qatar</option>";
if ($country == "Republic of Montenegro") echo "<option value='Republic of Montenegro' selected>Republic of Montenegro</option>";
if ($country == "Republic of Serbia") echo "<option value='Republic of Serbia' selected>Republic of Serbia</option>";
if ($country == "Romania") echo "<option value='Romania' selected>Romania</option>";
if ($country == "Russia") echo "<option value='Russia' selected>Russia</option>";
if ($country == "Sao Tome & Principe") echo "<option value='Sao Tome & Principe' selected>Sao Tome & Principe</option>";
if ($country == "Saudi Arabia") echo "<option value='Saudi Arabia' selected>Saudi Arabia</option>";
if ($country == "Senegal") echo "<option value='Senegal' selected>Senegal</option>";
if ($country == "Singapore") echo "<option value='Singapore' selected>Singapore</option>";
if ($country == "Slovakia") echo "<option value='Slovakia' selected>Slovakia</option>";
if ($country == "Slovenia") echo "<option value='Slovenia' selected>Slovenia</option>";
if ($country == "South Africa") echo "<option value='South Africa' selected>South Africa</option>";
if ($country == "Spain") echo "<option value='Spain' selected>Spain</option>";
if ($country == "Sudan") echo "<option value='Sudan' selected>Sudan</option>";
if ($country == "Sweden") echo "<option value='Sweden' selected>Sweden</option>";
if ($country == "Switzerland") echo "<option value='Switzerland' selected>Switzerland</option>";
if ($country == "Syria") echo "<option value='Syria' selected>Syria</option>";
if ($country == "Taiwan") echo "<option value='Taiwan' selected>Taiwan</option>";
if ($country == "Thailand") echo "<option value='Thailand' selected>Thailand</option>";
if ($country == "Tunisia") echo "<option value='Tunisia' selected>Tunisia</option>";
if ($country == "Turkey") echo "<option value='Turkey' selected>Turkey</option>";
if ($country == "Uganda") echo "<option value='Uganda' selected>Uganda</option>";
if ($country == "United Kingdom") echo "<option value='United Kingdom' selected>United Kingdom</option>";
if ($country == "Ukraine") echo "<option value='Ukraine' selected>Ukraine</option>";
if ($country == "United Arab Erimates") echo "<option value='United Arab Erimates' selected>United Arab Emirates</option>";
if ($country == "United States of America") echo "<option value='United States of America' selected>United States of America</option>";
if ($country == "Uruguay") echo "<option value='Uruguay' selected>Uruguay</option>";
if ($country == "Vatican City State") echo "<option value='Vatican City State' selected>Vatican City State</option>";
if ($country == "Venezuela") echo "<option value='Venezuela' selected>Venezuela</option>";
if ($country == "Vietnam") echo "<option value='Vietnam' selected>Vietnam</option>";
if ($country == "Zimbabwe") echo "<option value='Zimbabwe' selected>Zimbabwe</option>";
endif ?>

<option value="0">Country/País?</option>
<option value="Brasil">Brasil</option>
<option value="Afganistan">Afghanistan</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="Angola">Angola</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
<option value="Brasil">Brasil</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Cape Verde">Cape Verde</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Colombia">Colombia</option>
<option value="Congo">Congo</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Cote DIvoire">Cote DIvoire</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<option value="Denmark">Denmark</option>
<option value="East Timor">East Timor</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Estonia">Estonia</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="French Guiana">French Guiana</option>
<option value="Germany">Germany</option>
<option value="Great Britain">Great Britain</option>
<option value="Greece">Greece</option>
<option value="Grenada">Grenada</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Hawaii">Hawaii</option>
<option value="Honduras">Honduras</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="Indonesia">Indonesia</option>
<option value="India">India</option>
<option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
<option value="Ireland">Ireland</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Korea South">Korea South</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Libya">Libya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Macau">Macau</option>
<option value="Macedonia">Macedonia</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Martinique">Martinique</option>
<option value="Mexico">Mexico</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands (Holland)</option>
<option value="New Zealand">New Zealand</option>
<option value="Nigeria">Nigeria</option>
<option value="Norway">Norway</option>
<option value="Pakistan">Pakistan</option>
<option value="Panama">Panama</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Phillipines">Philippines</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Qatar">Qatar</option>
<option value="Republic of Montenegro">Republic of Montenegro</option>
<option value="Republic of Serbia">Republic of Serbia</option>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Sao Tome & Principe">Sao Tome & Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="South Africa">South Africa</option>
<option value="Spain">Spain</option>
<option value="Sudan">Sudan</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Taiwan">Taiwan</option>
<option value="Thailand">Thailand</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Uganda">Uganda</option>
<option value="United Kingdom">United Kingdom</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Erimates">United Arab Emirates</option>
<option value="United States of America">United States of America</option>
<option value="Uruguay">Uruguay</option>
<option value="Vatican City State">Vatican City State</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Zimbabwe">Zimbabwe</option>