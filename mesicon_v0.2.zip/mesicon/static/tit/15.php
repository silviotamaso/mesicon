ooo        ooooo oooooooooooo  .oooooo..o ooooo   .oooooo.     .oooooo.   ooooo      ooo 
`88.       .888' `888'     `8 d8P'    `Y8 `888'  d8P'  `Y8b   d8P'  `Y8b  `888b.     `8' 
 888b     d'888   888         Y88bo.       888  888          888      888  8 `88b.    8  
 8 Y88. .P  888   888oooo8     `"Y8888o.   888  888          888      888  8   `88b.  8  
 8  `888'   888   888    "         `"Y88b  888  888          888      888  8     `88b.8  
 8    Y     888   888       o oo     .d8P  888  `88b    ooo  `88b    d88'  8       `888  
o8o        o888o o888ooooood8 8""88888P'  o888o  `Y8bood8P'   `Y8bood8P'  o8o        `8