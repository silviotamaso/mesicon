 .S_SsS_S.     sSSs    sSSs   .S    sSSs    sSSs_sSSs     .S_sSSs    
.SS~S*S~SS.   d%%SP   d%%SP  .SS   d%%SP   d%%SP~YS%%b   .SS~YS%%b   
S%S `Y' S%S  d%S'    d%S'    S%S  d%S'    d%S'     `S%b  S%S   `S%b  
S%S     S%S  S%S     S%|     S%S  S%S     S%S       S%S  S%S    S%S  
S%S     S%S  S&S     S&S     S&S  S&S     S&S       S&S  S%S    S&S  
S&S     S&S  S&S_Ss  Y&Ss    S&S  S&S     S&S       S&S  S&S    S&S  
S&S     S&S  S&S~SP  `S&&S   S&S  S&S     S&S       S&S  S&S    S&S  
S&S     S&S  S&S       `S*S  S&S  S&S     S&S       S&S  S&S    S&S  
S*S     S*S  S*b        l*S  S*S  S*b     S*b       d*S  S*S    S*S  
S*S     S*S  S*S.      .S*P  S*S  S*S.    S*S.     .S*S  S*S    S*S  
S*S     S*S   SSSbs  sSS*S   S*S   SSSbs   SSSbs_sdSSS   S*S    S*S  
SSS     S*S    YSSP  YSS'    S*S    YSSP    YSSP~YSSY    S*S    SSS  
        SP                   SP                          SP          
        Y                    Y                           Y