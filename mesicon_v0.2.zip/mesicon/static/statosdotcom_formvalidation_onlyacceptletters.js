function allLetter(inputtxt) { 
	var letters = /^[A-Za-z]+$/;
	if(inputtxt.value.match(letters)) {
		//alert('Your name have accepted : you can try another');
		return true;
		} else {
		alert('MESICON\n\nUse apenas letras no nome.');
		return false;
	}
}