<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

$id = $_GET['i']; // id to find
$table = $_GET['t']; // table where he is

$posts = getBAM($id, $table);

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON | Edit or Register Book/Editar ou Cadastrar Livro</title>

<!-- TODO: form validation -->

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<h1><?php
if ($id == 0) {
    echo txt('cadastrar') . " " . txt('livro');
    echo "<h3><a href='control_panel.php'>&lt;&lt; " . txt('voltar') . " " . txt('paineldecontrole') . "</a></h3>";
} else {
    echo txt('editar') . " " . txt('livro');
    echo "<h3><a href='posts.php'>&lt;&lt; " . txt('voltar') . " " . txt('postagens') . "</a></h3>";
}
?></h1> <!-- main title -->

<script>
var _formConfirm_submitted = false; // with 'onsubmit' help prevent multi post actions
// TODO: validate author and title !!!!!!!!!!!!!!!!!
function statosdotcom_Count(obj,max) { if ((max-10) < obj.value.length) { document.getElementById("l"+obj.name).innerHTML = '<span style="color: red;">'+(max-obj.value.length)+'</span>'; } else { document.getElementById("l"+obj.name).innerHTML = (max-obj.value.length); }}
</script>

<style>
.ct { position: absolute; }
</style>

<?php foreach ($posts as $post): ?> <!-- MUST come before 'form' because it is used in the begining -->

    <?php if (($_SESSION['user']['role'] == 'Manager') && ($post['published'] == 2)) { ?>
        <br><br><h3 style='color: #990000'><?= txt('esteregistroaindanao') ?>.<br><a href="posts.php?delete_post=<?= $post['id'] ?>&t=0&go2=posts"><?= txt('desejaexcluir') ?>?</a>
        </h3><br><br>
    <?php } ?>

    <?php if ((($_SESSION['user']['role'] == 'Manager') && ($post['published'] == 0)) || (($_SESSION['user']['role'] == 'Manager') && ($post['published'] == 3))) { ?>
        <br><h3 style='color: #990000'><?= txt('indisponivel') ?>.</h3>
    <?php } else { ?>

        <?php if (($_SESSION['user']['role'] == "Administrator") || ($_SESSION['user']['role'] == "Manager")) { ?>
            <form id='statosdotcomForm' method='post' action="review_book.php?c=<?= $post['updated_at'] ?>" onsubmit="if (_formConfirm_submitted == false) { _formConfirm_submitted = true; return true; } else { alert('MESICON\n\nAguarde/Wait...'); return false; }">
        <?php } ?>

        <input type='hidden' name='updated_at' value='<?= $post['updated_at'] ?>'> <!-- very important field because it helps to control revisions -->
        <input type='hidden' name='tabela' value='<?= $table ?>'>

        <h4>
        <!-- validation errors for the form -->
        <?php include('incl_errors.php') ?>

            <?php include('edit_book_miolo.php') ?> <!------- CONTENTS ----------------------------------->

        <?php if ($_SESSION['user']['role'] == "Manager") { ?>
            <button type=submit class=btn name='update_reviewing_book' id=idBtnSend><?= txt('revisar_M') ?></button>update_reviewing_book
            </form>
        <?php } ?>

        <?php if ($_SESSION['user']['role'] == "Administrator") { ?>
            <button type="submit" class="btn" name="admin_update_book" id="idBtnSend"><?= txt('gravar_M') ?></button>
            </form>
        <?php } ?>

    <?php } ?>
            
<?php endforeach; ?>

<script>
var objForm = document.getElementById('statosdotcomForm');
objForm.addEventListener('submit', function (e) {
    var objBtn = document.getElementById('idBtnSend');
    objBtn.style = 'color: #000000; background: #00ff00; cursor: not-allowed;';
    objBtn.textContent = 'Aguarde/Wait...';
    //objBtn.disabled = 'disabled'; // can't disable the button because without it the associated command don't go by POST (and this is needed). Going by GET can't make to work at the end.
});
</script>

<?php
include('incl_footer.php'); // close div id='pagediv', body, html and add JSs
?>
