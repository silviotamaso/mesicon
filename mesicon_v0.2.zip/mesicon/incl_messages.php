<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<?php
/*
if (isset($_SESSION['message'])) :
	<div class=message><p>
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
	</p></div>
endif
*/

if ($_SESSION['message'] != "") {
    
    if (getLastWord($_SESSION['message']) == "1") echo "<div class=message1>"; // yellow
    if (getLastWord($_SESSION['message']) == "2") echo "<div class=message2>"; // green
    if (getLastWord($_SESSION['message']) == "3") echo "<div class=message3>"; // red
    
	echo substr($_SESSION['message'], 0, strlen($_SESSION['message'])-1) . "</div>";
	
    unset($_SESSION['message']);
}
?>