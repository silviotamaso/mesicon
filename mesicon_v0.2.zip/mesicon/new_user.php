<?php
// header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html><head>
<?php
include('config.php');
include('incl_registration_login.php');
include('incl_errors.php');
if (isset($_POST['avalia-btn'])) {
	//echo "entrou";
	$email = $_POST['email'];
	$id2change = $_POST['i'];
	$emailnovousuario = $_POST['emailnovousuario'];
	$password = $_POST['encpass'];
	if (empty($email)) { array_push($errors, "Email do ADM requerido"); }
	if (empty($password)) { array_push($errors, "Senha do ADM requerida"); }
	if (empty($errors)) {
		//echo "2";
		$sql = "SELECT * FROM 02_mesicon_users WHERE email='$email' and password='$password' LIMIT 1";
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result) > 0) {
			//echo "3";
			$reg_user_id = mysqli_fetch_assoc($result)['id']; 
			// $_SESSION['user'] = getUserById($reg_user_id); 
			$_SESSION['user']['id'] = getUserById($reg_user_id); 
			if ($_SESSION['user']['role'] == "Administrator") { // achou adm viu que é adm, segue
				//echo "4";
				header('location: new_user_admin.php?e=' . $emailnovousuario . '&i=' . $id2change);
				exit(0);
			}
		}
	}
}
?>
<script>
<!--
window.addEventListener('load', 
function() {document.statosdotcomForm.email.focus();}, false);
function vai(el,m) {alert(m);el.focus();}
function x(f){
	if (f.email.value=="") {vai(f.email,"MESICON\n\nDigite seu email.");return false;}
	else if (f.email.value.indexOf("@")==-1 || f.email.value.indexOf(".")==-1 || f.email.value.indexOf(" ")==1 || f.email.value.indexOf("/")==1 || f.email.value.indexOf("@.")==1 || f.email.value.indexOf(".@")==1) {vai(f.email,"MESICON\n\nEmail inválido.");return false;}
	else if (f.password.value=="") {vai(f.password,"MESICON\n\nDigite sua senha.");return false;}
	else {f.encpass.value = sha3_224(f.password.value);return true;}}
//-->
</script>
<script src="static/sha3-min.js"></script>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Novo Usuário</title></head><body><center>
<form name="statosdotcomForm" method="post" action="new_user.php" onSubmit="return x(this);">
<input type="text" name="email" placeholder="Email"><br><input type="password" name="password" placeholder="Senha" maxlength="8"><br>
<input type="hidden" name="emailnovousuario" value="<?= $_GET['e'] ?>"><input type="hidden" name="i" value="<?= $_GET['i'] ?>"><input type="hidden" name="encpass">
<button type="submit" name="avalia-btn">ENTRAR</button><br></form></center></body></html>