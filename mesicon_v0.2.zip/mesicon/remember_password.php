<?php
include('config.php');
include('incl_debug.php');

echo var_dump($_POST); // show all posted elements

if ($_SERVER['REQUEST_METHOD']=='POST') {

	$email = $_POST['email2'];
	$statos = $_POST['statos']; 

	$achou = 0;
	// mt_rand(min,max), função php na linha abaixo, é 4 vezes mais rápida que a default "rand()". Ambas geram 10 caracteres e em "mt" se max < min dá pau.
	$temp = mt_rand(0000000000,9999999999);
	$sql = "";
	$id = "";

	if ($statos == "1") {

/*
		$link = mysqli_connect("localhost", "statos_user2", "501247xr", "statos_dbase");
		 
		if ($link === false) {
			echo "(recoverid.php) ERROR: Could not connect (Falha de conexao)."; 
			die ("(recoverid.php) ERROR: Could not connect (Erro de conexao): " . mysqli_connect_error());
		}
		 
		// echo "Connect Successfully. Host info: " . mysqli_get_host_info($link); // print detailed host info
*/

		$sql = "SELECT email, id FROM 02_mesicon_users WHERE email = '" . $email . "'";
		if ($result = mysqli_query($conn, $sql)) {
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_array($result)) {
					echo "ID: " . $row['id']; // found email
					$id = $row['id'];

					$emailSubject = "(ALTERAR/CHANGE) MESICON";

                    $msg = "Esta é uma mensagem automática, por favor não a responda.\nThis is an automatic message, please do not respond to it.";
                    $msg .= "----------\n";
					$msg .= "Clique no link a seguir para alterar seu email de acesso ou senha:\nClick the following link to change your access email or password:\n\n";
					//$msg .= "$row['password'] . "\n";
					$msg .= "https://www.statos.com/mesicon/changemailpass.php?HelloHAL=" . $temp . "&DoYouReadMe=statos";
            $msg .= "\n----------\n\n";
            $msg .= "Manuscritos e Edições SIstema de CONtrole - MESICON\n";
            $msg .= "statos.com/mesicon\n\n";
            $msg .= "Se você considera esta mensagem um erro, delete-a sem problemas.\nIf you consider this message an error, please delete it.\n\n\n\n";

					// vai para assinante
					//if (@ mail ($email, $emailSubject, $msg, $mail_header)) {
					//if (@ mail ($email, $emailSubject, $msg)) {
						
						
					// código para envio de email original Locaweb
					/*
					if(!mail($emaildestinatario, $assunto, $mensagemHTML, $headers ,"-r".$emailsender)){ // Se for Postfix
						$headers .= "Return-Path: " . $emailsender . $quebra_linha; // Se "não for Postfix"
						mail($emaildestinatario, $assunto, $mensagemHTML, $headers );
					}
					*/
					
					$emailsender = "apps@statos.com";

					$headers = "MIME-Version: 1.1\n";
					$headers .= "Content-type: text/plain; charset=UTF-8\n";
					$headers .= "X-Priority: 1\n"; // para enviar a mensagem em prioridade máxima
					$headers .= "From: " . $emailsender . "\n"; // remetente
					$headers .= "Return-Path: " . $emailsender . "\n"; // return-path

					// TODO - descobrir por que, no código abaixo, vai email mesmo no else
					if(!mail($email, $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Se for Postfix
						// $headers .= "Return-Path: " . $emailsender . $quebra_linha; // Se "não for Postfix"
						mail($email, $emailSubject, $msg, $headers );
						$achou = 1;
						// foi
					} else {
						$achou = 2; // não foi possível enviar o email com a senha
						// erro
					}

					$sql = "INSERT INTO 02_mesicon_passemailchange (temp, created_at) VALUES('$temp', now())";
					mysqli_query($conn, $sql); // insere Rand como temp em passemailchange

					$sql = "UPDATE 02_mesicon_users SET temp='$temp' WHERE id='$id'";
					mysqli_query($conn, $sql); // insere mesmo Rand como temp em users

				}
				
				mysqli_free_result($result); // Free result set
			} else {
				// echo "-1'" . $email;
			}
		} else {
			//echo "Usuario nao localizado: " . mysqli_error($conn);
		}

		mysqli_close($conn);

		
	} else {
		echo "403: forbidden"; // closes if password not present
	}
	
} else {
	echo "403: forbidden"; // closes if values didn't come by POST
}

if ($achou == 0) $_SESSION['message'] = "E-mail? Tente novamente/Try again 3"; // 0: email não localizado
if ($achou == 1 || $achou == 2) $_SESSION['message'] = "Ok! Verifique email, talvez pasta spam/Check your e-mail, maybe spam folder 2"; // 1: achou
// TODO: verificar por que mesmo com $achou = 2 ele localiza o user e envia o email
//if ($achou == 2) $_SESSION['message'] = "Erro no sistema, tente novamente 1"; // 2: achou email, mas msg não enviada por algum motivo

header('Location: login.php');
exit();

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->
