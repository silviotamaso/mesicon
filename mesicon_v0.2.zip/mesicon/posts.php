<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

// se não tiver ordenação definida, vai por data de cadastro
if (!$_GET['o']) $order = "created_at";
else $order = $_GET['o'];

// se não tiver sentido de ordenação, vai por ascendente
if (!$_GET['o2']) $asc_or_desc = "DESC";
else $asc_or_desc = $_GET['o2'];

$table = "1"; // corresponde a books, books_temp, manuscripts e manuscripts_temp

$posts = getAllBAM($table, $order, $asc_or_desc);

$contador = 1;
$contabela = 0;

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Posts</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<table width="100%"><tr><td align="center">
<h1><?php if ($_SESSION['user']['role'] == "Administrator") echo "Minhas "; ?><?= txt('postagens') ?><br></h1><h3><a href="control_panel.php">&lt;&lt; <?= txt('voltar') ?> <?= txt('paineldecontrole') ?></a></h3></td>
<td align="center" valign="middle"><a href='create_book.php?i=0'><h1>+<?= txt('L') ?></h1></a></td>
<td align="center" valign="middle"><a href='create_manuscript.php?i=0'><h1>+M</h1></a></td>
<td align="center">
<?php
echo "<font size='-1'>";
echo "<a href='posts.php?o=created_at&o2=DESC'>" . txt('data') . "</a><br>";
echo "<a href='posts.php?o=author&o2=ASC'>" . txt('autoria') . "</a><br>";
echo "<a href='posts.php?o=title&o2=ASC'>" . txt('titulo') . "</a><br>";
echo "</font>";
?>
</td>
</tr></table> <!-- tabela superior: título, links de ordenamento -->

<?php include('incl_messages.php') ?>

<?php if (empty($posts)): 
// esta condição aqui só vai existir se o banco estiver completamente vazio - pay attention vacilão
else: ?>



<br><table border="1" cellspacing="0" cellpadding="0" bordercolor="#cccccc" align="center" width="100%">

<tr>
<td align="center"><font size="-1">#</font></td>
<td align="center"><font size="-1"><?= txt('tipo') ?></font></td>
<td align="center"><font size="-1"><?= txt('titulo') ?></font></td>
<td align="center"><font size="-1"><?= txt('autor') ?></font></td>
<td align="center"><font size="-1"><?= txt('editar') ?></font></td>
<td align="center"><font size="-1"><?= txt('publicado') ?></font></td>
</tr> <!-- cabeçalho da tabela -->





    
    
    
<!-- abaixo:
- foreach roda número de vezes igual à qtde de tabelas, atualmente 2, indicadas por $key;
- count($posts) retorna o número de tabelas também;
- count($post) retorna o número de itens dentro de cada tabela, em cada foreach;
- $key: nome da tabela em questão
-->
<?php foreach ($posts as $key => $post): ?>
    
    
    
    <?php
    ///////////// ABRE DEBUG ////////////////////// - funcionando perfecto: reproduz em escala menor o que deve rodar abaixo
    //if ($key == "02_mesicon_books") $contabela = 0; // leu todas as linhas da primeira tabela, quando entrar na segunda zera o contador
    //echo "<br>tabela: " . $key . "<br>";
    //while ($contabela < count($post)) {
        //echo "contabela: " . $contabela . "<br>"; // está indo de 0 a 1, afinal são 2 tabelas
        //echo "post[$contabela]['author']: " . $post[$contabela]['author'] . "<br>";
        //$contabela++;
    //}
    ///////////// FECHA DEBUG //////////////////////////////////////////////////////////////
    ?>
    
    

    <?php
    if ($key == "02_mesicon_books_temp") $tabela = 0;

    if ($key == "02_mesicon_books") {
        $contabela = 0; // leu todas as linhas da primeira tabela, quando entrar na segunda zera o contador
        $tabela = 1;
    }

    if ($key == "02_mesicon_manuscripts_temp") {
        $contabela = 0; // leu todas as linhas da segunda tabela, quando entrar na terceira zera o contador
        $tabela = 2;
    }

    if ($key == "02_mesicon_manuscripts") {
        $contabela = 0; // leu todas as linhas da terceira tabela, quando entrar na quarta zera o contador
        $tabela = 3;
    }
    
    while ($contabela < count($post)) {
    ?>

        <!-- listar se o usuário é o criador dos posts e o post está com published -->
        <?php if (($_SESSION['user']['id'] == $post[$contabela]['creator_id']) && $post[$contabela]['published'] != 4) : ?>
        <tr style="height: 50px;">

            <td align=center><font size="-2"><?= $contador++ ?></font></td> <!-- número de ordem -->

            <td align=center><font size="-2">
            <?php
            if ($tabela == 0 || $tabela == 1) echo txt('L');
            if ($tabela == 2 || $tabela == 3) echo txt('M');
            ?>
            </font></td>

            <td>
                <font size="-1">
                <?php 
                // echo $post[$contabela]['title'];
                if (strlen($post[$contabela]['title']) > 13) echo substr($post[$contabela]['title'],0,13) . "...";
                else if (strlen($post[$contabela]['title']) < 2 || $post[$contabela]['title'] == "") echo "-";
                else echo $post[$contabela]['title'];
                if ($post[$contabela]['ed_number'] != 0) echo "<sup>" . $post[$contabela]['ed_number'] . "<font size='-2'>ed</font></sup>";
                ?>
                </font>
            </td> <!-- título e número da edição -->

            <td><font size="-1"><a href="<?= 'post.php?id=' . $post[$contabela]['id'] . '&t=' . $tabela ?>">
                <?php
                if (strlen($post[$contabela]['author']) > 16) echo substr($post[$contabela]['author'],0,15) . "...";
                else echo $post[$contabela]['author'];
                ?>                    
            </a></font></td> <!-- autor -->

            <td align="center">
                <?php 
                if ($post[$contabela]['published'] == 1 || $post[$contabela]['published'] == 2) {
                    if ($tabela == 0 || $tabela == 1) echo "<a href='edit_book.php?i=" . $post[$contabela]['id'] . "&t=" . $tabela . "'>" . txt('editar') . "</a>";
                    if ($tabela == 2 || $tabela == 3) echo "<a href='edit_manuscript.php?i=" . $post[$contabela]['id'] . "&t=" . $tabela . "'>" . txt('editar') . "</a>";
                }
                if ($post[$contabela]['published'] == 0 || $post[$contabela]['published'] == 3) echo "<font size='-1'>" . txt('aguarde') . "</font>";
                ?>
            </td> <!-- editar -->

            <td align="center"><a href=# onclick="javascript:alert('MESICON\n\nAtualizado em/Updated in: <?= $post[$contabela]['created_at'] ?>');">
                <?php 
                if ($post[$contabela]['published'] == 1) echo txt('sim');
                else echo txt('nao');
                ?>
            </a></td> <!-- publicado -->

        </tr> <!-- conteúdo principal -->
        <?php endif ?>
    

    <?php
        //echo "post[$contabela]['author']: " . $post[$contabela]['author'] . "<br>";
        $contabela++;
    }
    ?>





    
    
<?php endforeach ?>











</table> <!-- tabela princial, é onde está o principal da pg -->












<?php
    endif;
    if ($contador == 1) echo "<br><h3>" . txt('sempost') . ".</h3>";
?> <!-- controla se exibe conteúdo total ou não a depender das postagens, se não há nenhuma, exibe nada, se há de uma para mais, exibe tudo -->

<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>


