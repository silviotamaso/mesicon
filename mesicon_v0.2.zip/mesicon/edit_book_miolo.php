<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

        <input type='hidden' name='id' value='<?php echo $id; ?>'>
        <input type="hidden" name="creator" value="<?= $post['creator'] ?>">
        <input type="hidden" name="creator_id" value="<?= $post['creator_id'] ?>">

        <br><?= txt('casohajainfo') ?>.<br><br>

        <br><font color='red'>*</font> <?= txt('titulo') ?>:
        <div id='ltitle' class='ct'></div>
        <?php 
            if ($post['title'] != "0" && strlen($post['title']) > 1) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='title' name='title' value='" . $post['title'] . "' placeholder='" . txt('titulo') . "' maxlength='199'>";
            else echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='title' name='title' value='' placeholder='" . txt('titulo') ."' maxlength='199'>";
        ?>
        
        <br><br><font color='red'>*</font> <?= txt('autor') ?><sup><a href="javascript:alert('MESICON\n\nUse \';\' para separar nomes.\n\nUse \';\' to separate names.');">&nbsp;&#9432;&nbsp;</a></sup> (<?= txt('sobrenome') ?>, <?= txt('nome') ?>):<br>
        <div id='lauthor' class='ct'></div>
        <input onkeyup="statosdotcom_Count(this,199);" type='text' id='author' name='author' value='<?= $post['author'] ?>' placeholder='<?= txt('autor') ?>' maxlength='199'>

        <!--
        // it was this way when "org" was commanded by a checkbox
        <label for="org">
        <?php 
        //if ($post['org'] == 1) echo "<input type=checkbox id=org name=org checked value=1>";
        //else echo "<input type=checkbox id=org name=org value=0>";
        ?>
        <h3>Selecione a caixa acima se o(a/s) autor(a/s/es) for(em) organizador(a/s/es) ou editor(a/s/es).</h3></label><br>
        -->

        <br><br><?= txt('ehorganizador') ?>?<br>
        <select name="org" id="org">
        <?php
        if ($post['org'] == '0') echo "<option value='0' selected>" . txt('orged') . "?</option>";
        if ($post['org'] == '1') echo "<option value='1' selected>" . txt('expressamente') . "</option>";
        if ($post['org'] == '2') echo "<option value='2' selected>" . txt('presumivelmente') . "</option>";
        ?>
        <option value='0'><?= txt('orged') ?>?</option>
        <option value='1'><?= txt('expressamente') ?></option>
        <option value='2'><?= txt('presumivelmente') ?></option>
        </select>


        <br><br><?= txt('numeroedicao') ?>:<br>
        <select name='ed_number' id='ed_number'>
        <?php
        if ($post['ed_number'] == 0) echo "<option value=0 selected>" . txt('numeroedicao') . "?</option>";
        else echo "<option value=" . $post['ed_number'] . " selected>" . $post['ed_number'] . "</option>";
        echo "<option value=0>" . txt('numeroedicao') . "?</option>";
        $contador = 0;
        while ($contador<75){
        $contador++;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
        }
        ?>
        </select>

        <br><br>Volumes:<br>
        <select name='tomos' id='tomos'>
        <?php
        if ($post['tomos'] == 0) echo '<option value=0 selected>Volumes?</option>';
        else echo "<option selected value=" . $post['tomos'] . ">" . $post['tomos'] . "</option>";
        echo '<option value=0>Volumes?</option>';
        $contador = 0;
        while ($contador<9){
        $contador++;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
        }
        ?>
        </select>

        <br><br><?= txt('series') ?>:
        <div id='lseries' class='ct'></div>
        <?php
        if ($post['series'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='series' id='series' placeholder='" . txt('series') . "' maxlength='99'>";
        else echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='series' id='series' value='" . $post['series'] . "' placeholder='" . txt('series') . "' maxlength='99'>";
        ?>

        <br><br><?= txt('numseries') ?>:<br>
        <select name='num_series' id='num_series'>
        <?php
        if ($post['num_series'] == 0) echo "<option value=0 selected>" . txt('numero') . "?</option>";
        else echo "<option selected value=" . $post['num_series'] . ">" . $post['num_series'] . "</option>";
        echo "<option value=0>" . txt('numero') . "?</option>";
        $contador = 0;
        while ($contador<99){
        $contador++;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
        }
        ?>
        </select>

        <br><br><?= txt('editora') ?>:<br>
        <div id='lpublisher' class='ct'></div>
        <?php
        if ($post['publisher'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='publisher' id='publisher' placeholder='" . txt('editora') . "' maxlength='99'>";
        else echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='publisher' id='publisher' value='" . $post['publisher'] . "' placeholder='" . txt('editora') . "' maxlength='99'>";
        ?>

        <br><br><?= txt('cidade') ?>:<br>
        <div id='lcity' class='ct'></div>
        <?php
        if ($post['city'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='city' id='city' placeholder='" . txt('cidade') . "' maxlength='99'>";
        else echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='city' id='city' value='" . $post['city'] . "' placeholder='" . txt('cidade') . "' maxlength='99'>";
        ?>

        <br><br><?= txt('estado') ?>:<br>
        <!-- <label for='state'>Estado:</label> -->
        <select name='state' id='state'>
        <?php
        if ($post['state'] == '0') echo "<option value='0' selected>" . txt('estado') . "?</option>";
        if ($post['state'] == 'AC') echo "<option value='AC' selected>Acre</option>";
        if ($post['state'] == 'AL') echo "<option value='AL' selected>Alagoas</option>";
        if ($post['state'] == 'AP') echo "<option value='AP' selected>Amapá</option>";
        if ($post['state'] == 'AM') echo "<option value='AM' selected>Amazonas</option>";
        if ($post['state'] == 'BA') echo "<option value='BA' selected>Bahia</option>";
        if ($post['state'] == 'CE') echo "<option value='CE' selected>Ceará</option>";
        if ($post['state'] == 'DF') echo "<option value='DF' selected>Distrito Federal</option>";
        if ($post['state'] == 'ES') echo "<option value='ES' selected>Espirito Santo</option>";
        if ($post['state'] == 'GO') echo "<option value='GO' selected>Goiás</option>";
        if ($post['state'] == 'MA') echo "<option value='MA' selected>Maranhão</option>";
        if ($post['state'] == 'MS') echo "<option value='MS' selected>Mato Grosso do Sul</option>";
        if ($post['state'] == 'MT') echo "<option value='MT' selected>Mato Grosso</option>";
        if ($post['state'] == 'MG') echo "<option value='MG' selected>Minas Gerais</option>";
        if ($post['state'] == 'PA') echo "<option value='PA' selected>Pará</option>";
        if ($post['state'] == 'PB') echo "<option value='PB' selected>Paraíba</option>";
        if ($post['state'] == 'PR') echo "<option value='PR' selected>Paraná</option>";
        if ($post['state'] == 'PE') echo "<option value='PE' selected>Pernambuco</option>";
        if ($post['state'] == 'PI') echo "<option value='PI' selected>Piauí</option>";
        if ($post['state'] == 'RJ') echo "<option value='RJ' selected>Rio de Janeiro</option>";
        if ($post['state'] == 'RN') echo "<option value='RN' selected>Rio Grande do Norte</option>";
        if ($post['state'] == 'RS') echo "<option value='RS' selected>Rio Grande do Sul</option>";
        if ($post['state'] == 'RO') echo "<option value='RO' selected>Rondônia</option>";
        if ($post['state'] == 'RR') echo "<option value='RR' selected>Roraima</option>";
        if ($post['state'] == 'SC') echo "<option value='SC' selected>Santa Catarina</option>";
        if ($post['state'] == 'SP') echo "<option value='SP' selected>São Paulo</option>";
        if ($post['state'] == 'SE') echo "<option value='SE' selected>Sergipe</option>";
        if ($post['state'] == 'TO') echo "<option value='TO' selected>Tocantins</option>";
        ?>
        <option value='0'><?= txt('estado') ?>?</option>
        <option value='AC'>Acre</option>
        <option value='AL'>Alagoas</option>
        <option value='AP'>Amapá</option>
        <option value='AM'>Amazonas</option>
        <option value='BA'>Bahia</option>
        <option value='CE'>Ceará</option>
        <option value='DF'>Distrito Federal</option>
        <option value='ES'>Espirito Santo</option>
        <option value='GO'>Goiás</option>
        <option value='MA'>Maranhão</option>
        <option value='MS'>Mato Grosso do Sul</option>
        <option value='MT'>Mato Grosso</option>
        <option value='MG'>Minas Gerais</option>
        <option value='PA'>Pará</option>
        <option value='PB'>Paraíba</option>
        <option value='PR'>Paraná</option>
        <option value='PE'>Pernambuco</option>
        <option value='PI'>Piauí</option>
        <option value='RJ'>Rio de Janeiro</option>
        <option value='RN'>Rio Grande do Norte</option>
        <option value='RS'>Rio Grande do Sul</option>
        <option value='RO'>Rondônia</option>
        <option value='RR'>Roraima</option>
        <option value='SC'>Santa Catarina</option>
        <option value='SP'>São Paulo</option>
        <option value='SE'>Sergipe</option>
        <option value='TO'>Tocantins</option>
        </select>

        <br><br><?= txt('paisdepublicacao') ?>:<br>
        <!-- <label for='country'>País:</label> -->
        <select id='country' name='country'>
        <?php
        if ($post['country'] == '0') echo "<option value='0' selected>" . txt('paisdepublicacao') . "?</option>";
        if ($post['country'] == 'Afganistan') echo "<option value='Afganistan' selected>Afghanistan</option>";
        if ($post['country'] == 'Albania') echo "<option value='Albania' selected>Albania</option>";
        if ($post['country'] == 'Algeria') echo "<option value='Algeria' selected>Algeria</option>";
        if ($post['country'] == 'Angola') echo "<option value='Angola' selected>Angola</option>";
        if ($post['country'] == 'Argentina') echo "<option value='Argentina' selected>Argentina</option>";
        if ($post['country'] == 'Armenia') echo "<option value='Armenia' selected>Armenia</option>";
        if ($post['country'] == 'Aruba') echo "<option value='Aruba' selected>Aruba</option>";
        if ($post['country'] == 'Australia') echo "<option value='Australia' selected>Australia</option>";
        if ($post['country'] == 'Austria') echo "<option value='Austria' selected>Austria</option>";
        if ($post['country'] == 'Azerbaijan') echo "<option value='Azerbaijan' selected>Azerbaijan</option>";
        if ($post['country'] == 'Bahamas') echo "<option value='Bahamas' selected>Bahamas</option>";
        if ($post['country'] == 'Bahrain') echo "<option value='Bahrain' selected>Bahrain</option>";
        if ($post['country'] == 'Barbados') echo "<option value='Barbados' selected>Barbados</option>";
        if ($post['country'] == 'Belarus') echo "<option value='Belarus' selected>Belarus</option>";
        if ($post['country'] == 'Belgium') echo "<option value='Belgium' selected>Belgium</option>";
        if ($post['country'] == 'Bolivia') echo "<option value='Bolivia' selected>Bolivia</option>";
        if ($post['country'] == 'Bosnia & Herzegovina') echo "<option value='Bosnia & Herzegovina' selected>Bosnia & Herzegovina</option>";
        if ($post['country'] == 'Brasil') echo "<option value='Brasil' selected>Brasil</option>";
        if ($post['country'] == 'Bulgaria') echo "<option value='Bulgaria' selected>Bulgaria</option>";
        if ($post['country'] == 'Cambodia') echo "<option value='Cambodia' selected>Cambodia</option>";
        if ($post['country'] == 'Cameroon') echo "<option value='Cameroon' selected>Cameroon</option>";
        if ($post['country'] == 'Canada') echo "<option value='Canada' selected>Canada</option>";
        if ($post['country'] == 'Cape Verde') echo "<option value='Cape Verde' selected>Cape Verde</option>";
        if ($post['country'] == 'Chile') echo "<option value='Chile' selected>Chile</option>";
        if ($post['country'] == 'China') echo "<option value='China' selected>China</option>";
        if ($post['country'] == 'Colombia') echo "<option value='Colombia' selected>Colombia</option>";
        if ($post['country'] == 'Congo') echo "<option value='Congo' selected>Congo</option>";
        if ($post['country'] == 'Costa Rica') echo "<option value='Costa Rica' selected>Costa Rica</option>";
        if ($post['country'] == 'Cote DIvoire') echo "<option value='Cote DIvoire' selected>Cote DIvoire</option>";
        if ($post['country'] == 'Croatia') echo "<option value='Croatia' selected>Croatia</option>";
        if ($post['country'] == 'Cuba') echo "<option value='Cuba' selected>Cuba</option>";
        if ($post['country'] == 'Cyprus') echo "<option value='Cyprus' selected>Cyprus</option>";
        if ($post['country'] == 'Czech Republic') echo "<option value='Czech Republic' selected>Czech Republic</option>";
        if ($post['country'] == 'Denmark') echo "<option value='Denmark' selected>Denmark</option>";
        if ($post['country'] == 'East Timor') echo "<option value='East Timor' selected>East Timor</option>";
        if ($post['country'] == 'Ecuador') echo "<option value='Ecuador' selected>Ecuador</option>";
        if ($post['country'] == 'Egypt') echo "<option value='Egypt' selected>Egypt</option>";
        if ($post['country'] == 'El Salvador') echo "<option value='El Salvador' selected>El Salvador</option>";
        if ($post['country'] == 'Estonia') echo "<option value='Estonia' selected>Estonia</option>";
        if ($post['country'] == 'Finland') echo "<option value='Finland' selected>Finland</option>";
        if ($post['country'] == 'France') echo "<option value='France' selected>France</option>";
        if ($post['country'] == 'French Guiana') echo "<option value='French Guiana' selected>French Guiana</option>";
        if ($post['country'] == 'Germany') echo "<option value='Germany' selected>Germany</option>";
        if ($post['country'] == 'Great Britain') echo "<option value='Great Britain' selected>Great Britain</option>";
        if ($post['country'] == 'Greece') echo "<option value='Greece' selected>Greece</option>";
        if ($post['country'] == 'Grenada') echo "<option value='Grenada' selected>Grenada</option>";
        if ($post['country'] == 'Guatemala') echo "<option value='Guatemala' selected>Guatemala</option>";
        if ($post['country'] == 'Guinea') echo "<option value='Guinea' selected>Guinea</option>";
        if ($post['country'] == 'Guyana') echo "<option value='Guyana' selected>Guyana</option>";
        if ($post['country'] == 'Haiti') echo "<option value='Haiti' selected>Haiti</option>";
        if ($post['country'] == 'Hawaii') echo "<option value='Hawaii' selected>Hawaii</option>";
        if ($post['country'] == 'Honduras') echo "<option value='Honduras' selected>Honduras</option>";
        if ($post['country'] == 'Hong Kong') echo "<option value='Hong Kong' selected>Hong Kong</option>";
        if ($post['country'] == 'Hungary') echo "<option value='Hungary' selected>Hungary</option>";
        if ($post['country'] == 'Iceland') echo "<option value='Iceland' selected>Iceland</option>";
        if ($post['country'] == 'Indonesia') echo "<option value='Indonesia' selected>Indonesia</option>";
        if ($post['country'] == 'India') echo "<option value='India' selected>India</option>";
        if ($post['country'] == 'Iran') echo "<option value='Iran' selected>Iran</option>";
        if ($post['country'] == 'Iraq') echo "<option value='Iraq' selected>Iraq</option>";
        if ($post['country'] == 'Ireland') echo "<option value='Ireland' selected>Ireland</option>";
        if ($post['country'] == 'Israel') echo "<option value='Israel' selected>Israel</option>";
        if ($post['country'] == 'Italy') echo "<option value='Italy' selected>Italy</option>";
        if ($post['country'] == 'Jamaica') echo "<option value='Jamaica' selected>Jamaica</option>";
        if ($post['country'] == 'Japan') echo "<option value='Japan' selected>Japan</option>";
        if ($post['country'] == 'Kazakhstan') echo "<option value='Kazakhstan' selected>Kazakhstan</option>";
        if ($post['country'] == 'Korea South') echo "<option value='Korea South' selected>Korea South</option>";
        if ($post['country'] == 'Latvia') echo "<option value='Latvia' selected>Latvia</option>";
        if ($post['country'] == 'Lebanon') echo "<option value='Lebanon' selected>Lebanon</option>";
        if ($post['country'] == 'Libya') echo "<option value='Libya' selected>Libya</option>";
        if ($post['country'] == 'Liechtenstein') echo "<option value='Liechtenstein' selected>Liechtenstein</option>";
        if ($post['country'] == 'Lithuania') echo "<option value='Lithuania' selected>Lithuania</option>";
        if ($post['country'] == 'Luxembourg') echo "<option value='Luxembourg' selected>Luxembourg</option>";
        if ($post['country'] == 'Macau') echo "<option value='Macau' selected>Macau</option>";
        if ($post['country'] == 'Macedonia') echo "<option value='Macedonia' selected>Macedonia</option>";
        if ($post['country'] == 'Malaysia') echo "<option value='Malaysia' selected>Malaysia</option>";
        if ($post['country'] == 'Maldives') echo "<option value='Maldives' selected>Maldives</option>";
        if ($post['country'] == 'Mali') echo "<option value='Mali' selected>Mali</option>";
        if ($post['country'] == 'Malta') echo "<option value='Malta' selected>Malta</option>";
        if ($post['country'] == 'Martinique') echo "<option value='Martinique' selected>Martinique</option>";
        if ($post['country'] == 'Mexico') echo "<option value='Mexico' selected>Mexico</option>";
        if ($post['country'] == 'Moldova') echo "<option value='Moldova' selected>Moldova</option>";
        if ($post['country'] == 'Monaco') echo "<option value='Monaco' selected>Monaco</option>";
        if ($post['country'] == 'Mongolia') echo "<option value='Mongolia' selected>Mongolia</option>";
        if ($post['country'] == 'Morocco') echo "<option value='Morocco' selected>Morocco</option>";
        if ($post['country'] == 'Mozambique') echo "<option value='Mozambique' selected>Mozambique</option>";
        if ($post['country'] == 'Nepal') echo "<option value='Nepal' selected>Nepal</option>";
        if ($post['country'] == 'Netherlands') echo "<option value='Netherlands' selected>Netherlands (Holland)</option>";
        if ($post['country'] == 'New Zealand') echo "<option value='New Zealand' selected>New Zealand</option>";
        if ($post['country'] == 'Nigeria') echo "<option value='Nigeria' selected>Nigeria</option>";
        if ($post['country'] == 'Norway') echo "<option value='Norway' selected>Norway</option>";
        if ($post['country'] == 'Pakistan') echo "<option value='Pakistan' selected>Pakistan</option>";
        if ($post['country'] == 'Panama') echo "<option value='Panama' selected>Panama</option>";
        if ($post['country'] == 'Paraguay') echo "<option value='Paraguay' selected>Paraguay</option>";
        if ($post['country'] == 'Peru') echo "<option value='Peru' selected>Peru</option>";
        if ($post['country'] == 'Phillipines') echo "<option value='Phillipines' selected>Philippines</option>";
        if ($post['country'] == 'Poland') echo "<option value='Poland' selected>Poland</option>";
        if ($post['country'] == 'Portugal') echo "<option value='Portugal' selected>Portugal</option>";
        if ($post['country'] == 'Puerto Rico') echo "<option value='Puerto Rico' selected>Puerto Rico</option>";
        if ($post['country'] == 'Qatar') echo "<option value='Qatar' selected>Qatar</option>";
        if ($post['country'] == 'Republic of Montenegro') echo "<option value='Republic of Montenegro' selected>Republic of Montenegro</option>";
        if ($post['country'] == 'Republic of Serbia') echo "<option value='Republic of Serbia' selected>Republic of Serbia</option>";
        if ($post['country'] == 'Romania') echo "<option value='Romania' selected>Romania</option>";
        if ($post['country'] == 'Russia') echo "<option value='Russia' selected>Russia</option>";
        if ($post['country'] == 'Sao Tome & Principe') echo "<option value='Sao Tome & Principe' selected>Sao Tome & Principe</option>";
        if ($post['country'] == 'Saudi Arabia') echo "<option value='Saudi Arabia' selected>Saudi Arabia</option>";
        if ($post['country'] == 'Senegal') echo "<option value='Senegal' selected>Senegal</option>";
        if ($post['country'] == 'Singapore') echo "<option value='Singapore' selected>Singapore</option>";
        if ($post['country'] == 'Slovakia') echo "<option value='Slovakia' selected>Slovakia</option>";
        if ($post['country'] == 'Slovenia') echo "<option value='Slovenia' selected>Slovenia</option>";
        if ($post['country'] == 'South Africa') echo "<option value='South Africa' selected>South Africa</option>";
        if ($post['country'] == 'Spain') echo "<option value='Spain' selected>Spain</option>";
        if ($post['country'] == 'Sudan') echo "<option value='Sudan' selected>Sudan</option>";
        if ($post['country'] == 'Sweden') echo "<option value='Sweden' selected>Sweden</option>";
        if ($post['country'] == 'Switzerland') echo "<option value='Switzerland' selected>Switzerland</option>";
        if ($post['country'] == 'Syria') echo "<option value='Syria' selected>Syria</option>";
        if ($post['country'] == 'Taiwan') echo "<option value='Taiwan' selected>Taiwan</option>";
        if ($post['country'] == 'Thailand') echo "<option value='Thailand' selected>Thailand</option>";
        if ($post['country'] == 'Tunisia') echo "<option value='Tunisia' selected>Tunisia</option>";
        if ($post['country'] == 'Turkey') echo "<option value='Turkey' selected>Turkey</option>";
        if ($post['country'] == 'Uganda') echo "<option value='Uganda' selected>Uganda</option>";
        if ($post['country'] == 'United Kingdom') echo "<option value='United Kingdom' selected>United Kingdom</option>";
        if ($post['country'] == 'Ukraine') echo "<option value='Ukraine' selected>Ukraine</option>";
        if ($post['country'] == 'United Arab Erimates') echo "<option value='United Arab Erimates' selected>United Arab Emirates</option>";
        if ($post['country'] == 'United States of America') echo "<option value='United States of America' selected>United States of America</option>";
        if ($post['country'] == 'Uruguay') echo "<option value='Uruguay' selected>Uruguay</option>";
        if ($post['country'] == 'Vatican City State') echo "<option value='Vatican City State' selected>Vatican City State</option>";
        if ($post['country'] == 'Venezuela') echo "<option value='Venezuela' selected>Venezuela</option>";
        if ($post['country'] == 'Vietnam') echo "<option value='Vietnam' selected>Vietnam</option>";
        if ($post['country'] == 'Zimbabwe') echo "<option value='Zimbabwe' selected>Zimbabwe</option>";
        ?>
        <option value='0'><?= txt('paisdepublicacao') ?>?</option>
        <option value='Afganistan'>Afghanistan</option>
        <option value='Albania'>Albania</option>
        <option value='Algeria'>Algeria</option>
        <option value='Angola'>Angola</option>
        <option value='Argentina'>Argentina</option>
        <option value='Armenia'>Armenia</option>
        <option value='Aruba'>Aruba</option>
        <option value='Australia'>Australia</option>
        <option value='Austria'>Austria</option>
        <option value='Azerbaijan'>Azerbaijan</option>
        <option value='Bahamas'>Bahamas</option>
        <option value='Bahrain'>Bahrain</option>
        <option value='Barbados'>Barbados</option>
        <option value='Belarus'>Belarus</option>
        <option value='Belgium'>Belgium</option>
        <option value='Bolivia'>Bolivia</option>
        <option value='Bosnia & Herzegovina'>Bosnia & Herzegovina</option>
        <option value='Brasil'>Brasil</option>
        <option value='Bulgaria'>Bulgaria</option>
        <option value='Cambodia'>Cambodia</option>
        <option value='Cameroon'>Cameroon</option>
        <option value='Canada'>Canada</option>
        <option value='Cape Verde'>Cape Verde</option>
        <option value='Chile'>Chile</option>
        <option value='China'>China</option>
        <option value='Colombia'>Colombia</option>
        <option value='Congo'>Congo</option>
        <option value='Costa Rica'>Costa Rica</option>
        <option value='Cote DIvoire'>Cote DIvoire</option>
        <option value='Croatia'>Croatia</option>
        <option value='Cuba'>Cuba</option>
        <option value='Cyprus'>Cyprus</option>
        <option value='Czech Republic'>Czech Republic</option>
        <option value='Denmark'>Denmark</option>
        <option value='East Timor'>East Timor</option>
        <option value='Ecuador'>Ecuador</option>
        <option value='Egypt'>Egypt</option>
        <option value='El Salvador'>El Salvador</option>
        <option value='Estonia'>Estonia</option>
        <option value='Finland'>Finland</option>
        <option value='France'>France</option>
        <option value='French Guiana'>French Guiana</option>
        <option value='Germany'>Germany</option>
        <option value='Great Britain'>Great Britain</option>
        <option value='Greece'>Greece</option>
        <option value='Grenada'>Grenada</option>
        <option value='Guatemala'>Guatemala</option>
        <option value='Guinea'>Guinea</option>
        <option value='Guyana'>Guyana</option>
        <option value='Haiti'>Haiti</option>
        <option value='Hawaii'>Hawaii</option>
        <option value='Honduras'>Honduras</option>
        <option value='Hong Kong'>Hong Kong</option>
        <option value='Hungary'>Hungary</option>
        <option value='Iceland'>Iceland</option>
        <option value='Indonesia'>Indonesia</option>
        <option value='India'>India</option>
        <option value='Iran'>Iran</option>
        <option value='Iraq'>Iraq</option>
        <option value='Ireland'>Ireland</option>
        <option value='Israel'>Israel</option>
        <option value='Italy'>Italy</option>
        <option value='Jamaica'>Jamaica</option>
        <option value='Japan'>Japan</option>
        <option value='Kazakhstan'>Kazakhstan</option>
        <option value='Korea South'>Korea South</option>
        <option value='Latvia'>Latvia</option>
        <option value='Lebanon'>Lebanon</option>
        <option value='Libya'>Libya</option>
        <option value='Liechtenstein'>Liechtenstein</option>
        <option value='Lithuania'>Lithuania</option>
        <option value='Luxembourg'>Luxembourg</option>
        <option value='Macau'>Macau</option>
        <option value='Macedonia'>Macedonia</option>
        <option value='Malaysia'>Malaysia</option>
        <option value='Maldives'>Maldives</option>
        <option value='Mali'>Mali</option>
        <option value='Malta'>Malta</option>
        <option value='Martinique'>Martinique</option>
        <option value='Mexico'>Mexico</option>
        <option value='Moldova'>Moldova</option>
        <option value='Monaco'>Monaco</option>
        <option value='Mongolia'>Mongolia</option>
        <option value='Morocco'>Morocco</option>
        <option value='Mozambique'>Mozambique</option>
        <option value='Nepal'>Nepal</option>
        <option value='Netherlands'>Netherlands (Holland)</option>
        <option value='New Zealand'>New Zealand</option>
        <option value='Nigeria'>Nigeria</option>
        <option value='Norway'>Norway</option>
        <option value='Pakistan'>Pakistan</option>
        <option value='Panama'>Panama</option>
        <option value='Paraguay'>Paraguay</option>
        <option value='Peru'>Peru</option>
        <option value='Phillipines'>Philippines</option>
        <option value='Poland'>Poland</option>
        <option value='Portugal'>Portugal</option>
        <option value='Puerto Rico'>Puerto Rico</option>
        <option value='Qatar'>Qatar</option>
        <option value='Republic of Montenegro'>Republic of Montenegro</option>
        <option value='Republic of Serbia'>Republic of Serbia</option>
        <option value='Romania'>Romania</option>
        <option value='Russia'>Russia</option>
        <option value='Sao Tome & Principe'>Sao Tome & Principe</option>
        <option value='Saudi Arabia'>Saudi Arabia</option>
        <option value='Senegal'>Senegal</option>
        <option value='Singapore'>Singapore</option>
        <option value='Slovakia'>Slovakia</option>
        <option value='Slovenia'>Slovenia</option>
        <option value='South Africa'>South Africa</option>
        <option value='Spain'>Spain</option>
        <option value='Sudan'>Sudan</option>
        <option value='Sweden'>Sweden</option>
        <option value='Switzerland'>Switzerland</option>
        <option value='Syria'>Syria</option>
        <option value='Taiwan'>Taiwan</option>
        <option value='Thailand'>Thailand</option>
        <option value='Tunisia'>Tunisia</option>
        <option value='Turkey'>Turkey</option>
        <option value='Uganda'>Uganda</option>
        <option value='United Kingdom'>United Kingdom</option>
        <option value='Ukraine'>Ukraine</option>
        <option value='United Arab Erimates'>United Arab Emirates</option>
        <option value='United States of America'>United States of America</option>
        <option value='Uruguay'>Uruguay</option>
        <option value='Vatican City State'>Vatican City State</option>
        <option value='Venezuela'>Venezuela</option>
        <option value='Vietnam'>Vietnam</option>
        <option value='Zimbabwe'>Zimbabwe</option>
        </select>

        <br><br><?= txt('anodepublicacao') ?>:<br>
        <!-- <label for='year'>Ano:</label> -->
        <select name='year' id='year'>
        <?php
        if ($post['year'] == '0') echo "<option value='0' selected>" . txt('anodepublicacao') . "?</option>";
        $contador = date('Y') + 1;
        while ($contador>1882){
        $contador--;
        if ($post['year'] == $contador) echo "<option value=" . $contador . " selected>" . $contador . "</option>";
        }
        ?>
        <option value='0'><?= txt('anodepublicacao') ?>?</option>
        <?php 
        $contador = date('Y') + 1;
        while ($contador>1882){
        $contador--;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
        }
        ?>
        </select>

        <br><br><?= txt('mesdepublicacao') ?>:<br>
        <!-- <label for='month'>Mês:</label> -->
        <select name='month' id='month'>
        <?php
        if ($post['month'] == '0') echo "<option value='0' selected>" . txt('mesdepublicacao') . "?</option>";
        if ($post['month'] == '1') echo "<option value='1' selected>" . txt('jan') . "</option>";
        if ($post['month'] == '2') echo "<option value='2' selected>" . txt('fev') . "</option>";
        if ($post['month'] == '3') echo "<option value='3' selected>" . txt('mar') . "</option>";
        if ($post['month'] == '4') echo "<option value='4' selected>" . txt('abr') . "</option>";
        if ($post['month'] == '5') echo "<option value='5' selected>" . txt('mai') . "</option>";
        if ($post['month'] == '6') echo "<option value='6' selected>" . txt('jun') . "</option>";
        if ($post['month'] == '7') echo "<option value='7' selected>" . txt('jul') . "</option>";
        if ($post['month'] == '8') echo "<option value='8' selected>" . txt('ago') . "</option>";
        if ($post['month'] == '9') echo "<option value='9' selected>" . txt('set') . "</option>";
        if ($post['month'] == '10') echo "<option value='10' selected>" . txt('out') . "</option>";
        if ($post['month'] == '11') echo "<option value='11' selected>" . txt('nov') . "</option>";
        if ($post['month'] == '12') echo "<option value='12' selected>" . txt('dez') . "</option>";
        ?>
        <option value='0'><?= txt('mesdepublicacao') ?>?</option>
        <option value='1'><?= txt('jan') ?></option>
        <option value='2'><?= txt('fev') ?></option>
        <option value='3'><?= txt('mar') ?></option>
        <option value='4'><?= txt('abr') ?></option>
        <option value='5'><?= txt('mai') ?></option>
        <option value='6'><?= txt('jun') ?></option>
        <option value='7'><?= txt('jul') ?></option>
        <option value='8'><?= txt('ago') ?></option>
        <option value='9'><?= txt('set') ?></option>
        <option value='10'><?= txt('out') ?></option>
        <option value='11'><?= txt('nov') ?></option>
        <option value='12'><?= txt('dez') ?></option>
        </select>

        <br><br><?= txt('edimpressaoudig') ?>?<br>
        <!-- <label for='digital'>Impresso ou digital?:</label> -->
        <select name='digital' id='digital'>
        <?php
        if ($post['digital'] == '0') echo "<option value='0' selected>" . txt('edimpressaoudig') . "?</option>";
        if ($post['digital'] == '1') echo "<option value='1' selected>" . txt('impressa') . "</option>";
        if ($post['digital'] == '2') echo "<option value='2' selected>Digital</option>";
        ?>
        <option value='0'><?= txt('edimpressaoudig') ?>?</option>
        <option value='1'><?= txt('impressa') ?></option>
        <option value='2'>Digital</option>
        </select>

        <br><br><?= txt('paginas') ?>:<br>
        <div id='lpages' class='ct'></div>
        <?php if ($post['pages'] == 0) { ?>
        <input onkeyup='statosdotcom_Count(this,4);' type='tel' name='pages' id='pages' placeholder='<?= txt('paginas') ?>' maxlength='4' onChange="this.value=this.value.replace(/[^0-9]+/g, '');"> <!-- regex refuses everything but numbers -->
        <?php } else { ?>
        <input onkeyup='statosdotcom_Count(this,4);' type='tel' name='pages' id='pages' value='<?= $post['pages'] ?>' placeholder='<?= txt('paginas') ?>' maxlength='4' onChange="this.value=this.value.replace(/[^0-9]+/g, '');"> <!-- regex refuses everything but numbers -->
        <?php } ?>

        <br><br>ISBN:<br>
        <div id='lisbn' class='ct'></div>
        <?php if ($post['isbn'] == 0) { ?>
        <input onkeyup='statosdotcom_Count(this,13);' type='tel' name='isbn' id='isbn' placeholder='ISBN' maxlength='13' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">
        <?php } else { ?>
        <input onkeyup='statosdotcom_Count(this,13);' type='tel' name='isbn' id='isbn' value='<?= $post['isbn'] ?>' placeholder='ISBN' maxlength='13' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">
        <?php } ?>

        <br><br><?= txt('largura') ?> (cm.):<br>
        <div id='lwidth' class='ct'></div>
        <?php if ($post['width'] == 0) { ?>
        <input onkeyup='statosdotcom_Count(this,2);' type='tel' name='width' id='width' placeholder='<?= txt('largura') ?>' maxlength='2' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">
        <?php } else { ?>
        <input onkeyup='statosdotcom_Count(this,2);' type='tel' name='width' id='width' value='<?= $post['width'] ?>' placeholder='<?= txt('largura') ?>' maxlength='2' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">
        <?php } ?>

        <br><br><?= txt('altura') ?> (cm.):<br>
        <div id='lheight' class='ct'></div>
        <?php if ($post['height'] == 0) { ?>
        <input onkeyup='statosdotcom_Count(this,2);' type='tel' name='height' id='height' placeholder='<?= txt('altura') ?>' maxlength='2' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">
        <?php } else { ?>
        <input onkeyup='statosdotcom_Count(this,2);' type='tel' name='height' id='height' value='<?= $post['height'] ?>' placeholder='<?= txt('altura') ?>' maxlength='2' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">
        <?php } ?>

        <br><br><?= txt('encadernacao') ?>?<br>
        <!-- <label for='paperback'>Capa Dura:</label> -->
        <select name='paperback' id='paperback'>
        <?php
        if ($post['paperback'] == 0) echo "<option value=0 selected>" . txt('encadernacao') . "?</option>";
        if ($post['paperback'] == 1) echo "<option value=1 selected>" . txt('capadura') . "</option>";
        if ($post['paperback'] == 2) echo "<option value=2 selected>" . txt('brochura') . "</option>";
        ?>
        <option value=0><?= txt('encadernacao') ?>?</option>
        <option value=1><?= txt('capadura') ?></option>
        <option value=2><?= txt('brochura') ?></option>
        </select>

        <br><br><?= txt('haexlibris') ?>?<sup><a href="javascript:alert('MESICON\n\nLogomarca do proprietário do livro.\n\nKind of logo from the book\'s owner.');">&#9432;&nbsp;</a></sup><br>
        <!-- <label for='exlibris'>Apresenta ex-libris do proprietário?</label> -->
        <select name='exlibris' id='exlibris'>
        <?php
        if ($post['exlibris'] == 0) echo "<option value=0 selected>" . txt('haexlibris') . "?</option>";
        if ($post['exlibris'] == 1) echo "<option value=1 selected>" . txt('sim') . "</option>";
        if ($post['exlibris'] == 2) echo "<option value=2 selected>" . txt('nao') . "</option>";
        ?>
        <option value=0><?= txt('haexlibris') ?>?</option>
        <option value=1><?= txt('sim') ?></option>
        <option value=2><?= txt('nao') ?></option>
        </select>

        <br><br><?= txt('idioma') ?>:<br>
        <!-- <label for='idiom'>Idioma:</label> -->
        <select id='idiom' name='idiom'>
        <?php
        if ($post['idiom'] == '0') echo "<option value='0' selected>" . txt('idioma') . "?</option>";
        if ($post['idiom'] == 'pt') echo "<option value='pt' selected>Português</option>";
        if ($post['idiom'] == 'af') echo "<option value='af' selected>Afrikaans</option>";
        if ($post['idiom'] == 'sq') echo "<option value='sq' selected>Albanian</option>";
        if ($post['idiom'] == 'ar') echo "<option value='ar' selected>Arabic</option>";
        if ($post['idiom'] == 'hy') echo "<option value='hy' selected>Armenian</option>";
        if ($post['idiom'] == 'az') echo "<option value='az' selected>Azerbaijani</option>";
        if ($post['idiom'] == 'eu') echo "<option value='eu' selected>Basque</option>";
        if ($post['idiom'] == 'be') echo "<option value='be' selected>Belarusian</option>";
        if ($post['idiom'] == 'bs') echo "<option value='bs' selected>Bosnian</option>";
        if ($post['idiom'] == 'bg') echo "<option value='bg' selected>Bulgarian</option>";
        if ($post['idiom'] == 'ca') echo "<option value='ca' selected>Catalan</option>";
        if ($post['idiom'] == 'zh') echo "<option value='zh' selected>Chinese</option>";
        if ($post['idiom'] == 'hr') echo "<option value='hr' selected>Croatian</option>";
        if ($post['idiom'] == 'cs') echo "<option value='cs' selected>Czech</option>";
        if ($post['idiom'] == 'da') echo "<option value='da' selected>Danish</option>";
        if ($post['idiom'] == 'nl') echo "<option value='nl' selected>Dutch</option>";
        if ($post['idiom'] == 'en') echo "<option value='en' selected>English</option>";
        if ($post['idiom'] == 'eo') echo "<option value='eo' selected>Esperanto</option>";
        if ($post['idiom'] == 'et') echo "<option value='et' selected>Estonian</option>";
        if ($post['idiom'] == 'fl') echo "<option value='fl' selected>Filipino</option>";
        if ($post['idiom'] == 'fi') echo "<option value='fi' selected>Finnish</option>";
        if ($post['idiom'] == 'fr') echo "<option value='fr' selected>French</option>";
        if ($post['idiom'] == 'de') echo "<option value='de' selected>German</option>";
        if ($post['idiom'] == 'el') echo "<option value='el' selected>Greek</option>";
        if ($post['idiom'] == 'gn') echo "<option value='gn' selected>Guarani</option>";
        if ($post['idiom'] == 'hn') echo "<option value='hn' selected>Hawaiian</option>";
        if ($post['idiom'] == 'he') echo "<option value='he' selected>Hebrew</option>";
        if ($post['idiom'] == 'hi') echo "<option value='hi' selected>Hindi</option>";
        if ($post['idiom'] == 'hu') echo "<option value='hu' selected>Hungarian</option>";
        if ($post['idiom'] == 'is') echo "<option value='is' selected>Icelandic</option>";
        if ($post['idiom'] == 'id') echo "<option value='id' selected>Indonesian</option>";
        if ($post['idiom'] == 'ga') echo "<option value='ga' selected>Irish</option>";
        if ($post['idiom'] == 'it') echo "<option value='it' selected>Italian</option>";
        if ($post['idiom'] == 'ja') echo "<option value='ja' selected>Japanese</option>";
        if ($post['idiom'] == 'kk') echo "<option value='kk' selected>Kazakh</option>";
        if ($post['idiom'] == 'ko') echo "<option value='ko' selected>Korean</option>";
        if ($post['idiom'] == 'la') echo "<option value='la' selected>Latin</option>";
        if ($post['idiom'] == 'lv') echo "<option value='lv' selected>Latvian</option>";
        if ($post['idiom'] == 'lt') echo "<option value='lt' selected>Lithuanian</option>";
        if ($post['idiom'] == 'mk') echo "<option value='mk' selected>Macedonian</option>";
        if ($post['idiom'] == 'ms') echo "<option value='ms' selected>Malay</option>";
        if ($post['idiom'] == 'mt') echo "<option value='mt' selected>Maltese</option>";
        if ($post['idiom'] == 'mn') echo "<option value='mn' selected>Mongolian</option>";
        if ($post['idiom'] == 'ne') echo "<option value='ne' selected>Nepali</option>";
        if ($post['idiom'] == 'no') echo "<option value='no' selected>Norwegian</option>";
        if ($post['idiom'] == 'fa') echo "<option value='fa' selected>Persian</option>";
        if ($post['idiom'] == 'pl') echo "<option value='pl' selected>Polish</option>";
        if ($post['idiom'] == 'pt') echo "<option value='pt' selected>Português</option>";
        if ($post['idiom'] == 'pa') echo "<option value='pa' selected>Punjabi</option>";
        if ($post['idiom'] == 'qu') echo "<option value='qu' selected>Quechua</option>";
        if ($post['idiom'] == 'ro') echo "<option value='ro' selected>Romanian</option>";
        if ($post['idiom'] == 'rm') echo "<option value='rm' selected>Romansh</option>";
        if ($post['idiom'] == 'ru') echo "<option value='ru' selected>Russian</option>";
        if ($post['idiom'] == 'gd') echo "<option value='gd' selected>Scottish Gaelic</option>";
        if ($post['idiom'] == 'sr') echo "<option value='sr' selected>Serbian</option>";
        if ($post['idiom'] == 'sk') echo "<option value='sk' selected>Slovak</option>";
        if ($post['idiom'] == 'sl') echo "<option value='sl' selected>Slovenian</option>";
        if ($post['idiom'] == 'es') echo "<option value='es' selected>Spanish</option>";
        if ($post['idiom'] == 'su') echo "<option value='su' selected>Sundanese</option>";
        if ($post['idiom'] == 'sw') echo "<option value='sw' selected>Swahili</option>";
        if ($post['idiom'] == 'sv') echo "<option value='sv' selected>Swedish</option>";
        if ($post['idiom'] == 'th') echo "<option value='th' selected>Thai</option>";
        if ($post['idiom'] == 'tp') echo "<option value='tp' selected>Tupi</option>";
        if ($post['idiom'] == 'tr') echo "<option value='tr' selected>Turkish</option>";
        if ($post['idiom'] == 'uk') echo "<option value='uk' selected>Ukrainian</option>";
        if ($post['idiom'] == 'uz') echo "<option value='uz' selected>Uzbek</option>";
        if ($post['idiom'] == 'vi') echo "<option value='vi' selected>Vietnamese</option>";
        if ($post['idiom'] == 'cy') echo "<option value='cy' selected>Welsh</option>";
        if ($post['idiom'] == 'yi') echo "<option value='yi' selected>Yiddish</option>";
        if ($post['idiom'] == 'yo') echo "<option value='yo' selected>Yoruba</option>";
        if ($post['idiom'] == 'zu') echo "<option value='zu' selected>Zulu</option>";
        ?>
        <option value='0'><?= txt('idioma') ?>?</option>
        <option value='pt'>Português</option>
        <option value='af'>Afrikaans</option>
        <option value='sq'>Albanian</option>
        <option value='ar'>Arabic</option>
        <option value='hy'>Armenian</option>
        <option value='az'>Azerbaijani</option>
        <option value='eu'>Basque</option>
        <option value='be'>Belarusian</option>
        <option value='bs'>Bosnian</option>
        <option value='bg'>Bulgarian</option>
        <option value='ca'>Catalan</option>
        <option value='zh'>Chinese</option>
        <option value='hr'>Croatian</option>
        <option value='cs'>Czech</option>
        <option value='da'>Danish</option>
        <option value='nl'>Dutch</option>
        <option value='en'>English</option>
        <option value='eo'>Esperanto</option>
        <option value='et'>Estonian</option>
        <option value='fl'>Filipino</option>
        <option value='fi'>Finnish</option>
        <option value='fr'>French</option>
        <option value='de'>German</option>
        <option value='el'>Greek</option>
        <option value='gn'>Guarani</option>
        <option value='hn'>Hawaiian</option>
        <option value='he'>Hebrew</option>
        <option value='hi'>Hindi</option>
        <option value='hu'>Hungarian</option>
        <option value='is'>Icelandic</option>
        <option value='id'>Indonesian</option>
        <option value='ga'>Irish</option>
        <option value='it'>Italian</option>
        <option value='ja'>Japanese</option>
        <option value='kk'>Kazakh</option>
        <option value='ko'>Korean</option>
        <option value='la'>Latin</option>
        <option value='lv'>Latvian</option>
        <option value='lt'>Lithuanian</option>
        <option value='mk'>Macedonian</option>
        <option value='ms'>Malay</option>
        <option value='mt'>Maltese</option>
        <option value='mn'>Mongolian</option>
        <option value='ne'>Nepali</option>
        <option value='no'>Norwegian</option>
        <option value='fa'>Persian</option>
        <option value='pl'>Polish</option>
        <option value='pt'>Português</option>
        <option value='pa'>Punjabi</option>
        <option value='qu'>Quechua</option>
        <option value='ro'>Romanian</option>
        <option value='rm'>Romansh</option>
        <option value='ru'>Russian</option>
        <option value='gd'>Scottish Gaelic</option>
        <option value='sr'>Serbian</option>
        <option value='sk'>Slovak</option>
        <option value='sl'>Slovenian</option>
        <option value='es'>Spanish</option>
        <option value='su'>Sundanese</option>
        <option value='sw'>Swahili</option>
        <option value='sv'>Swedish</option>
        <option value='th'>Thai</option>
        <option value='tp'>Tupi</option>
        <option value='tr'>Turkish</option>
        <option value='uk'>Ukrainian</option>
        <option value='uz'>Uzbek</option>
        <option value='vi'>Vietnamese</option>
        <option value='cy'>Welsh</option>
        <option value='yi'>Yiddish</option>
        <option value='yo'>Yoruba</option>
        <option value='zu'>Zulu</option>
        </select>

        <br><br><?= txt('tradutor') ?>:<br>
        <div id='ltranslator' class='ct'></div>
        <?php
        if ($post['translator'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='translator' id='translator' placeholder='" . txt('tradutor') . "' maxlength='99'>";
        else echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='translator' id='translator' value='" . $post['translator'] . "' placeholder='" . txt('tradutor') . "' maxlength='99'>";
        ?>

        <br><br><?= txt('outroidioma') ?>:<br>
        <div id='lmore_idioms' class='ct'></div>
        <?php
        if ($post['more_idioms'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' name='more_idioms' id='more_idioms' placeholder='" . txt('outroidioma') . "' maxlength='199'>";
        else echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' name='more_idioms' id='more_idioms' value='" . $post['more_idioms'] . "' placeholder='" . txt('outroidioma') . "' maxlength='199'>";
        ?>

        <br><br><?= txt('dedicatoriaimpressa') ?>?<br>
        <div id='lprinted_dedication' class='ct'></div>
        <textarea onkeyup='statosdotcom_Count(this,65535);' name='printed_dedication' id='printed_dedication' rows=5 placeholder="<?= txt('dedicatoriaimpressa') ?>" maxlength=65535><?php if ($post['printed_dedication'] != "" && $post['printed_dedication'] != 0) echo $post['printed_dedication']; ?></textarea>

        <br><br><?= txt('haprefaciador') ?>:<br>
        <div id='lpreface' class='ct'></div>
        <?php
        if ($post['preface'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='preface' id='preface' placeholder='" . txt('haprefaciador') . "' maxlength='99'>";
        else echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='preface' id='preface' value='" . $post['preface'] . "' placeholder='" . txt('haprefaciador') . "' maxlength='99'>";
        ?>

        <br><br><?= txt('hamanuscrito') ?>?<br>
        <!-- <label for='manuscript'>Apresenta dedicatória manuscrita, anotações, marginália?</label> -->
        <select name='manuscript' id='manuscript'>
        <?php if ($id != 0):
        if ($post['manuscript'] == 0) echo "<option value=0 selected>" . txt('manuscrito') . "?</option>";
        if ($post['manuscript'] == 1) echo "<option value=1 selected>" . txt('sim') . "</option>";
        if ($post['manuscript'] == 2) echo "<option value=2 selected>" . txt('nao') . "</option>";
        endif ?>
        <option value=0><?= txt('manuscrito') ?>?</option>
        <option value=1><?= txt('sim') ?></option>
        <option value=2><?= txt('nao') ?></option>
        </select>

        <!-- TODO: manuscript dedication - transcript here or go to the manuscript area - think how to do it -->

        <br><br><?= txt('hailustracapa') ?>?<br>
        <div id='lfront_illustrator' class='ct'></div>
        <?php
        if ($post['front_illustrator'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='front_illustrator' id='front_illustrator' placeholder='" . txt('hailustracapa') . "' maxlength='99'>";
        else echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='front_illustrator' id='front_illustrator' value='" . $post['front_illustrator'] . "' placeholder='" . txt('hailustracapa') . "' maxlength='99'>";
        ?>

        <br><br><?= txt('hailustrainterno') ?>?<br>
        <div id='linside_illustrator' class='ct'></div>
        <?php
        if ($post['inside_illustrator'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='inside_illustrator' id='inside_illustrator' placeholder='" . txt('hailustrainterno') . "' maxlength='99'>";
        else echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='inside_illustrator' id='inside_illustrator' value='" . $post['inside_illustrator'] . "' placeholder='" . txt('hailustrainterno') . "' maxlength='99'>";
        ?>

        <br><br><?= txt('haprimaaba') ?>?<br>
        <div id='lfirst_ear' class='ct'></div>
        <textarea input onkeyup='statosdotcom_Count(this,65535);' name='first_ear' id='first_ear' rows=5 placeholder='<?= txt('haprimaaba') ?>' maxlength=65535><?php if ($post['first_ear'] != "" && $post['first_ear'] != 0) echo $post['first_ear']; ?></textarea>

        <br><br><?= txt('hasegundaaba') ?>?<br>
        <div id='lsecond_ear' class='ct'></div>
        <textarea input onkeyup='statosdotcom_Count(this,65535);' name='second_ear' id='second_ear' rows=5 placeholder='<?= txt('hasegundaaba') ?>' maxlength=65535><?php if ($post['second_ear'] != "" && $post['second_ear'] != 0) echo $post['second_ear']; ?></textarea>

        <br><br><?= txt('haverso') ?>?<br>
        <div id='lback' class='ct'></div>
        <textarea input onkeyup='statosdotcom_Count(this,65535);' name='back' id='back' rows=5 placeholder='<?= txt('haverso') ?>' maxlength=65535><?php if ($post['back'] != "" && $post['back'] != 0) echo $post['back']; ?></textarea>

        <br><br><?= txt('notadapesquisa') ?>:<br>
        <div id='ladd_info' class='ct'></div>
        <textarea input onkeyup='statosdotcom_Count(this,65535);' name='add_info' id='add_info' rows=20 placeholder='<?= txt('notapesqtxt') ?>.' maxlength=65535><?php if ($post['add_info'] != "0" && strlen($post['add_info']) > 2) echo $post['add_info']; ?></textarea>
        
        <br>