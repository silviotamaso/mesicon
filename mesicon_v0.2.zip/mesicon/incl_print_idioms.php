<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<?php if ($id != 0):
if ($idiom == "0") echo "<option value='0' selected>Idiom/Idioma?</option>";
if ($idiom == "pt") echo "<option value='pt' selected>Português</option>";
if ($idiom == "af") echo "<option value='af' selected>Afrikaans</option>";
if ($idiom == "sq") echo "<option value='sq' selected>Albanian</option>";
if ($idiom == "ar") echo "<option value='ar' selected>Arabic</option>";
if ($idiom == "hy") echo "<option value='hy' selected>Armenian</option>";
if ($idiom == "az") echo "<option value='az' selected>Azerbaijani</option>";
if ($idiom == "eu") echo "<option value='eu' selected>Basque</option>";
if ($idiom == "be") echo "<option value='be' selected>Belarusian</option>";
if ($idiom == "bs") echo "<option value='bs' selected>Bosnian</option>";
if ($idiom == "bg") echo "<option value='bg' selected>Bulgarian</option>";
if ($idiom == "ca") echo "<option value='ca' selected>Catalan</option>";
if ($idiom == "zh") echo "<option value='zh' selected>Chinese</option>";
if ($idiom == "hr") echo "<option value='hr' selected>Croatian</option>";
if ($idiom == "cs") echo "<option value='cs' selected>Czech</option>";
if ($idiom == "da") echo "<option value='da' selected>Danish</option>";
if ($idiom == "nl") echo "<option value='nl' selected>Dutch</option>";
if ($idiom == "en") echo "<option value='en' selected>English</option>";
if ($idiom == "eo") echo "<option value='eo' selected>Esperanto</option>";
if ($idiom == "et") echo "<option value='et' selected>Estonian</option>";
if ($idiom == "fl") echo "<option value='fl' selected>Filipino</option>";
if ($idiom == "fi") echo "<option value='fi' selected>Finnish</option>";
if ($idiom == "fr") echo "<option value='fr' selected>French</option>";
if ($idiom == "de") echo "<option value='de' selected>German</option>";
if ($idiom == "el") echo "<option value='el' selected>Greek</option>";
if ($idiom == "gn") echo "<option value='gn' selected>Guarani</option>";
if ($idiom == "hn") echo "<option value='hn' selected>Hawaiian</option>";
if ($idiom == "he") echo "<option value='he' selected>Hebrew</option>";
if ($idiom == "hi") echo "<option value='hi' selected>Hindi</option>";
if ($idiom == "hu") echo "<option value='hu' selected>Hungarian</option>";
if ($idiom == "is") echo "<option value='is' selected>Icelandic</option>";
if ($idiom == "id") echo "<option value='id' selected>Indonesian</option>";
if ($idiom == "ga") echo "<option value='ga' selected>Irish</option>";
if ($idiom == "it") echo "<option value='it' selected>Italian</option>";
if ($idiom == "ja") echo "<option value='ja' selected>Japanese</option>";
if ($idiom == "kk") echo "<option value='kk' selected>Kazakh</option>";
if ($idiom == "ko") echo "<option value='ko' selected>Korean</option>";
if ($idiom == "la") echo "<option value='la' selected>Latin</option>";
if ($idiom == "lv") echo "<option value='lv' selected>Latvian</option>";
if ($idiom == "lt") echo "<option value='lt' selected>Lithuanian</option>";
if ($idiom == "mk") echo "<option value='mk' selected>Macedonian</option>";
if ($idiom == "ms") echo "<option value='ms' selected>Malay</option>";
if ($idiom == "mt") echo "<option value='mt' selected>Maltese</option>";
if ($idiom == "mn") echo "<option value='mn' selected>Mongolian</option>";
if ($idiom == "ne") echo "<option value='ne' selected>Nepali</option>";
if ($idiom == "no") echo "<option value='no' selected>Norwegian</option>";
if ($idiom == "fa") echo "<option value='fa' selected>Persian</option>";
if ($idiom == "pl") echo "<option value='pl' selected>Polish</option>";
if ($idiom == "pt") echo "<option value='pt' selected>Português</option>";
if ($idiom == "pa") echo "<option value='pa' selected>Punjabi</option>";
if ($idiom == "qu") echo "<option value='qu' selected>Quechua</option>";
if ($idiom == "ro") echo "<option value='ro' selected>Romanian</option>";
if ($idiom == "rm") echo "<option value='rm' selected>Romansh</option>";
if ($idiom == "ru") echo "<option value='ru' selected>Russian</option>";
if ($idiom == "gd") echo "<option value='gd' selected>Scottish Gaelic</option>";
if ($idiom == "sr") echo "<option value='sr' selected>Serbian</option>";
if ($idiom == "sk") echo "<option value='sk' selected>Slovak</option>";
if ($idiom == "sl") echo "<option value='sl' selected>Slovenian</option>";
if ($idiom == "es") echo "<option value='es' selected>Spanish</option>";
if ($idiom == "su") echo "<option value='su' selected>Sundanese</option>";
if ($idiom == "sw") echo "<option value='sw' selected>Swahili</option>";
if ($idiom == "sv") echo "<option value='sv' selected>Swedish</option>";
if ($idiom == "th") echo "<option value='th' selected>Thai</option>";
if ($idiom == "tp") echo "<option value='tp' selected>Tupi</option>";
if ($idiom == "tr") echo "<option value='tr' selected>Turkish</option>";
if ($idiom == "uk") echo "<option value='uk' selected>Ukrainian</option>";
if ($idiom == "uz") echo "<option value='uz' selected>Uzbek</option>";
if ($idiom == "vi") echo "<option value='vi' selected>Vietnamese</option>";
if ($idiom == "cy") echo "<option value='cy' selected>Welsh</option>";
if ($idiom == "yi") echo "<option value='yi' selected>Yiddish</option>";
if ($idiom == "yo") echo "<option value='yo' selected>Yoruba</option>";
if ($idiom == "zu") echo "<option value='zu' selected>Zulu</option>";
endif ?>

<option value="0">Idiom/Idioma?</option>
<option value="pt">Português</option>
<option value="af">Afrikaans</option>
<option value="sq">Albanian</option>
<option value="ar">Arabic</option>
<option value="hy">Armenian</option>
<option value="az">Azerbaijani</option>
<option value="eu">Basque</option>
<option value="be">Belarusian</option>
<option value="bs">Bosnian</option>
<option value="bg">Bulgarian</option>
<option value="ca">Catalan</option>
<option value="zh">Chinese</option>
<option value="hr">Croatian</option>
<option value="cs">Czech</option>
<option value="da">Danish</option>
<option value="nl">Dutch</option>
<option value="en">English</option>
<option value="eo">Esperanto</option>
<option value="et">Estonian</option>
<option value="fl">Filipino</option>
<option value="fi">Finnish</option>
<option value="fr">French</option>
<option value="de">German</option>
<option value="el">Greek</option>
<option value="gn">Guarani</option>
<option value="hn">Hawaiian</option>
<option value="he">Hebrew</option>
<option value="hi">Hindi</option>
<option value="hu">Hungarian</option>
<option value="is">Icelandic</option>
<option value="id">Indonesian</option>
<option value="ga">Irish</option>
<option value="it">Italian</option>
<option value="ja">Japanese</option>
<option value="kk">Kazakh</option>
<option value="ko">Korean</option>
<option value="la">Latin</option>
<option value="lv">Latvian</option>
<option value="lt">Lithuanian</option>
<option value="mk">Macedonian</option>
<option value="ms">Malay</option>
<option value="mt">Maltese</option>
<option value="mn">Mongolian</option>
<option value="ne">Nepali</option>
<option value="no">Norwegian</option>
<option value="fa">Persian</option>
<option value="pl">Polish</option>
<option value="pt">Português</option>
<option value="pa">Punjabi</option>
<option value="qu">Quechua</option>
<option value="ro">Romanian</option>
<option value="rm">Romansh</option>
<option value="ru">Russian</option>
<option value="gd">Scottish Gaelic</option>
<option value="sr">Serbian</option>
<option value="sk">Slovak</option>
<option value="sl">Slovenian</option>
<option value="es">Spanish</option>
<option value="su">Sundanese</option>
<option value="sw">Swahili</option>
<option value="sv">Swedish</option>
<option value="th">Thai</option>
<option value="tp">Tupi</option>
<option value="tr">Turkish</option>
<option value="uk">Ukrainian</option>
<option value="uz">Uzbek</option>
<option value="vi">Vietnamese</option>
<option value="cy">Welsh</option>
<option value="yi">Yiddish</option>
<option value="yo">Yoruba</option>
<option value="zu">Zulu</option>