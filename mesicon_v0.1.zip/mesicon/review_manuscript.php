<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

$randomDate = $_GET['c']; // if it coming from create_post(): received random as flag in updated_at (format unix datetime "yyyy-mm-dd hh:mm:ss")
$posts = getManuscript2Review($randomDate);

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON | Review Manuscript/Revisar Manuscrito</title>

<!-- TODO: validation does not work; disable register button after pressed and flag still not working -->

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->


<h1><?= txt('revisar') ?> <?= txt('manuscrito') ?></h1>

<script>
var _formConfirm_submitted = false; // with "onsubmit" help prevent multi post
function statosdotcomVai() {
    if ( _formConfirm_submitted == false ) {
        _formConfirm_submitted = true; 
        return true;
    } else {
        alert('MESICON\n\nAguarde/Wait...'); 
        return false; 
    }
}
</script>

<?php foreach ($posts as $post): ?>

<?php if (($_SESSION['user']['role'] == "Administrator") || ($_SESSION['user']['role'] == "Manager")) { ?>
    <form id="statosdotcomForm" method="post" action="" onsubmit="statosdotcomVai();">
<?php } ?>

<!-- validation errors for the form -->
<?php include('incl_errors.php') ?>
<?php include('incl_messages.php') ?>

<?php
// TODO: only the owner of the post or GOD can have access and edit/save
// $_SESSION['user']['id'];
// $_SESSION['user']['username'];
?>

<h4>

<input type="hidden" name="id" value="<?= $post['id'] ?>">
<input type="hidden" name="creator" value="<?= $post['creator'] ?>">
<input type="hidden" name="creator_id" value="<?= $post['creator_id'] ?>">
<input type="hidden" name="updated_at" value="<?= $randomDate ?>">    

<font color="#990000"><?= txt('autorman') ?>:<br></font>
<?php
echo $post['author'] . "<input type='hidden' name='author' value='" . $post['author'] . "'>";
?><br><br>

<font color="#990000"><?= txt('aspectoautor') ?>:<br></font>
<?php
if ($post['author_type'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='author_type' value='0'>";
if ($post['author_type'] == "1") echo txt('expresso') . "<input type='hidden' name='author_type' value='1'>";
if ($post['author_type'] == "2") echo txt('presumido') . "<input type='hidden' name='author_type' value='2'>";
?><br><br>

<font color="#990000"><?= txt('originalidade') ?>:<br></font>
<?php
if ($post['original'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='original' value='0'>";
if ($post['original'] == "1") echo txt('originalidade') . " " . txt('expresso') . "<input type='hidden' name='original' value='1'>";
if ($post['original'] == "2") echo txt('copiaourep') . " " . txt('expresso') . "<input type='hidden' name='original' value='2'>";
if ($post['original'] == "3") echo txt('originalidade') . "/" . txt('copiaourep') . " " . txt('presumido') . "<input type='hidden' name='original' value='3'>";
?><br><br>

<font color="#990000"><?= txt('copiadetalhe') ?>:<br></font>
<?php
if ($post['copy'] == "" || $post['copy'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='copy' value='0'>";
else echo $post['copy'] . "<input type='hidden' name='copy' value='" . $post['copy'] . "'>";
?><br><br>

<font color="#990000"><?= txt('titulo') ?>:<br></font>
<?php
if ($post['title'] == "" || $post['title'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='title' value='0'>";
else echo $post['title'] . "<input type='hidden' name='title' value='" . $post['title'] . "'>";
?><br><br>

<font color="#990000"><?= txt('aspectotitulo') ?>:<br></font>
<?php
if ($post['title_type'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='title_type' value='0'>";
if ($post['title_type'] == "1") echo txt('expresso') . "<input type='hidden' name='title_type' value='1'>";
if ($post['title_type'] == "2") echo txt('presumido') . "<input type='hidden' name='title_type' value='2'>";
?><br><br>

<font color="#990000"><?= txt('autorsign') ?>:<br></font>
<?php
if ($post['signature'] == "" || $post['signature'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='signature' value='0'>";
else echo $post['signature'] . "<input type='hidden' name='signature' value='" . $post['signature'] . "'>";
?><br><br>

<font color="#990000"><?= txt('localorigem') ?>:<br></font>
<?php
if ($post['source_local'] == "" || $post['source_local'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='source_local' value='0'>";
else echo $post['source_local'] . "<input type='hidden' name='source_local' value='" . $post['source_local'] . "'>";
?><br><br>

<font color="#990000"><?= txt('aspectoorigem') ?>:<br></font>
<?php
if ($post['source_local_type'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='source_local_type' value='0'>";
if ($post['source_local_type'] == "1") echo txt('expresso') . "<input type='hidden' name='source_local_type' value='1'>";
if ($post['source_local_type'] == "2") echo txt('presumido') . "<input type='hidden' name='source_local_type' value='2'>";
?><br><br>

<font color="#990000"><?= txt('destinatario') ?>:<br></font>
<?php
if ($post['recipient'] == "" || $post['recipient'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='recipient' value='0'>";
else echo $post['recipient'] . "<input type='hidden' name='recipient' value='" . $post['recipient'] . "'>";
?><br><br>

<font color="#990000"><?= txt('aspectodestinatario') ?>:<br></font>
<?php
if ($post['recipient_type'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='recipient_type' value='0'>";
if ($post['recipient_type'] == "1") echo txt('expresso') . "<input type='hidden' name='recipient_type' value='1'>";
if ($post['recipient_type'] == "2") echo txt('presumido') . "<input type='hidden' name='recipient_type' value='2'>";
?><br><br>

<font color="#990000"><?= txt('localdestino') ?>:<br></font>
<?php
if ($post['destination'] == "" || $post['destination'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='destination' value='0'>";
else echo $post['destination'] . "<input type='hidden' name='destination' value='" . $post['destination'] . "'>";
?><br><br>

<font color="#990000"><?= txt('aspectodestino') ?>:<br></font>
<?php
if ($post['destination_type'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='destination_type' value='0'>";
if ($post['destination_type'] == "1") echo txt('expresso') . "<input type='hidden' name='destination_type' value='1'>";
if ($post['destination_type'] == "2") echo txt('presumido') . "<input type='hidden' name='destination_type' value='2'>";
?><br><br>

<font color="#990000"><?= txt('formatrata') ?>:<br></font>
<?php
if ($post['treatment'] == "" || $post['treatment'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='treatment' value='0'>";
else echo $post['treatment'] . "<input type='hidden' name='treatment' value='" . $post['treatment'] . "'>";
?><br><br>

<font color="#990000">Post scriptum:<br></font>
<?php
if ($post['postscript'] == "" || $post['postscript'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='postscript' value='0'>";
else echo $post['postscript'] . "<input type='hidden' name='postscript' value='" . $post['postscript'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('data') ?>: </font>
<?php
if ($post['data'] == "" || $post['data'] == '0000-00-00') echo txt('naoespecificado') . "<input type='hidden' name='data' value='0'>";
else echo $post['data'] . "<input type='hidden' name='data' value='" . $post['data'] . "'>";
?><br><br>

<font color="#990000"><?= txt('aspectodata') ?>: </font>
<?php
if ($post['data_type'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='data_type' value='0'>";
if ($post['data_type'] == "1") echo txt('expresso') . "<input type='hidden' name='data_type' value='1'>";
if ($post['data_type'] == "2") echo txt('presumido') . "<input type='hidden' name='data_type' value='2'>";
?><br><br>
    
<font color="#990000"><?= txt('idioma') ?>: </font>
<?php
if ($post['idiom'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='idiom' value='0'>";
else echo "<input type='hidden' name='idiom' value='" . $post['idiom'] . "'>";
printaidioma($post['idiom']);
?><br><br>

<font color="#990000"><?= txt('genero') ?>: </font>
<?php
if ($post['gender'] == '0') echo txt('naoespecificado');
if ($post['gender'] == '1') echo txt('bibliografico');
if ($post['gender'] == '2') echo txt('cartografico');
if ($post['gender'] == '3') echo txt('eletronico');
if ($post['gender'] == '4') echo txt('filmografico');
if ($post['gender'] == '5') echo txt('iconografico');
if ($post['gender'] == '6') echo txt('micrografico');
if ($post['gender'] == '7') echo txt('sonoro');
if ($post['gender'] == '8') echo "Textual</option>";
if ($post['gender'] == '9') echo txt('tridimensional');
?><br><br>

<font color="#990000"><?= txt('especie') ?>:<br></font>
<?php
if ($post['species'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='species' value='0'>";
if ($post['species'] == "1") echo "Abaixo-assinado<input type='hidden' name='species' value='1'>";
if ($post['species'] == "2") echo "Acordo<input type='hidden' name='species' value='2'>";
if ($post['species'] == "3") echo "Alvará<input type='hidden' name='species' value='3'>";
if ($post['species'] == "4") echo "Assento<input type='hidden' name='species' value='4'>";
if ($post['species'] == "5") echo "Ata<input type='hidden' name='species' value='5'>";
if ($post['species'] == "6") echo "Atestado<input type='hidden' name='species' value='6'>";
if ($post['species'] == "7") echo "Auto<input type='hidden' name='species' value='7'>";
if ($post['species'] == "8") echo "Aviso<input type='hidden' name='species' value='8'>";
if ($post['species'] == "9") echo "Bilhete<input type='hidden' name='species' value='9'>";
if ($post['species'] == "10") echo "Carta<input type='hidden' name='species' value='10'>";
if ($post['species'] == "11") echo "Carta aberta/Manifesto<input type='hidden' name='species' value='11'>";
if ($post['species'] == "12") echo "Cartão de visita<input type='hidden' name='species' value='12'>";
if ($post['species'] == "13") echo "Cartão de ponto<input type='hidden' name='species' value='13'>";
if ($post['species'] == "14") echo "Cartaz<input type='hidden' name='species' value='14'>";
if ($post['species'] == "15") echo "Cédula de identidade<input type='hidden' name='species' value='15'>";
if ($post['species'] == "16") echo "Certidão<input type='hidden' name='species' value='16'>";
if ($post['species'] == "17") echo "Certificado<input type='hidden' name='species' value='17'>";
if ($post['species'] == "18") echo "Cheque<input type='hidden' name='species' value='18'>";
if ($post['species'] == "19") echo "Circular<input type='hidden' name='species' value='19'>";
if ($post['species'] == "20") echo "Comunicação/Paper<input type='hidden' name='species' value='20'>";
if ($post['species'] == "21") echo "Comunicado<input type='hidden' name='species' value='21'>";
if ($post['species'] == "22") echo "Contrato<input type='hidden' name='species' value='22'>";
if ($post['species'] == "23") echo "Convenção<input type='hidden' name='species' value='23'>";
if ($post['species'] == "24") echo "Convite<input type='hidden' name='species' value='24'>";
if ($post['species'] == "25") echo "Convocação<input type='hidden' name='species' value='25'>";
if ($post['species'] == "26") echo "Cópia autêntica<input type='hidden' name='species' value='26'>";
if ($post['species'] == "27") echo "Crachá<input type='hidden' name='species' value='27'>";
if ($post['species'] == "28") echo "Currículo<input type='hidden' name='species' value='28'>";
if ($post['species'] == "29") echo "Declaração<input type='hidden' name='species' value='29'>";
if ($post['species'] == "30") echo "Decreto<input type='hidden' name='species' value='30'>";
if ($post['species'] == "31") echo "Depoimento<input type='hidden' name='species' value='31'>";
if ($post['species'] == "32") echo "Despacho<input type='hidden' name='species' value='32'>";
if ($post['species'] == "33") echo "Diário<input type='hidden' name='species' value='33'>";
if ($post['species'] == "34") echo "Diploma<input type='hidden' name='species' value='34'>";
if ($post['species'] == "35") echo "Dissertação<input type='hidden' name='species' value='35'>";
if ($post['species'] == "36") echo "Dossiê<input type='hidden' name='species' value='36'>";
if ($post['species'] == "37") echo "Edital<input type='hidden' name='species' value='37'>";
if ($post['species'] == "38") echo "Ementa<input type='hidden' name='species' value='38'>";
if ($post['species'] == "39") echo "Escritura<input type='hidden' name='species' value='39'>";
if ($post['species'] == "40") echo "Estatuto<input type='hidden' name='species' value='40'>";
if ($post['species'] == "41") echo "Expediente<input type='hidden' name='species' value='41'>";
if ($post['species'] == "42") echo "Estrato<input type='hidden' name='species' value='42'>";
if ($post['species'] == "43") echo "Fatura<input type='hidden' name='species' value='43'>";
if ($post['species'] == "44") echo "Ficha<input type='hidden' name='species' value='44'>";
if ($post['species'] == "45") echo "Folheto/Folder/Prospecto<input type='hidden' name='species' value='45'>";
if ($post['species'] == "46") echo "Formulário<input type='hidden' name='species' value='46'>";
if ($post['species'] == "47") echo "Guia<input type='hidden' name='species' value='47'>";
if ($post['species'] == "48") echo "Histórico<input type='hidden' name='species' value='48'>";
if ($post['species'] == "49") echo "Informe<input type='hidden' name='species' value='49'>";
if ($post['species'] == "50") echo "Instrução<input type='hidden' name='species' value='50'>";
if ($post['species'] == "51") echo "Inventário<input type='hidden' name='species' value='51'>";
if ($post['species'] == "52") echo "Laudo<input type='hidden' name='species' value='52'>";
if ($post['species'] == "53") echo "Layout<input type='hidden' name='species' value='53'>";
if ($post['species'] == "54") echo "Lei<input type='hidden' name='species' value='54'>";
if ($post['species'] == "55") echo "Lista/Listagem<input type='hidden' name='species' value='55'>";
if ($post['species'] == "56") echo "Livro<input type='hidden' name='species' value='56'>";
if ($post['species'] == "57") echo "Mapa<input type='hidden' name='species' value='57'>";
if ($post['species'] == "58") echo "Memorando<input type='hidden' name='species' value='58'>";
if ($post['species'] == "59") echo "Memória/Memorial<input type='hidden' name='species' value='59'>";
if ($post['species'] == "60") echo "Minuta<input type='hidden' name='species' value='60'>";
if ($post['species'] == "61") echo "Moção<input type='hidden' name='species' value='61'>";
if ($post['species'] == "62") echo "Norma<input type='hidden' name='species' value='62'>";
if ($post['species'] == "63") echo "Nota<input type='hidden' name='species' value='63'>";
if ($post['species'] == "64") echo "Ofício<input type='hidden' name='species' value='64'>";
if ($post['species'] == "65") echo "Orçamento<input type='hidden' name='species' value='65'>";
if ($post['species'] == "66") echo "Ordem de serviço<input type='hidden' name='species' value='66'>";
if ($post['species'] == "67") echo "Organograma<input type='hidden' name='species' value='67'>";
if ($post['species'] == "68") echo "Original/Rascunho<input type='hidden' name='species' value='68'>";
if ($post['species'] == "69") echo "Panfleto<input type='hidden' name='species' value='69'>";
if ($post['species'] == "70") echo "Papeleta<input type='hidden' name='species' value='70'>";
if ($post['species'] == "71") echo "Parecer<input type='hidden' name='species' value='71'>";
if ($post['species'] == "72") echo "Partilha<input type='hidden' name='species' value='72'>";
if ($post['species'] == "73") echo "Partitura<input type='hidden' name='species' value='73'>";
if ($post['species'] == "74") echo "Passaporte<input type='hidden' name='species' value='74'>";
if ($post['species'] == "75") echo "Pauta<input type='hidden' name='species' value='75'>";
if ($post['species'] == "76") echo "Petição<input type='hidden' name='species' value='76'>";
if ($post['species'] == "77") echo "Planilha<input type='hidden' name='species' value='77'>";
if ($post['species'] == "78") echo "Planta<input type='hidden' name='species' value='78'>";
if ($post['species'] == "79") echo "Portaria<input type='hidden' name='species' value='79'>";
if ($post['species'] == "80") echo "Processo<input type='hidden' name='species' value='80'>";
if ($post['species'] == "81") echo "Procuração<input type='hidden' name='species' value='81'>";
if ($post['species'] == "82") echo "Programa<input type='hidden' name='species' value='82'>";
if ($post['species'] == "83") echo "Projeto<input type='hidden' name='species' value='83'>";
if ($post['species'] == "84") echo "Prontuário<input type='hidden' name='species' value='84'>";
if ($post['species'] == "85") echo "Proposta<input type='hidden' name='species' value='85'>";
if ($post['species'] == "86") echo "Protocolo<input type='hidden' name='species' value='86'>";
if ($post['species'] == "87") echo "Prova<input type='hidden' name='species' value='87'>";
if ($post['species'] == "88") echo "Quadro<input type='hidden' name='species' value='88'>";
if ($post['species'] == "89") echo "Questionário<input type='hidden' name='species' value='89'>";
if ($post['species'] == "90") echo "Receita<input type='hidden' name='species' value='90'>";
if ($post['species'] == "91") echo "Recibo<input type='hidden' name='species' value='91'>";
if ($post['species'] == "92") echo "Recorte/Clip<input type='hidden' name='species' value='92'>";
if ($post['species'] == "93") echo "Recurso<input type='hidden' name='species' value='93'>";
if ($post['species'] == "94") echo "Regimento<input type='hidden' name='species' value='94'>";
if ($post['species'] == "95") echo "Registro<input type='hidden' name='species' value='95'>";
if ($post['species'] == "96") echo "Regulamento<input type='hidden' name='species' value='96'>";
if ($post['species'] == "97") echo "Relação/Rol<input type='hidden' name='species' value='97'>";
if ($post['species'] == "98") echo "Relatório<input type='hidden' name='species' value='98'>";
if ($post['species'] == "99") echo "Release/Press release<input type='hidden' name='species' value='99'>";
if ($post['species'] == "100") echo "Requerimento/Requisição<input type='hidden' name='species' value='100'>";
if ($post['species'] == "101") echo "Resolução<input type='hidden' name='species' value='101'>";
if ($post['species'] == "102") echo "Resumo<input type='hidden' name='species' value='102'>";
if ($post['species'] == "103") echo "Roteiro<input type='hidden' name='species' value='103'>";
if ($post['species'] == "104") echo "Sinopse<input type='hidden' name='species' value='104'>";
if ($post['species'] == "105") echo "Solicitação<input type='hidden' name='species' value='105'>";
if ($post['species'] == "106") echo "Tabela<input type='hidden' name='species' value='106'>";
if ($post['species'] == "107") echo "Telegrama<input type='hidden' name='species' value='107'>";
if ($post['species'] == "108") echo "Termo<input type='hidden' name='species' value='108'>";
if ($post['species'] == "109") echo "Tese<input type='hidden' name='species' value='109'>";
if ($post['species'] == "110") echo "TCC<input type='hidden' name='species' value='110'>";
if ($post['species'] == "111") echo "Título de crédito<input type='hidden' name='species' value='111'>";
if ($post['species'] == "112") echo "Vale<input type='hidden' name='species' value='112'>";
?><br><br>
    
<font color="#990000"><?= txt('tipodoc') ?>:<br></font>
<?php
if ($post['type'] == "" || $post['type'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='type' value='0'>";
else echo $post['type'] . "<input type='hidden' name='type' value='" . $post['type'] . "'>";
?><br><br> 
    
<font color="#990000"><?= txt('numitens') ?>: </font>
<?php
if ($post['items'] == "" || $post['items'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='items' value='0'>";
else echo $post['items'] . "<input type='hidden' name='items' value='" . $post['items'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('descricao') ?>:<br></font>
<?php
if ($post['description'] == "" || $post['description'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='description' value='0'>";
else echo $post['description'] . "<input type='hidden' name='description' value='" . $post['description'] . "'>";
?><br><br>

<font color="#990000"><?= txt('conteudo') ?>:<br></font>
<?php
if ($post['contents'] == "" || $post['contents'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='contents' value='0'>";
else echo $post['contents'] . "<input type='hidden' name='contents' value='" . $post['contents'] . "'>";
?><br><br> 
 
<font color="#990000"><?= txt('autografo') ?>?<br></font>
<?php
if ($post['autograph'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='autograph' value='0'>";   
if ($post['autograph'] == "1") echo txt('lapis') . "<input type='hidden' name='autograph' value='1'>";   
if ($post['autograph'] == "2") echo txt('canetaesf') . "<input type='hidden' name='autograph' value='2'>";   
if ($post['autograph'] == "3") echo txt('canetatint') . "<input type='hidden' name='autograph' value='3'>";   
?><br><br> 

<font color="#990000"><?= txt('coraut') ?>:<br></font>
<?php
if ($post['autograph_color'] == "" || $post['autograph_color'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='autograph_color' value='0'>";
else echo $post['autograph_color'] . "<input type='hidden' name='autograph_color' value='" . $post['autograph_color'] . "'>";
?><br><br> 
 
<font color="#990000"><?= txt('datiloscrito') ?>? (<?= txt('escritoamaq') ?>)?<br></font>
<?php
if ($post['typewritten'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='typewritten' value='0'>";
if ($post['typewritten'] == "1") echo txt('sim') . "<input type='hidden' name='typewritten' value='1'>";
if ($post['typewritten'] == "2") echo txt('nao') . "<input type='hidden' name='typewritten' value='2'>";
?><br><br>  

<font color="#990000"><?= txt('datiloscritocor') ?>:<br></font>
<?php
if ($post['typewritten_color'] == "" || $post['typewritten_color'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='typewritten_color' value='0'>";
else echo $post['typewritten_color'] . "<input type='hidden' name='typewritten_color' value='" . $post['typewritten_color'] . "'>";
?><br><br>

<font color="#990000"><?= txt('midia') ?>:<br></font>
<?php
if ($post['medium'] == "") echo txt('naoespecificado') . "<input type='hidden' name='medium' value=''>";
else echo $post['medium'] . "<input type='hidden' name='medium' value='" . $post['medium'] . "'>";
?><br><br>  

<font color="#990000"><?= txt('marcadagua') ?>?<br></font>
<?php
if ($post['watermark'] == "" || $post['watermark'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='watermark' value='0'>";
else echo $post['watermark'] . "<input type='hidden' name='watermark' value='" . $post['watermark'] . "'>";
?><br><br>

<font color="#990000"><?= txt('paginas') ?>: </font>
<?php
if ($post['pages'] == "" || $post['pages'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='pages' value='0'>";
else echo $post['pages'] . "<input type='hidden' name='pages' value='" . $post['pages'] . "'>";
?><br><br>

<font color="#990000"><?= txt('folhas') ?>: </font>
<?php
if ($post['leafs'] == "" || $post['leafs'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='leafs' value='0'>";
else echo $post['leafs'] . "<input type='hidden' name='leafs' value='" . $post['leafs'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('largura') ?> (cm.): </font>
<?php
if ($post['width'] == "" || $post['width'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='width' value='0'>";
else echo $post['width'] . "<input type='hidden' name='width' value='" . $post['width'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('altura') ?> (cm.): </font>
<?php
if ($post['height'] == "" || $post['height'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='height' value='0'>";
else echo $post['height'] . "<input type='hidden' name='height' value='" . $post['height'] . "'>";
?><br><br>

<font color="#990000"><?= txt('anexos') ?>:<br></font>
<?php
if ($post['anex'] == "" || $post['anex'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='anex' value='0'>";
else echo $post['anex'] . "<input type='hidden' name='anex' value='" . $post['anex'] . "'>";
?><br><br>

<font color="#990000"><?= txt('envelope') ?>?<br></font>
<?php
if ($post['envelope'] == "" || $post['envelope'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='envelope' value='0'>";
else echo $post['envelope'] . "<input type='hidden' name='envelope' value='" . $post['envelope'] . "'>";
?><br><br> 

<font color="#990000"><?= txt('selo') ?>?<br></font>
<?php
if ($post['stamp'] == "" || $post['stamp'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='stamp' value='0'>";
else echo $post['stamp'] . "<input type='hidden' name='stamp' value='" . $post['stamp'] . "'>";
?><br><br>      

<font color="#990000"><?= txt('carimbo') ?>?<br></font>
<?php
if ($post['imprint'] == "" || $post['imprint'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='imprint' value='0'>";
else echo $post['imprint'] . "<input type='hidden' name='imprint' value='" . $post['imprint'] . "'>";
?><br><br>      

<font color="#990000"><?= txt('datapost') ?>: </font>
<?php
if ($post['post'] == "" || $post['post'] == '0000-00-00') echo txt('naoespecificado') . "<input type='hidden' name='post' value='0'>";
else echo $post['post'] . "<input type='hidden' name='post' value='" . $post['post'] . "'>";
?><br><br>    

<font color="#990000"><?= txt('aspecdatapost') ?>: </font>
<?php
if ($post['post_type'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='post_type' value='0'>";
if ($post['post_type'] == "1") echo txt('expresso') . "<input type='hidden' name='post_type' value='1'>";
if ($post['post_type'] == "2") echo txt('presumido') . "<input type='hidden' name='post_type' value='2'>";
?><br><br>  

<font color="#990000"><?= txt('datarec') ?>: </font>
<?php
if ($post['receipt'] == "" || $post['receipt'] == '0000-00-00') echo txt('naoespecificado') . "<input type='hidden' name='receipt' value='0'>";
else echo $post['receipt'] . "<input type='hidden' name='receipt' value='" . $post['receipt'] . "'>";
?><br><br>    

<font color="#990000"><?= txt('aspecdatarec') ?>: </font>
<?php
if ($post['receipt_type'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='receipt_type' value='0'>";
if ($post['receipt_type'] == "1") echo txt('expresso') . "<input type='hidden' name='receipt_type' value='1'>";
if ($post['receipt_type'] == "2") echo txt('presumido') . "<input type='hidden' name='receipt_type' value='2'>";
?><br><br>   

<font color="#990000"><?= txt('portador') ?>?<br></font>
<?php
if ($post['carrier'] == "" || $post['carrier'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='carrier' value='0'>";
else echo $post['carrier'] . "<input type='hidden' name='carrier' value='" . $post['carrier'] . "'>";
?><br><br> 

<font color="#990000"><?= txt('emmaos') ?>? </font>
<?php
if ($post['in_hands'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='in_hands' value='0'>";
if ($post['in_hands'] == "1") echo txt('sim') . "<input type='hidden' name='in_hands' value='1'>";
if ($post['in_hands'] == "2") echo txt('nao') . "<input type='hidden' name='in_hands' value='2'>";
?><br><br>    

<font color="#990000"><?= txt('notadest') ?>:<br></font>
<?php
if ($post['notes_recipient'] == "" || $post['notes_recipient'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='notes_recipient' value='0'>";
else echo $post['notes_recipient'] . "<input type='hidden' name='notes_recipient' value='" . $post['notes_recipient'] . "'>";
?><br><br>   

<font color="#990000"><?= txt('notaterc') ?>:<br></font>
<?php
if ($post['notes_third'] == "" || $post['notes_third'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='notes_third' value='0'>";
else echo $post['notes_third'] . "<input type='hidden' name='notes_third' value='" . $post['notes_third'] . "'>";
?><br><br>    

<font color="#990000"><?= txt('conserva') ?>:<br></font>
<?php
if ($post['conservation'] == "0") echo txt('naoespecificado') . "<input type='hidden' name='conservation' value='0'>";
if ($post['conservation'] == "1") echo txt('conservab') . "<input type='hidden' name='conservation' value='1'>";
if ($post['conservation'] == "2") echo txt('conservar') . "<input type='hidden' name='conservation' value='2'>";
if ($post['conservation'] == "3") echo txt('conservam') . "<input type='hidden' name='conservation' value='3'>";
?><br><br> 

<font color="#990000"><?= txt('local') ?>:<br></font>
<?php
if ($post['address'] == "" || $post['address'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='address' value='0'>";
else echo $post['address'] . "<input type='hidden' name='address' value='" . $post['address'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('acervo') ?>?<br></font>
<?php
if ($post['collection'] == "" || $post['collection'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='collection' value='0'>";
else echo $post['collection'] . "<input type='hidden' name='collection' value='" . $post['collection'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('acervoref') ?>:<br></font>
<?php
if ($post['ref'] == "" || $post['ref'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='ref' value='0'>";
else echo $post['ref'] . "<input type='hidden' name='ref' value='" . $post['ref'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('onomastico') ?>:<br></font>
<?php
if ($post['onomastic'] == "" || $post['onomastic'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='onomastic' value='0'>";
else echo $post['onomastic'] . "<input type='hidden' name='onomastic' value='" . $post['onomastic'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('pseudo') ?>:<br></font>
<?php
if ($post['pseudonyms'] == "" || $post['pseudonyms'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='pseudonyms' value='0'>";
else echo $post['pseudonyms'] . "<input type='hidden' name='pseudonyms' value='" . $post['pseudonyms'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('livrosmen') ?>:<br></font>
<?php
if ($post['mentioned_works'] == "" || $post['mentioned_works'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='mentioned_works' value='0'>";
else echo $post['mentioned_works'] . "<input type='hidden' name='mentioned_works' value='" . $post['mentioned_works'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('jornais') ?>:<br></font>
<?php
if ($post['periodics'] == "" || $post['periodics'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='periodics' value='0'>";
else echo $post['periodics'] . "<input type='hidden' name='periodics' value='" . $post['periodics'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('proveniencia') ?>:<br></font>
<?php
if ($post['historic'] == "" || $post['historic'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='historic' value='0'>";
else echo $post['historic'] . "<input type='hidden' name='historic' value='" . $post['historic'] . "'>";
?><br><br>

<font color="#990000"><?= txt('formaacq') ?>:<br></font>
<?php
if ($post['acquisition'] == "") echo txt('naoespecificado') . "<input type='hidden' name='acquisition' value=''>";
else echo $post['acquisition'] . "<input type='hidden' name='acquisition' value='" . $post['acquisition'] . "'>";
?><br><br> 
    
<font color="#990000"><?= txt('dataacq') ?>: </font>
<?php
if ($post['acq_date'] == "" || $post['acq_date'] == '0000-00-00') echo txt('naoespecificado') . "<input type='hidden' name='acq_date' value='0'>";
else echo $post['acq_date'] . "<input type='hidden' name='acq_date' value='" . $post['acq_date'] . "'>";
?><br><br>
    
<font color="#990000"><?= txt('notadapesquisa') ?>:<br></font>
<?php
if ($post['add_info'] == "" || $post['add_info'] == 0) echo txt('naoespecificado') . "<input type='hidden' name='add_info' value='0'>";
else echo $post['add_info'] . "<input type='hidden' name='add_info' value='" . $post['add_info'] . "'>";
?><br><br>

</h4>

<?php endforeach; ?>

<?php if (($_SESSION['user']['role'] == "Administrator") || ($_SESSION['user']['role'] == "Manager")) { ?>
    <br>
    <button type="submit" class="btn" name="edit_manuscript" id="idBtnReview">&lt;&lt; <?= txt('corrigir_M') ?></button><br><br>
    <button type="submit" class="btn" name="update_manuscript_from_review" id="idBtnSend"><?= txt('gravar_M') ?> &gt;&gt;</button>
    </form>
<?php } ?>

<script>
<!--
var objForm = document.getElementById("statosdotcomForm");
objForm.addEventListener('submit', function (e) {
    var objBtnSend = document.getElementById('idBtnSend');
    objBtnSend.textContent = 'Aguarde/Wait...';
    objBtnSend.style = "color: #000000; background: #00ff00; cursor: not-allowed;";
    //objBtnSend.disabled = 'disabled'; // can't disable the button because without it the associated command don't go by POST (and this is needed). Going by GET can't make to work at the end.
    var objBtnReview = document.getElementById('idBtnReview');
    objBtnReview.textContent = 'Aguarde/Wait...';
    objBtnReview.style = "color: #000000; background: #00ff00; cursor: not-allowed;";
    //objBtnReview.disabled = 'disabled'; // can't disable the button because without it the associated command don't go by POST (and this is needed). Going by GET can't make to work at the end.
});
//-->
</script>

<?php
function printaidioma(string $i) {
if ($i == "0") echo txt('idioma');
if ($i == "af") echo "Afrikaans";
if ($i == "sq") echo "Albanian";
if ($i == "ar") echo "Arabic";
if ($i == "hy") echo "Armenian";
if ($i == "az") echo "Azerbaijani";
if ($i == "eu") echo "Basque";
if ($i == "be") echo "Belarusian";
if ($i == "bs") echo "Bosnian";
if ($i == "bg") echo "Bulgarian";
if ($i == "ca") echo "Catalan";
if ($i == "zh") echo "Chinese";
if ($i == "hr") echo "Croatian";
if ($i == "cs") echo "Czech";
if ($i == "da") echo "Danish";
if ($i == "nl") echo "Dutch";
if ($i == "en") echo "English";
if ($i == "eo") echo "Esperanto";
if ($i == "et") echo "Estonian";
if ($i == "fl") echo "Filipino";
if ($i == "fi") echo "Finnish";
if ($i == "fr") echo "French";
if ($i == "de") echo "German";
if ($i == "el") echo "Greek";
if ($i == "gn") echo "Guarani";
if ($i == "hn") echo "Hawaiian";
if ($i == "he") echo "Hebrew";
if ($i == "hi") echo "Hindi";
if ($i == "hu") echo "Hungarian";
if ($i == "is") echo "Icelandic";
if ($i == "id") echo "Indonesian";
if ($i == "ga") echo "Irish";
if ($i == "it") echo "Italian";
if ($i == "ja") echo "Japanese";
if ($i == "kk") echo "Kazakh";
if ($i == "ko") echo "Korean";
if ($i == "la") echo "Latin";
if ($i == "lv") echo "Latvian";
if ($i == "lt") echo "Lithuanian";
if ($i == "mk") echo "Macedonian";
if ($i == "ms") echo "Malay";
if ($i == "mt") echo "Maltese";
if ($i == "mn") echo "Mongolian";
if ($i == "ne") echo "Nepali";
if ($i == "no") echo "Norwegian";
if ($i == "fa") echo "Persian";
if ($i == "pl") echo "Polish";
if ($i == "pt") echo "Português";
if ($i == "pa") echo "Punjabi";
if ($i == "qu") echo "Quechua";
if ($i == "ro") echo "Romanian";
if ($i == "rm") echo "Romansh";
if ($i == "ru") echo "Russian";
if ($i == "gd") echo "Scottish Gaelic";
if ($i == "sr") echo "Serbian";
if ($i == "sk") echo "Slovak";
if ($i == "sl") echo "Slovenian";
if ($i == "es") echo "Spanish";
if ($i == "su") echo "Sundanese";
if ($i == "sw") echo "Swahili";
if ($i == "sv") echo "Swedish";
if ($i == "th") echo "Thai";
if ($i == "tp") echo "Tupi";
if ($i == "tr") echo "Turkish";
if ($i == "uk") echo "Ukrainian";
if ($i == "uz") echo "Uzbek";
if ($i == "vi") echo "Vietnamese";
if ($i == "cy") echo "Welsh";
if ($i == "yi") echo "Yiddish";
if ($i == "yo") echo "Yoruba";
if ($i == "zu") echo "Zulu";    
}
?>

<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
