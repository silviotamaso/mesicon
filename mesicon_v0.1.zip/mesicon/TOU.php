<!DOCTYPE html>
<html>

<head>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Terms of Use/Termos de Uso</title></head>
<body><table width="100%"><tr valign="top">
    
    
    
    
    
    
    
<td width="50%">

<center>Português</center><br><br>

Termos de Uso (Atualizado em junho 2022)<br>--<br>

Aqui estão os Termos de Uso e Serviço para usar este site. Ao usar o MESICON ("O Serviço"), um serviço fornecido pelo Statos.com ("A Empresa"), você concorda em estar vinculado aos seguintes termos e condições ("Termos de Uso"). A violação de qualquer um dos termos declarados abaixo resultará no término da sua conta ou da conta da sua empresa.
<br> <br>

Termos e Condições Gerais <br>
Ao contrário do que geralmente é feito por empresas e serviços que você pode usar inadvertidamente (M3ta, Fac3book, Inst4gram, Twitt3r, 4mazon, 4pple e outras) e, muito pior, em alguns casos, idolatra, não usamos suas informações para nada: não vendemos, alugamos, trocamos, emprestamos, colocamos em leilão, nada, mas você deve fornecer informações válidas necessárias para concluir o processo de inscrição. A Empresa não será responsável por qualquer perda de dados, divulgação de dados ou danos incorridos que resultarão de não proteger sua senha e conta. Você não deve violar nenhuma lei ou fazer qualquer uso não autorizado ou ilegal usando o Serviço. Você e/ou sua empresa serão responsáveis por todo o conteúdo e atividade que são mantidos sob sua conta. Seu uso do Serviço é de risco exclusivo seu. O serviço é prestado na base do "é como está/no estado". Você não deve revender, copiar ou duplicar informações do Serviço, ou qualquer parte dele, sem uma permissão por escrito da Empresa. A Empresa não garante que o Serviço atenda às suas necessidades, estará livre de erros, estará seguro ou estará disponível o tempo todo. A Empresa possui o direito de remover, ou não remover, qualquer conteúdo que seja ilegal ou ofensivo. No entanto, qualquer abuso ou ameaça resultará na suspensão ou rescisão imediata dessa conta. Você entende e concorda expressamente que a Empresa não se responsabiliza por quaisquer danos diretos ou indiretos, incluindo, entre outros, danos por perda de dados, lucros ou outras perdas intangíveis resultantes do uso direto ou indireto do Serviço. Você concorda em indenizar e manter a Empresa inofensiva e suas afiliadas, oficiais, agentes e funcionários contra perdas, danos ou despesas ameaçadas por razão da responsabilidade ou responsabilidade potencial da Empresa por ou decorrente de quaisquer reivindicações por danos. Nesse caso, a Empresa pode fornecer um aviso por escrito de tal reivindicação ou ação.
<br> <br>

Política de Privacidade e Segurança <br>
A privacidade e a segurança de suas informações são importantes para nós. <br>
Esta seção informa as nossas políticas sobre a coleção, uso e divulgação de informações que recebemos dos usuários do Serviço. <br>
Estamos comprometidos com a confidencialidade e a segurança de qualquer informação que você nos fornece. A Empresa está comprometida em proteger a privacidade de seus clientes e essa política de segurança e privacidade descreve quais tipos de informações coletamos e a maneira como podemos usá-las. O uso de informações coletadas por meio de nosso Serviço deve ser limitado ao objetivo de fornecer o Serviço para o qual os clientes (você/sua empresa) envolveram a Empresa. <br>
Lembre-se de que, quando você inserir informações no Serviço, a transmissão de informações será feita por empresas terceiras usando a tecnologia de camada de soquete. Seguimos os padrões geralmente aceitos para proteger as informações enviadas a nós, tanto durante a transmissão quanto depois que as recebermos. No entanto, nenhum método de transmissão pela Internet ou método de armazenamento eletrônico é 100% seguro. Portanto, não podemos garantir segurança absoluta. Sobre o aviso de página não segura que os navegadores exibem: trata-se de nossa opção por habilitar apenas o protocolo HTTP, ao invés do HTTPS, para o acesso a MESICON. HTTPS é desnecessário para o nosso caso. Há poucos anos HTTPS era requerido e efetivamente usado apenas para websites de instituições financeiras, eles sim precisam da camada adicional de segurança, o "s" da sigla, para suas operações, nenhum outro site (que não faça comércio eletrônico) precisa de HTTPS. Mas como virou moda ter o cadeado fechado na barra de endereços do navegador, a indústria foi a primeira a adotar a ideia, afinal - claro, é mais dinheiro para ela. No nosso caso, apenas mudar o cadeado de aberto para fechado aumentaria em 30% o valor necessário para a manutenção de MESICON. A velha história: um canhão para matar uma mosca. Nós recusamos. Pesquise no seu buscador preferido e confirme a diferença entre http e https, certamente concordará que não precisamos dele, ao menos em termos objetivos, de funcionalidade e de garantia das informações dos usuários de MESICON (por moda não, de fato, para "ficar bem na foto" seria lindo ter o cadeado fechado - quer nos ajudar a pagar por ele então? Ok). Não, definitivamente não somos do tipo que tem "... enrolado os pés publicamente nos tapetes das etiquetas", na versão de Fernando Pessoa. A propósito, na sua busca por respostas, procure também pelo método de criptografia SHA3, é por meio desse argoritmo que MESICON armazena a sua senha de usuário (aqui: http://statos.com/mesicon/static/sha3-min.js, confira se nossa página de registro não carrega essa biblioteca, é bem fácil de ver). Ademais, resta descobrir por que alguém incorreria num crime - invasão de computadores é crime, para acessar informações relativas a edições e manuscritos que estão disponíveis e acessíveis irrestritamente, até os não cadastrados em MESICON têm acesso a elas. De novo, se formos pelo argumento da indústria, claro, quanto mais gastarmos, consumirmos, melhor! E quanto mais as desavisadas vítimas da moda do momento demandarem recursos, mais a indústria ganha. Mais computadores, fazendo mais requisições cada vez mais complexas, que demandam maior consumo de banda, mais gasto de tempo e em eletricidade... para exibirmos um cadeado fechado na página e assim posarmos de Guardiões da Segurança enquanto exigimos, cada vez mais, dos finitos recursos de nosso Planeta, aumentando nossa pegada de carbono etc. Sim, às vezes é importante usar essa parte de nosso corpo que se localiza dentro da caixa craniana. A indústria elegendo o seu produto mais caro como o único autorizado, afinal, site que não usa o cadeado fechado é apresentado como um risco para o usuário final (por meio dos avisos de perigo e a enumeração de golpes que você poderá sofrer se navegar num site cuja conexão não é aquela requerida pelos serviços financeiros) age como o fabricante de automóveis que denuncia (e quer banir) o trânsito de bicicletas nas vias públicas como se fossem uma ameaça a você, possuidor do caro e poluidor veículo automotor fabricado por ela, indústria que faz propaganda como sendo defensora do meio ambiente e os incautos acreditam.
<br><br>

Coleta e Uso de Informações; Dados de Log; "Cookies" <br>
Para usar o Serviço, precisamos que você nos forneça apenas o endereço de e-mail seu/da sua empresa. A Empresa também não possui ou mantém estatísticas de uso do Serviço ou informações baseadas em localização. Não pedimos que você nos forneça informações de identificação pessoal. Não coletamos informações chamadas dados de log. Não usamos "cookies" para coletar informações.
<br> <br>

Compartilhamento de Informações <br>
A Empresa não venderá suas informações, alugará, emprestará ou trocará com terceiros, em qualquer condição. A Empresa usa as informações coletadas para atendê-lo. No entanto, se solicitado por lei, a Empresa tem o direito de compartilhar as informações que possui com as autoridades; conforme exigido por lei, como cumprir uma intimação ou processo legal semelhante; Quando acreditamos de boa fé que a divulgação é necessária para proteger nossos direitos, proteger sua segurança ou a segurança de outras pessoas, investigar fraudes ou responder a um pedido de autoridade governamental instituída; Para qualquer outro terceiro com ou sem o seu consentimento anterior para fazê-lo, a decisão final será da Empresa, podendo ou não transferir informações e pode não notificá-lo sobre isso, igualmente em qualquer caso de que seja adquirida ou fundida com outra empresa. Você pode ser notificado por e-mail e/ou um aviso proeminente em nosso site de quaisquer opções que possa ter em relação às suas informações. Por favor, esteja informado de que a Empresa usa fornecedores terceiros e/ou parceiros para fornecer o hardware, software, emails, redes, armazenamento e tecnologia relacionada necessários para executar o Serviço. Essas empresas estão autorizadas a usar suas informações apenas conforme necessário para fornecer esses serviços a nós.
<br> <br>

Acesso e Escolha do Usuário <br>
Se suas informações mudarem, você poderá corrigi-las ou atualizá-las fazendo a alteração no Serviço. A Empresa não responderá solicitações sobre dados dos usuários do Serviço. Podemos usar suas informações para fornecer o Serviço, essas informações podem ser necessárias para cumprir nossas obrigações legais, resolver disputas e fazer cumprir nossos acordos.
<br><br>

Preços; Termos de Atualização; Disponibilidade; Tratamento dos Dados; Recusa de Responsabilidade<br>
O serviço é gratuito. Em qualquer caso de atualização do Serviço, a Empresa não será responsável por qualquer conteúdo ou recurso ou incapacidade de executar tarefas resultantes da atualização do Serviço. Os dados e o conteúdo que você inserir no Serviço serão considerados de sua inteira responsabilidade, para fins  legais. A Empresa poderá inserir informações que julgue pertinente, sob qualquer aspecto, junto às informações dos usuários, da mesma maneira a Empresa terá sempre o direito de editar/alterar/excluir todo e qualquer conteúdo, sob qualquer motivo, inserido no Serviço por seus usuários e/ou clientes. Em benefício da transparência, todas as ações realizadas por usuários registrados no Serviço, administradores ou não, estarão disponíveis na seção "Histórico" (dentro de "Perfil").
<br> <br>

Cancelamento, Suspensão e Reativação; Alterações neste Documento<br>
A Empresa se reserva no direito de recusar o fornecimento do Serviço a qualquer pessoa ou empresa por qualquer motivo a qualquer momento, da mesma forma que a Empresa pode recusar pedidos para cancelar ou reativar sua conta e/ou de sua empresa (ou de terceiros), da mesma forma com relação às informações que você/sua empresa forneçam ao Serviço - A Empresa pode recursar-se a apagar suas informações ou inserir novas informações. A Empresa tem o direito de suspender ou encerrar sua conta e/ou a conta da sua empresa a qualquer momento e sob qualquer alegação/motivo. Se um usuário mostrar comportamento inadequado, promover lixo eletrônico (spam) ou inundações (flood), por exemplo (ou qualquer outro uso não previsto e/ou de risco), ele será impedido de acessar o Serviço. A falha da Empresa em exercer ou fazer cumprir qualquer direito ou disposição dos Termos de Uso não constituirá uma renúncia a esse direito ou disposição. Os Termos de Uso constituem o contrato completo entre você e a Empresa e governam o uso do Serviço, substituindo quaisquer acordos anteriores entre você e a Empresa. A Empresa se reserva no direito de atualizar e alterar os Termos de Uso periodicamente sem aviso prévio. Quaisquer alterações ou atualizações feitas no Serviço estão sujeitas a estes Termos de Uso. Continuar a usar o Serviço depois que essas alterações ou atualizações constituirá seu consentimento para essas atualizações e/ou alterações. Apps arroba statos ponto com é a maneira oficial de entrar em contato conosco, em qualquer caso, sobre esses Termos de Uso. Este documento é efetivo a partir da data de atualização expressa (acima) e permanecerá em vigor, exceto com relação a quaisquer alterações em suas disposições no futuro, que estarão em vigor imediatamente após a publicação nesta página.
<br><br>

Incorpore Este Serviço à Sua Instituição <br>
O objetivo final deste serviço é ser colocado "público", em sentido amplo e não apenas em termos de espaço (a Internet, onde já está), mas também tempo. Pensando nisso, realmente desejamos que um dia alguma instituição pública, estatal ou federal, tenha interesse em hospedar este sistema dentro da sua própria central de informática, libertando MESICON de nossos parcos recursos individuais e, com isso, aumentando as chances de MESICON permanecer online para uso e benefício das próximas gerações. Você acha que sua instituição poderia lidar com isso? Observadas pequenas condições (relativas basicamente a manutenção dos créditos e à obrigatoriedade de que MESICON permaneça de uso gratuito), podemos doar o sistema para vocês. Adicionalmente, oferecemos auxílio para incorporar a MESICON um banco de dados que vem sendo preparado desde uma pesquisa de doutorado iniciada em 2013 na USP, base que conta com 12 tabelas (periódicos, editoras, tipografias, livrarias, entre outras), sendo a maior dela possuidora de 4465 campos (jun. 2022). Por favor, entre em contato e vamos tratar do assunto.
<br> <br>

Versão Exclusiva de MESICON para Você e/ou Sua Empresa <br>
Se você acha que uma versão modificada deste Serviço beneficiaria você e/ou sua empresa, entre em contato.
<br> <br>

Aspectos técnicos (em junho de 2022)<br>
Para desenvolver este Sistema prezamos por apenas utilizar software 100% livre e gratuito, tanto em nosso ambiente de desenvolvimento doméstico quanto "na nuvem", no provedor de serviços de internet onde MESICON fica armazenado. Localmente temos Slax Linux, Android, Notepad++, Epic Browser mobile e desktop (Chromium-mod), Mozilla Firefox, InkScape e IcoFX. Remotamente, o servidor HTTP é um Linux CentOS 5.11 (64 bits) rodando Apache e PHP versão 8.0.10. Já o servidor MySQL é um Linux Debian com a libmysql versão 5.5.62 e Apache v. 2.4.20. Aqui o PHP é v. 5.6.40-0+deb8u12. Finalizando, todas as senhas dos usuários são armazenadas após passarem pelo método de criptografia SHA3.
<br> <br>

Marketing <br>
Além de ser gratuito este Serviço não possui nem aceita anúncios ou propaganda de qualquer espécie: é 100% livre - foi feito pensando em você, para seu uso e desfruto sem inconveniência de qualquer tipo.
<br> <br>

Doação/Ajuda <br>
Se você aprecia o nosso trabalho e o nosso Serviço e acha que mereceremos algum tipo de retribuição, uma doação, um incentivo, certifique-se de que isso não seria apenas muito apreciado, mas verdadeiramente essencial para a continuação de nossas atividades. A doação pode até ser anônima/sigilosa via <a href="https://t.co/c2MNS5mMmJ" target="_blank">boleto, cartão, paypal etc</a>. Se preferir entre em contato conosco para tratarmos desse assunto. Além disso, pedimos humildemente que você ajude a compartilhar este Serviço entre seus grupos de amigos, pode ser útil para alguém. Por ser muito modesto, nunca apareceremos em tópicos "de interesse" nos canais comerciais, por isso dependemos de você. Agradecemos.
<br><br>

Agrade(Esclare)cimento<br>
Sim, é bastante provinciano, mas temos que deixar claro que agradecemos imensamente aos nossos pais e irmãos por nos ajudarem a viabilizar os meios necessários para a realização deste e de outros projetos. Adoraríamos listar como apoiadores/ parceiros/ financiadores/ patronos/ doadores (ainda que apenas rubricas daqueles que preferem o sigilo) empresas, institutos, desses que abundam por aí ostentando nomes e sobrenomes famosos (dessas empresas que vemos todo dia fazendo propaganda na televisão em horário nobre pregando todo o contrário do que realizam na prática), de grandes industriais e figuras públicas, políticos e ex-presidentes da república até, gente que gosta de posar de bonzinho mas que, para o povo mesmo, o público anônimo, não fazem nada a não ser mamar em suas tetas. E não dizemos isso da boca para fora não, já batemos em muitas portas. Ótimo, é mais uma lição e uma prova de que não precisamos de ninguém para sermos felizes e fazermos coisas de interesse coletivo acontecerem, independentes de ninguém, muito menos dos "poderosos" de plantão - que um dia terão seus corpos cheios de ouro sendo comidos na terra pelos mesmíssimos vermes que nós. Adicionalmente, agradecemos à Universidade de São Paulo pela oportunidade de lá desenvolvermos uma pesquisa de mestrado, onde construímos um banco de dados para tabular o material coligido em termos de correspondência manuscrita - cuja derivação foi utilizada na engenharia de dados dos "Manuscritos", aqui em MESICON, e também uma pesquisa de doutorado em que, por meio da construção e utilização de outro banco de dados informatizado, obtivemos a estrutura base para a construção do presente sistema. Finalmente, não menos importante: agradecemos à Coordenação de Aperfeiçoamento de Pessoal de Nível Superior (CAPES), agência do Ministério da Educação, do Governo do Brasil, pela subvenção das bolsas de estudos de mestrado e doutorado que nos permitiram a dedicação integral à pesquisa. E não, não usamos aqui termos e facilidades inteligentinhas e da moda (ah! As maravilhas da modernidade), coisas que julgamos feitas apenas para fazer as pessoas de tolas, enquanto seus criadores enriquecem. Cr34tiv3 Comm0nz, etc, e sonolentas bobagens assemelhadas: nada das informações inseridas pelos usuários em MESICON é de uso livre, portanto preste atenção e contate os respectivos donos das informações antes de usá-las. Esteja avisado.
<br><br>

Créditos<br>
Este website foi concebido no âmbito das investigações do grupo de pesquisa "Regional Estudos Multidisciplinares - REGIONEM" (<a href="https://regionem.wordpress.com" target="_blank">regionem.wordpress.com</a>), em junho de 2022.<br>
Criação e Produção: Silvio Tamaso D'Onofrio (Junho 2022).<br>
Apoio: Deusdedit Anselmo D'Onofrio, Maria Marta Tamaso, Henrique César Tamaso D'Onofrio, Marta Fernanda Tamaso D'Onofrio.<br>
A arte ASCII exibida em cada página como logo MESICON foi feita com a curiosa ferramenta que Patrick Gillespie disponibilizou em <a href="http://patorjk.com" target="_blank">patorjk.com</a>.
<br><br>

Entre em Contato<br>
http://www.statos.com

</td>
    





<td width="50%">
    
<center>English</center><br><br>

Terms of Use (Last updated: June 2022)<br>--<br>

Here are the Terms of Use and Service for using this website. By using MESICON (“The Service”), a service provided by Statos.com (“The Company”), you are agreeing to be bound by the following terms and conditions (“Terms of Use”). Violation of any of the terms which are stated below will result in the termination of your, or your company's, account.
<br><br>

General Terms and Conditions<br>
Contrary to what is usually done out there by companies and services that you may use inadvertently (M3ta, Fac3book, Inst4gram, Twitt3r, 4mazon, 4pple and others) and, much worse, in some cases, idolate, we do not use your information for nothing: we do not sell it, rent, exchange, put on auction, nothing, but you must provide valid information needed to complete the signup process. The Company will not be responsible for any loss of data, disclosure of data or incurred damage that will result from not securing your password and account. You must not violate any law or make any unauthorized or illegal use while, and by, using the Service. You, and/or your company, will be responsible for all the content and activity which are held under you account. Your use of the Service is at your sole risk. The Service is provided on an “as is” basis. You must not resell, copy or duplicate information from the Service, or any part of it, without a written permission from The Company. The Company does not warrant that the Service will answer your needs, will be free of errors, will be secure or will be available at all times. The Company holds its rights to remove, or not to remove, any content which us unlawful or offensive. However, any written abuse or threat made in an account will result in the immediate suspension or termination of that account. You expressly understand and agree that The Company shall not be liable for any direct or indirect damages, including but not limited to damages for loss of data, profits, or other intangible losses resulting from the direct or indirect use of the Service. You agree to indemnify and hold harmless The Company and its affiliates, officers, agents, and employees from against loss or threatened loss or expense by reason of the liability or potential liability of The Company for or arising out of any claims for damages. In such a case, The Company may provide you with written notice of such claim, suit or action.
<br><br>

Privacy Policy and Security<br>
The privacy and security of your information is important to us.<br>
This section informs you of our policies regarding the collection, use and disclosure of information we receive from users of the Service.<br>
We're committed to the confidentiality and security of any information you provide us with. This security and privacy policy explains how we protect your information. The Service are provided by Statos.com (“The Company”). The Company is committed to protect the privacy of its customers and this Security and Privacy Policy outlines what kinds of information we collect and the way that we may use it. The use of information collected through our service shall be limited to the purpose of providing the service for which the Clients (you/your company) has engaged The Company.<br>
Have in mind that, when you enter information in the Service the transmission of information will be done by third party business using socket layer technology. We follow generally accepted standards to protect the information submitted to us, both during transmission and once we receive it. However, no method of transmission over the Internet, or method of electronic storage, is not 100% secure. Therefore, we cannot guarantee its absolute security. About the warning "page not safe" that browsers display: it is our choice to enable only the HTTP protocol, instead of HTTPS, for access to MESICON. HTTPS is unnecessary for our case. A few years ago HTTPS was required and effectively used only for financial institution websites, they need the additional security layer, the "s" letter in the acronym, for their operations, no other website (those who do not do e-commerce) needs HTTPS. But as it became fashionable to have the lock closed in the browser's address bar, the industry was the first to adopt the idea, after all - of course, it's more money for them. In our case, just changing the open lock to closed would increase by 30% the amount required for MESICON maintenance. The old story: a cannon to kill a fly. We refused. Search your favorite search engine and confirm the difference between HTTP and HTTPS, you will certainly agree that we don't need it, at least in terms of objective, functionality and guaranteeing MESICON users security (by fashion not, in fact, "to be well in the photo" it would be beautiful to have the lock closed - want to help us pay for it then? No, we are definitely not the type that has "... tripping up in public on the carpet of etiquette", according to Fernando Pessoa. In addition, in your search for answers, also look for the SHA3 encryption method, it is through this algorithm that MESICON stores your user password. Moreover, it remains to be found out why someone would incur a crime - invasion of computers is a crime, to access information regarding editions and manuscripts that are available and accessible unrestrictedly, even those not registered in MESICON can see them. So do we agree that HTTPS here is not justified? Again, if we go through the industry argument, of course, the more we spend, consume, the better. And the more the unsuspecting fashion victims of the moment demand resources, the more the industry earns. More computers, making more complexes requests, which require more band consumption, more time and electricity ... to display a closed lock on the page and thus pose as Security Guardians while we increasingly demand the finite features of our Planet, increasing our carbon footprint etc. Yes, sometimes it is important to use this part of our body that is located within the cranial box. The industry electing its most expensive product as the only authorized, after all, a site that does not use the closed lock is presented as a risk to the end user (through danger warnings and the enumeration of scams you can suffer from navigating in a Website whose connection is not the one required by the financial services) acts as the car manufacturer that denounces (and wants to ban) the transit of bicycles on public roads as if they were a threat to you, owner of the expensive and polluter vehicle made by her, Industry that advertises itselself as a defender of the environment and the unwary believe.
<br><br>

Information Collection And Use; Log Data; "Cookies"<br>
In order to use The Service, we need you to provide us with your/your company email address, only. The company also do not holds or keep application usage statistics or location based information. We do not ask you to provide us with personally identifiable information. We do not collect information called Log Data. We do not use "cookies" to collect information.
<br><br>

Information Sharing<br>
The Company will not sell your information, rent it or exchange it with any third party, in any condition. The Company uses the information that was gathered in order to service you. However, if requested by law, The Company holds its right to share the information it possesses with the authorities; as required by law, such as to comply with a subpoena, or similar legal process; when we believe in good faith that disclosure is necessary to protect our rights, protect your safety or the safety of others, investigate fraud, or respond to a government request; to any other third party with your prior consent to do so. The Company will transfer information, and may not notify you about it, in any case that it will be acquired or merged with another company. You may be notified via email and/or a prominent notice on our site of any choices you may have regarding your information. Please be informed that The Company uses third party vendors and hosting partners to provide the necessary hardware, software, emailing, networking, storage, and related technology required to run The Service. These companies are authorized to use your information only as necessary to provide these services to us.
<br><br>

User Access and Choice<br>
If your information changes you may correct or update it by making the change on the Service. The Company will not respond email solicitations about data. We may use your information on behalf to provide you the Service, this information may be necessary to comply with our legal obligations, resolve disputes, and enforce our agreements.
<br><br>

Prices; Update Terms; Availability; Data Treating, Denial of Responsibility<br>
The service is free. In any case of updating the service, the company will not be responsible for any content or resource or inability to perform tasks resulting from the service update. The data and content you enter in the service will be considered your own responsibility in legal terms. The company may enter information that deems relevant, in any respect, with users' information, in the same way the company will always have the right to edit/change/exclude any and all content, on any reason, inserted in the service by its users and/or customers. Transparently, all actions made by the registered users of the System, administrators or no, will be logged in the "History" section (inside "Profile".
<br><br>

Cancellation, Suspension and Reactivation; Changes to this Document<br>
The Company reserves the right to refuse the service of the Service to any person or company for any reason at any time, just as the Company can refuse requests to cancel or reactivate your account and/or your company's account (or third parties), likewise regarding the information you/your company provide to the Service - the Company can refuse to delete your information or enter new information. The Company has the right to suspend or end your account and/or your company's account at any time and on any allegation/reason. If a user shows inappropriate behavior, promoting electronic waste (spam) or flood, for example (or any other non-planned and/or risky use), it will be prevented from accessing the Service. The Company's failure to exercise or enforce any right or arrangement of the Terms of Use will not be a waiver of this right or provision. Terms of Use constitute the complete contract between you and the Company and govern the use of the Service, replacing any previous agreements between you and the Company. The Company reserves the right to update and change the Terms of Use periodically without notice. Any changes or updates made in the Service are subject to these Terms of Use. Continue using the Service after these changes or updates will constitute your consent to these updates and/or changes. Apps at statos dot com is the official way to contact us, in any case, about these Terms of Use. This document is effective from the express update date (above) and will remain in force, except for any changes in their provisions in the future, which will be in force immediately after publication on this page.
<br><br>

Incorporate this Service into your Institution<br>
The final goal of this Service is to be put "public", broad sense not only in terms of space (the internet, where it is already) but in time: thinking about it we really wish one day some public institution, state or federal, would have interest in host this project inside your own IT resources, making MESICON free from our personal efforts and with more chances to be online to the next generations. Do you think your institution could handle it? With a few conditions (related, basically, to the exposure of the "credits" and the maintenance of costless status for the final user), we can donate the system to you. Additionally, we offer assistance to incorporate MESICON a database that has been prepared since a doctoral research started in 2013 at University of São Paulo, a base that has 12 tables (periodicals, publishers, typography, bookstores, among others), the largest one with 4465 fields (Jun. 2022). Please, get in contact and let's talk about it. 
<br><br>

Taylor made version just for you and your business<br>
If you think a modified version of this Service would benefit you and/or your business, please get in contact.
<br><br>

Techincal Aspects (as of June 2022)<br>
To develop this system we value only using 100% free and open source software, both in our home environment and "in the clouds", in the internet service provider where MESICON is stored. Locally we have Slax Linux, Android, Notepad++, Epic Browser mobile and desktop (Chromium-mod), Mozilla Firefox, InkScape and IcoFX. Remotely, the HTTP server is a Linux CentOS 5.11 (64 bits) running Apache and PHP version 8.0.10. MySQL server is a Debian Linux with libmysql v. 5.5.62 and Apache v. 2.4.20. Here the PHP is v. 5.6.40-0+deb8u12. Finally, all user passwords are stored ecrypted by the SHA3 method (here: http://statos.com/mesicon/static/sha3-min.js - look to see if our sign in page doesn't load this library!).
<br> <br>

Marketing<br>
This Service does not have - nor accepts advertisements. It is 100% free - it was done thinking about you, for your use and enjoy without inconvenience of any kind.
<br><br>

Donation/Help<br>
If you like our Service and think we would deserve some kind of retribution, a donation, an incentive, be sure that this would be not only very appreciated but truly essential to the continuation of our activities. You can also donate in anonymity via <a href="https://t.co/c2MNS5mMmJ" target="_blank">invoice, credit cart, paypal and so on</a>. Contact us if you prefer. Additionally, we humbly ask you to help spread this Service among your groups of friends, it can be useful for someone. Because it is very modest, it will never appear in trending topics, so we depend on you. Thanks. 
<br><br>

Thanks/Acknowledgements<br>
Yes, it is quite provincial, but we have to make it clear that we thank our parents immensely for enabling us all the necessary means to carry out this and other projects. We would love to list great companies, sponsors, or large institutes, those that abound out there hosting famous names and surnames, of great industrial and public people, yet former politicians even presidents of the Republic, people who like to pose like good but who, for the people, the anonymous audience, do nothing but to breastfeed in their tits. And we don't say that from the mouth out, we've hit many doors. Great, it is another lesson and proof that we do not need anyone to be happy and do things of collective interest to happen, independent of anyone mainly the "powerful" on duty - that one day will have their bodies full of gold being eaten on earth by the same worms that we. Additionally, we thank the University of São Paulo for the opportunity to develop a master's research, where we built a database to control the collected material in terms of handwritten correspondence - whose derivation was used in "manuscript" data engineering, here in MESICON, and also a doctoral research in which, through the construction and use of another computerized database, we obtained the base structure for the construction of this system. Finally, not least important: we thank the Coordination of Improvement of Higher Education Personnel (CAPES), agency of the Ministry of Education, of the Government of Brazil, for the subsidy of master's and doctoral scholarships that allowed us to be full dedication to the research those years. And no, we don't use fancy and fashionable terms and facilities, wonders of the modern world, which we think are done just to make people in foolish while their creators enrich. Cr34tiv3 Commonz, etc., bulshit: Nothing in MESICON has its use free, so pay attention and contact the owners of information before using it. Be warned.
<br><br>

Credits<br>
This website was designed under the research group "Regional Estudos Multidisciplinares - REGIONEM" investigations (<a href="https://regionem.wordpress.com" target="_blank">regionem.wordpress.com</a>), in June, 2022.<br>
Created and developed by Silvio Tamaso D'Onofrio.<br>
Support: Deusdedit Anselmo D'Onofrio, Maria Marta Tamaso, Henrique César Tamaso D'Onofrio, Marta Fernanda Tamaso D'Onofrio.<br>
The ASCII Art showed in each page as MESICON logo was made using the nice tool Patrick Gillespie put in <a href="http://patorjk.com" target="_blank">patorjk.com</a>.
<br><br>

Contact Us<br>
http://www.statos.com

</td>
    
    
    
    
    
    
    
    
</tr></table>






