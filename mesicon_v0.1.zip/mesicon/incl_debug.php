<?php 

// print all Sessions to debug

error_reporting(0);

//echo "--- sessions<br>";
echo "user id: " . $_SESSION['user']['id'] . "<br>";
echo "user username: " . $_SESSION['user']['username'] . "<br>";
//echo "user role: " . $_SESSION['user']['role'] . "<br>";
echo "user role: " . $_SESSION['user']['role'] . "<br>";
echo "status: " . $_SESSION['user']['status'] . "<br>";
echo "idiom: " . $_SESSION['user']['lang'] . "<br>";
echo "message: " . $_SESSION['message'] . "<br>";
echo "esta página: " . $_SERVER["PHP_SELF"] . "<br>";
// echo "user: " . $_SESSION['user'] . "<br>"; - array where is all user data; prints only "Array"

error_reporting(1);

?>

<script>
setInterval(function(){ location.reload(); }, 50000);
</script>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->
