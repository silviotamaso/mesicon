<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_registration_login.php');
function getLastWord($estringue){
    $pieces = preg_split('/\s+/', $estringue); // regular expression to create array from white spaces split words
    //print_r($pieces);
    $lastword = array_pop($pieces);
    return $lastword;
} // existe cópia desta função tb em "incl_functions.php", se mudar aqui muda lá tb cabaço!
?>

<script>
<!--
window.addEventListener('load', 
  function() { 
    //alert('pg ended loading!');
    document.statosdotcomForm.email.focus();
  }, false);
function vai(el,m) {alert(m);el.focus();}
function i(f) {
	if (f.email.value=="") {vai(f.email,"MESICON\n\nE-mail?");return false;}
	else if (f.email.value.indexOf("@")==-1 || f.email.value.indexOf(".")==-1 || f.email.value.indexOf(" ")==1 || f.email.value.indexOf("/")==1 || f.email.value.indexOf("@.")==1 || f.email.value.indexOf(".@")==1) {vai(f.email,"MESICON\n\nE-mail?");return false;}
	else if (f.password.value=="") {vai(f.password,"MESICON\n\nSenha? Password?");return false;}
	else {
        var objForm = document.getElementById('statosdotcomForm');
        var objBtn = document.getElementById('id-login-btn');
        objBtn.style = 'color: #000000; background: #00ff00; cursor: not-allowed;';
        objBtn.textContent = 'Aguarde/Wait...';
		f.encpass.value = sha3_224(f.password.value);
		return true;
	}
}
function statosdotcom_lembrarSenha(f) {
	if (document.statosdotcomForm.email.value=="") {vai(document.statosdotcomForm.email,"MESICON\n\nEntre com e-mail e clique aqui.\n\nEnter e-mail and click here.");return false;}
	else if (document.statosdotcomForm.email.value.indexOf("@")==-1 || document.statosdotcomForm.email.value.indexOf(".")==-1 || document.statosdotcomForm.email.value.indexOf(" ")==1 || document.statosdotcomForm.email.value.indexOf("/")==1 || document.statosdotcomForm.email.value.indexOf("@.")==1 || document.statosdotcomForm.email.value.indexOf(".@")==1) {vai(document.statosdotcomForm.email,"MESICON\n\nE-mail?");return false;}
	else {
		//pensa();
		document.statosdotcomFormSenha.email2.value = document.statosdotcomForm.email.value;
		document.statosdotcomFormSenha.submit();
		return true;
	}
}
function statosdotcom_Count(obj,max) { if ((max-10) < obj.value.length) { document.getElementById("l"+obj.name).innerHTML = '<span style="color: red;">'+(max-obj.value.length)+'</span>'; } else { document.getElementById("l"+obj.name).innerHTML = (max-obj.value.length); }}
//function pensa() {document.body.style.cursor='wait';}
//-->
</script>
<script src="static/sha3-min.js"></script>

<style>
.ct { position: absolute; }
</style>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Log in/Entrar</title>

<!-- <link rel="preload" href="http://statos.com/mesicon/static/menu.png" as="image"> -->

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->
		
    <h1><?= txt('entrada') ?></h1>
    <?php include('incl_messages.php'); ?>
    
    <form name="statosdotcomForm" id="statosdotcomForm" method="post" action="login.php" onSubmit="return i(this);">
        <?php
        //include(ROOT_PATH . '/incl_errors.php')
        include('incl_errors.php')
        ?>
        <br><h3>Email:</h3><br>
        <input type="text" name="email" placeholder="Email">
        <br><h3><?= txt('senha') ?>:</h3><br>
        <div id='lpassword' class='ct'></div>
        <input onkeyup="statosdotcom_Count(this,8);" type='password' id='password' name='password' placeholder="<?= txt('senha') ?>" maxlength='8'>
        <input type="hidden" name="encpass">
        <br><button type="submit" class="btn" name="login-btn" id="id-login-btn"><?= txt('entrar_M') ?></button><br>
    </form>
    
    <form name="statosdotcomFormSenha" method="post" action="remember_password.php">
        <input type="hidden" name="statos" value="1"><input type="hidden" name="email2">
        <h4><a href="#" onClick="return statosdotcom_lembrarSenha(this);"><?= txt('lembrarsenha') ?></a></h4>
    </form><br>
    
    <h4><?= txt('naocadastrado') ?>? <a href="register.php"><?= txt('cadastrese') ?></a></h4>

<?php
if ($_GET['e'] != "") {
    $email = $_GET['e'];
    ?>
    <script>
        statosdotcomForm.email.value = '<?= $email ?>';
    </script>
    <?php
}
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>



