<?php
include('config.php');
include('incl_debug.php');
include('incl_functions.php');
include('incl_errors.php'); // deve vir depois de "incl_functions.php"
$admins = getUsers();
$roles = ['Manager', 'User'];
$statuses = ['Waiting', 'Authorized', 'Suspended'];
?>

<?php header('Content-Type: text/html; charset=UTF-8'); ?>

<!DOCTYPE html>
<html><head>
    
<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>Admin | Evaluate New User/Avalia Novo usuário</title>
    
</head><body>

<?php if ($_SESSION['user']['role'] == "Administrator"): ?>
    
	<center><h1><?= $_GET['e'] ?><br></h1>
	<form method="post" action="users.php?emailatualizado=<?= $_GET['e'] ?>">
		<input type="hidden" name="email_novo_usuario" value="<?= $_GET['e']; ?>">
		<input type="hidden" name="id2change" value="<?= $_GET['i']; ?>">
		<select name="role">
			<option value="" selected disabled>group?</option>
			<?php foreach ($roles as $key => $role): ?>
				<option value="<?php echo $role; ?>"><?php echo $role; ?></option>
			<?php endforeach ?>
		</select><br><br>
		<select name="status">
			<option value="" selected disabled>status?</option>
			<?php foreach ($statuses as $key => $status): ?>
				<option value="<?php echo $status; ?>"><?php echo $status; ?></option>
			<?php endforeach ?>
		</select><br><br>
		<button type="submit" name="update-admin3">UPDATE/ATUALIZAR (TODO)</button>
	</form></center>

<?php else: ?>
	<h1 style="text-align: center; margin-top: 20px;"><?= txt('proibido') ?>.</h1>
<?php endif ?>

</body></html>