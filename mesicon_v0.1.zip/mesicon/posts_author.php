<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
//include('incl_functions.php');
?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Posts from Author/Postagens de Autor Específico</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<?php

//getAllPostsFromAuthor($_GET['id'], "title", "ASC"); // id from the post creator, order, asc or desc - TODO: it seems only the first and the last ones listed correctly

//function getAllBooksFromUser($user_id, $order, $asc_or_desc) {

global $conn;
$num_registros = 0;
$sql = "SELECT title, author, created_at, creator, creator_id FROM 02_mesicon_books WHERE creator_id=$user_id ORDER BY " . $order . " " . $asc_or_desc;
$result = mysqli_query($conn, $sql);
if ($result === FALSE) {
    echo "Error at incl_public_functions - getBAMfromUser().";
    die(); // TODO: better error handling
} else {
    $posts = array();
    while ($row = $result->fetch_assoc()) {
        $posts[] = $row;
        $num_registros++;
    }
}
if ($num_registros > 0) echo "<br><h2>Publicações de <a href='user.php?id=" . $posts[0]['creator_id'] . "&v=p'>" . $posts[0]['creator'] . "</a></h2><br>";
else echo "Publicações: nenhuma.<br><br>";
echo "<p align=left>";
for ($contador = 0; $contador < $num_registros; $contador++) {
    echo "<img src='static/spacer.gif' width='5%' height='1px'><a href='post.php?id=" . $posts[$contador]['id'] . "'>" . $posts[$contador]['author'] . ". <i>" . $posts[$contador]['title'] . ".</i> (" . $posts[$contador]['created_at'] . ")</a><br>";
}
echo "</p>";









include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
