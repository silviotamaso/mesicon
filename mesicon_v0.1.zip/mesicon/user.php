<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');
?>

<script>
function i(f) {
	var counter = 0;
	var letters = /^[A-Za-z]+$/;
	var symbols = "!$%^*+|\\\'\"´`<>{}[]";
	if (f.username.value.match(letters)) { // accept only letters, not diacritics
		if (f.username.value.length < 3) {
			alert('MESICON\n\nYour name must have 3 letters min./Seu nome de usuário deve ter ao menos três letras.');
			return false;
		} else {
			// verifica se há especiais -----------------------------------------
			for (var j = 0; j < f.bio.value.length; j++) {
				if (symbols.indexOf(f.bio.value.charAt(j)) != -1) counter++; // have to be by counter or it raises HADOUKEN on the "returns"
			}
			if (counter > 0) {
				alert('MESICON\n\nDo not use special chars/Não use caracteres especiais na Bio.');
				f.bio.focus();
				return false;
			} else {
                f.username.value = f.username.value.toLowerCase();
                var objBtn = document.getElementById('id_update_user');
                objBtn.style = 'color: #000000; background: #00ff00; cursor: not-allowed;';
                objBtn.textContent = 'Aguarde/Wait...';
				return true;
			}
		}
	} else {
		// alert('Name rejected');
		alert('MESICON\n\nName cant be empty (letters only)/Nome não pode ficar vazio. Use apenas letras. Não use espaço, acento ou caracteres especiais.');
		return false;
	}
}
function statosdotcom_Count(obj,max) { if ((max-10) < obj.value.length) { document.getElementById("l"+obj.name).innerHTML = '<span style="color: red;">'+(max-obj.value.length)+'</span>'; } else { document.getElementById("l"+obj.name).innerHTML = (max-obj.value.length); }}
</script>
<style>
.ct { position: absolute; }
.statos_fonte_cinza { color: gray; font-size: calc(9px + (12 - 9) * ((100vw - 300px) / (2000 - 300))) !important; }
/* calc(minsize + (maxsize - minsize) * (100vm - minviewportwidth) / (maxwidthviewoport - minviewportwidth))) */
</style>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Profile/Perfil</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

    <?php
    include('incl_messages.php');
    error_reporting(0);
        //if ($_GET['updated'] == "1") $_SESSION['message'] = "Atualizado com sucesso 2";
        echo "<h2>" . $_SESSION['message'] . "</h2>";
    error_reporting(1);
    ?>

    <?php 
    $_SESSION['message'] = "";
    include('incl_errors.php');

    if ($_GET['v'] == "p") { // view profile - está em incl_functions.php - getUser()
        getUser($_GET['id']);
        // apenas admins? if (($_SESSION['user']['role'] == "Manager") || ($_SESSION['user']['role'] == "Administrator")) getBAMfromUser($_GET['id'], "created_at", "DESC"); // id do criador do post, ordenação, ascendente ou não - TODO: seems only the first and last records are displaying correctly
        getBAMfromUser($_GET['id'], "created_at", "DESC"); // id from the post creator, order asc or desc - TODO: seems only the first and last records are displaying correctly
    }

    if ($_GET['v'] == "h") { // view history - is in incl_functions.php - getUser()
        // mt_rand(min,max), php in the below line, 4 times fater than default "rand()". Both raise 10 chars and in "mt" if max < min goes HADOUKEN!
        echo "<h1>" . txt('historico') . "</h1><h3><a href='user.php?id=" . $_GET['id'] . "&v=p'>&lt;&lt; " . txt('voltar') . " " . txt('perfil') . "</a></h3><br>";
        echo "<font size='-1'>(" . txt('legenda') . ") c: comment; p: update profile; cb: create book; ub: update book; cm: create manuscript; um: update manuscript; l: link manuscript<br><br></font>";
        //getHistory($_SESSION['user']['id']);
        getHistory($_GET['id']);
    }

    echo "<br>--------------------<br>";
    echo "<a href=http://statos.com" . $_SERVER['REQUEST_URI'] . ">http://statos.com" . $_SERVER['REQUEST_URI'] . "</a><br>(<font size='-1'>" . date('F j, Y, g:i a') . "</font>)<br>";
	echo txt('mesicon') . "<br>";
    echo date('Y') . " &copy; MESICON<br></font>";

    // if user is logged in it means he's updating his own profile, so put the cursor there for him to edit then
    if ($_SESSION['user']['role'] != "") { ?>
        <script>
        <!--
        function vai(el,m) {alert(m);el.focus();}
        window.addEventListener('load', 
            function() { // alert('pg ended loading!');
                document.statosdotcomForm.username.focus();
            }, false
        );
        //-->
        </script>
    <?php } ?>
	
<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
