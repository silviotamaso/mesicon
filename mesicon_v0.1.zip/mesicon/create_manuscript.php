<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');
?>

<script>
window.addEventListener('load', 
  function() { 
    //alert('pg ended loading!');
    document.statosdotcomForm.author.focus();
  }, false);
function vai(el,m) {alert(m);el.focus();}
var _formConfirm_submitted = false;
function i(f){
	if (f.author.value=="") {vai(f.author,"MESICON\n\nEntre com autor.\n\nEnter author.");return false;}
	else if (_formConfirm_submitted == false ) { 
        //var objForm = document.getElementById("statosdotcomForm");
        var objBtn = document.getElementById('idBtnSend');
        objBtn.style = "color: #000000; background: #00ff00; cursor: not-allowed;";
        objBtn.textContent = 'Aguarde/Wait...';
        _formConfirm_submitted = true;
        return true;
    } else {
        alert('MESICON\n\nAguarde/Wait...');
        return false;
    }
}
function statosdotcom_Count(obj,max) { if ((max-10) < obj.value.length) { document.getElementById("l"+obj.name).innerHTML = '<span style="color: red;">'+(max-obj.value.length)+'</span>'; } else { document.getElementById("l"+obj.name).innerHTML = (max-obj.value.length); }}
</script>

<style>
.ct { position: absolute; }
</style>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON | Record Manuscript/Cadastrar Manuscrito</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<h1><?= txt('cadastrar') ?> <?= txt('manuscrito') ?></h1>

<?php echo "<h3><a href=control_panel.php>&lt;&lt; " . txt('voltar') . "  " . txt('paineldecontrole') . "</a></h3>"; ?>

<?php if (($_SESSION['user']['role'] == "Manager") || ($_SESSION['user']['role'] == "Administrator")) { ?>

<form name="statosdotcomForm" method="post" action="" onsubmit="return i(this);">
    
<h4>
<?php include('incl_errors.php') ?>

<input type="hidden" name="creator_id" value="<?php echo $_SESSION['user']['id']; ?>">
<input type="hidden" name="creator" value="<?php echo $_SESSION['user']['username']; ?>">

<br><br><?= txt('casohajainfo') ?>.<br><br><br>

<font color="red">*</font> <?= txt('autorman') ?><sup><a href="javascript:alert('MESICON\n\nUse \';\' para separar nomes.\n\nUse \';\' to separate names.');">&nbsp;&#9432;&nbsp;</a></sup> (<?= txt('sobrenome') ?>, <?= txt('nome') ?>):<br>
<div id='lauthor' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" name="author" id="author" placeholder="<?= txt('autorman') ?>" maxlength="199">

<br><?= txt('aspectoautor') ?>:<br>
<select name="author_type">
<option value="0"><?= txt('aspectoautor') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('originalidade') ?>:<br>
<select name="original">
<option value="0"><?= txt('originalidade') ?>?</option>
<option value="1"><?= txt('originalidade') ?> <?= txt('expresso') ?></option>
<option value="2"><?= txt('copiaourep') ?> <?= txt('expresso') ?></option>
<option value="3"><?= txt('originalidade') ?>/<?= txt('copiaourep') ?> <?= txt('presumido') ?></option>
</select>

<br><?= txt('copiadetalhe') ?><sup><a href="javascript:alert('MESICON\n\nÉ cópia carbono, qual a cor? Impresso por computador? Cópia datilográfica? Forneça detalhes.\n\nIs it a carbon copy? Printed by computer or typerwitten? Give details.');">&nbsp;&#9432;&nbsp;</a></sup><br>
<div id='lcopy' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" name="copy" id="copy" placeholder="<?= txt('copiadetalhe') ?>" maxlength="99">

<br><?= txt('titulo') ?>:<br>
<div id='ltitle' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" name="title" id="title" placeholder="<?= txt('titulo') ?>" maxlength="99">

<br><?= txt('aspectotitulo') ?>:<br>
<select name="title_type">
<option value="0"><?= txt('aspectotitulo') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('autorsign') ?>:<br>
<div id='lsignature' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,49);" type="text" name="signature" id="signature" placeholder="<?= txt('autorsign') ?>" maxlength="49">

<br><?= txt('localorigem') ?>:<br>
<div id='lsource_local' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,49);" type="text" id="source_local" name="source_local" placeholder="<?= txt('localorigem') ?>" maxlength="49">

<br><?= txt('aspectoorigem') ?>:<br>
<select name="source_local_type">
<option value="0"><?= txt('aspectoorigem') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('destinatario') ?><sup><a href="javascript:alert('MESICON\n\nUse \';\' para separar nomes.\n\nUse \';\' to separate names.');">&nbsp;&#9432;&nbsp;</a></sup> (Surname/Sobrenome, Name/Nome):<br>
<div id='lrecipient' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" name="recipient" id="recipient" placeholder="<?= txt('destinatario') ?>" maxlength="199">

<br><?= txt('aspectodestinatario') ?>:<br>
<select name="recipient_type">
<option value="0"><?= txt('aspectodestinatario') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('localdestino') ?>:<br>
<div id='ldestination' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,49);" type="text" name="destination" id="destination" placeholder="<?= txt('localdestino') ?>" maxlength="49">

<br><?= txt('aspectodestino') ?>:<br>
<select name="destination_type">
<option value="0"><?= txt('aspectodestino') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('formatrata') ?><sup><a href="javascript:alert('MESICON\n\nComo o autor se dirige ao destinatário.\n\nHow the author addesses the recipient.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<div id='ltreatment' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,49);" type="text" id="treatment" name="treatment" placeholder="<?= txt('formatrata') ?>" maxlength="49">

<br>Post scriptum<sup><a href="javascript:alert('MESICON\n\nHá anotações posteriores, mesmo que de terceiros? Há assinatura? Descreva e/ou transcreva.\n\nThere is/are later notes? Signed? Describe/transcribe it.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<div id='lpostscript' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="postscript" name="postscript" placeholder="P.S." maxlength="199" style="display: inline; margin: 0;">

<br><br><?= txt('data') ?>:<br>
<input type="date" name="data">

<br><?= txt('aspectodata') ?>:<br>
<select name="data_type">
<option value="0"><?= txt('aspectodata') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('idioma') ?>:<br>
<select id="idiom" name="idiom">
<option value="0"><?= txt('idioma') ?>?</option>
<option value="pt">Português</option>
<option value="af">Afrikaans</option>
<option value="sq">Albanian</option>
<option value="ar">Arabic</option>
<option value="hy">Armenian</option>
<option value="az">Azerbaijani</option>
<option value="eu">Basque</option>
<option value="be">Belarusian</option>
<option value="bs">Bosnian</option>
<option value="bg">Bulgarian</option>
<option value="ca">Catalan</option>
<option value="zh">Chinese</option>
<option value="hr">Croatian</option>
<option value="cs">Czech</option>
<option value="da">Danish</option>
<option value="nl">Dutch</option>
<option value="en">English</option>
<option value="eo">Esperanto</option>
<option value="et">Estonian</option>
<option value="fl">Filipino</option>
<option value="fi">Finnish</option>
<option value="fr">French</option>
<option value="de">German</option>
<option value="el">Greek</option>
<option value="gn">Guarani</option>
<option value="hn">Hawaiian</option>
<option value="he">Hebrew</option>
<option value="hi">Hindi</option>
<option value="hu">Hungarian</option>
<option value="is">Icelandic</option>
<option value="id">Indonesian</option>
<option value="ga">Irish</option>
<option value="it">Italian</option>
<option value="ja">Japanese</option>
<option value="kk">Kazakh</option>
<option value="ko">Korean</option>
<option value="la">Latin</option>
<option value="lv">Latvian</option>
<option value="lt">Lithuanian</option>
<option value="mk">Macedonian</option>
<option value="ms">Malay</option>
<option value="mt">Maltese</option>
<option value="mn">Mongolian</option>
<option value="ne">Nepali</option>
<option value="no">Norwegian</option>
<option value="fa">Persian</option>
<option value="pl">Polish</option>
<option value="pt">Português</option>
<option value="pa">Punjabi</option>
<option value="qu">Quechua</option>
<option value="ro">Romanian</option>
<option value="rm">Romansh</option>
<option value="ru">Russian</option>
<option value="gd">Scottish Gaelic</option>
<option value="sr">Serbian</option>
<option value="sk">Slovak</option>
<option value="sl">Slovenian</option>
<option value="es">Spanish</option>
<option value="su">Sundanese</option>
<option value="sw">Swahili</option>
<option value="sv">Swedish</option>
<option value="th">Thai</option>
<option value="tp">Tupi</option>
<option value="tr">Turkish</option>
<option value="uk">Ukrainian</option>
<option value="uz">Uzbek</option>
<option value="vi">Vietnamese</option>
<option value="cy">Welsh</option>
<option value="yi">Yiddish</option>
<option value="yo">Yoruba</option>
<option value="zu">Zulu</option>
</select>

<br><?= txt('genero') ?><sup><a id="source1" href="#endrefs">&nbsp;1&nbsp;</a></sup>:<br>
<select name="gender">
<option value="0"><?= txt('genero') ?>?</option>
<option value="1"><?= txt('bibliografico') ?></option>
<option value="2"><?= txt('cartografico') ?></option>
<option value="3"><?= txt('eletronico') ?></option>
<option value="4"><?= txt('filmografico') ?></option>
<option value="5"><?= txt('iconografico') ?></option>
<option value="6"><?= txt('micrografico') ?></option>
<option value="7"><?= txt('sonoro') ?></option>
<option value="8">Textual</option>
<option value="9"><?= txt('tridimensional') ?></option>
</select>

<br><?= txt('especie') ?><sup><a id="source2" href="#endrefs">&nbsp;2&nbsp;</a></sup>:<br>
<select name="species">
<option value="0"><?= txt('especie') ?>?</option>
<option value="1">Undersigned/Abaixo-assinado</option>
<option value="2">Agreement/Acordo</option>
<option value="3">Charter/Alvará</option>
<option value="4">Bench/Assento</option>
<option value="5">Protocol/Ata</option>
<option value="6">Attest/Atestado</option>
<option value="7">Auto</option>
<option value="8">Notice/Aviso</option>
<option value="9">Note/Bilhete</option>
<option value="10">Letter/Carta</option>
<option value="11">Open Letter/Carta aberta/Manifesto</option>
<option value="12">Business card/Cartão de visita</option>
<option value="13">Timecard/Cartão de ponto</option>
<option value="14">Poster/Cartaz</option>
<option value="15">Id card/Cédula de identidade</option>
<option value="16">Certificate/Certidão</option>
<option value="17">Certification/Certificado</option>
<option value="18">Check/Cheque</option>
<option value="19">Circular</option>
<option value="20">Communication/Comunicação/Paper</option>
<option value="21">Announcement/Comunicado</option>
<option value="22">Contract/Contrato</option>
<option value="23">Treaty/Convenção</option>
<option value="24">Invitation/Convite</option>
<option value="25">Convocation/Convocação</option>
<option value="26">Authentic copy/Cópia autêntica</option>
<option value="27">Badge/Crachá</option>
<option value="28">Curriculum/Currículo</option>
<option value="29">Declaration/Declaração</option>
<option value="30">Decree/Decreto</option>
<option value="31">Testimony/Depoimento</option>
<option value="32">Dispatch/Despacho</option>
<option value="33">Diary/Diário</option>
<option value="34">Diploma</option>
<option value="35">Dissertation/Dissertação</option>
<option value="36">Dossier/Dossiê</option>
<option value="37">Call/Edital</option>
<option value="38">Program/Ementa</option>
<option value="39">Charter/Escritura</option>
<option value="40">Statute/Estatuto</option>
<option value="41">Expedient/Expediente</option>
<option value="42">Extract/Extrato</option>
<option value="43">Invoice/Fatura</option>
<option value="44">Card/Ficha</option>
<option value="45">Flyer/Folheto/Folder/Prospecto</option>
<option value="46">Form/Formulário</option>
<option value="47">Guide/Guia</option>
<option value="48">Historic/Histórico</option>
<option value="49">Report/Informe</option>
<option value="50">Instruction/Instrução</option>
<option value="51">Inventory/Inventário</option>
<option value="52">Appraisal/Laudo</option>
<option value="53">Layout</option>
<option value="54">Law/Lei</option>
<option value="55">List/Lista/Listagem</option>
<option value="56">Book/Livro</option>
<option value="57">Map/Mapa</option>
<option value="58">Memorandum/Memorando</option>
<option value="59">Memory/Memória/Memorial</option>
<option value="60">Draught/Minuta</option>
<option value="61">Motion/Moção</option>
<option value="62">Norm/Norma</option>
<option value="63">Note/Nota</option>
<option value="64">Calling/Ofício</option>
<option value="65">Budget/Orçamento</option>
<option value="66">Order of service/Ordem de serviço</option>
<option value="67">Chart/Organograma</option>
<option value="68">Draft/Original/Rascunho</option>
<option value="69">Handout/Panfleto</option>
<option value="70">Slip/Papeleta</option>
<option value="71">Feedback/Parecer</option>
<option value="72">Partition/Partilha</option>
<option value="73">Score/Partitura</option>
<option value="74">Passport/Passaporte</option>
<option value="75">Schedule/Pauta</option>
<option value="76">Petition/Petição</option>
<option value="77">Spreadsheet/Planilha</option>
<option value="78">Plant/Planta</option>
<option value="79">Ordinance/Portaria</option>
<option value="80">Process/Processo</option>
<option value="81">Procuration/Procuração</option>
<option value="82">Program/Programa</option>
<option value="83">Project/Projeto</option>
<option value="84">Enchiridion/Prontuário</option>
<option value="85">Proposal/Proposta</option>
<option value="86">Record/Protocolo</option>
<option value="87">Proof/Prova</option>
<option value="88">Square/Quadro</option>
<option value="89">Quiz/Questionário</option>
<option value="90">Receipt/Receita</option>
<option value="91">Recibo</option>
<option value="92">Recorte/Clip</option>
<option value="93">Recurso</option>
<option value="94">Regimento</option>
<option value="95">Registro</option>
<option value="96">Regulamento</option>
<option value="97">Relação/Rol</option>
<option value="98">Relatório</option>
<option value="99">Release/Press release</option>
<option value="100">Request/Requerimento/Requisição</option>
<option value="101">Settling/Resolução</option>
<option value="102">Summary/Resumo</option>
<option value="103">Itinerary/Roteiro</option>
<option value="104">Synopsis/Sinopse</option>
<option value="105">Solicitation/Solicitação</option>
<option value="106">Table/Tabela</option>
<option value="107">Telegram/Telegrama</option>
<option value="108">Term/Termo</option>
<option value="109">Thesis/Tese</option>
<option value="110">Completion of Course Work/TCC- Trab. Concl. de Curso</option>
<option value="111">Credit title/Título de crédito</option>
<option value="112">Voucher/Vale</option>
</select>

<br><?= txt('tipodoc') ?><sup><a id="source3" href="#endrefs">&nbsp;3&nbsp;</a></sup>:<br>
<div id='ltype' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,49);" type="text" name="type" id="type" placeholder="<?= txt('tipodoc') ?>" maxlength="49">

<br><?= txt('numitens') ?>:<br>
<select name="items" id="items">
    <option value=0><?= txt('numitens') ?>?</option>
    <?php
    $contador = 0;
    while ($contador<99){
        $contador++;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
    }
    ?>
</select>

<br><?= txt('descricao') ?>:<br>
<div id='ldescription' class='ct'></div>
<textarea onkeyup="statosdotcom_Count(this,255);" id="description" name="description" rows=5 placeholder="<?= txt('descricao') ?>" maxlength="255"></textarea>

<br><?= txt('conteudo') ?>; <?= txt('transdescr') ?>:<br>
<div id='lcontents' class='ct'></div>
<textarea onkeyup="statosdotcom_Count(this,65535);" id="contents" name="contents" rows=20 placeholder="<?= txt('conteudo') ?>" maxlength="65535"></textarea>

<br><?= txt('autografo') ?> (<?= txt('escritoamao') ?>)?<br>
<select name="autograph">
<option value="0"><?= txt('autografo') ?>?</option>
<option value="1"><?= txt('lapis') ?></option>
<option value="2"><?= txt('canetaesf') ?></option>
<option value="3"><?= txt('canetatint') ?></option>
</select>

<br><?= txt('coraut') ?>:<br>
<div id='lautograph_color' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,19);" type="text" name="autograph_color" id="autograph_color" placeholder="<?= txt('coraut') ?>" maxlength="19">

<br><?= txt('datiloscrito') ?> (<?= txt('escritoamaq') ?>)?<br>
<select name="typewritten">
<option value="0"><?= txt('datiloscrito') ?>?</option>
<option value="1"><?= txt('sim') ?></option>
<option value="2"><?= txt('nao') ?></option>
</select>

<br><?= txt('datiloscritocor') ?>:<br>
<div id='ltypewritten_color' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,19);" type="text" name="typewritten_color" placeholder="<?= txt('datiloscritocor') ?>" maxlength="19">

<br><?= txt('midia') ?><sup><a href="javascript:alert('MESICON\n\nMaterial no qual são registradas as informações.\n\nMaterial in which information is recorded.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<?php
$meds = ['acetato','aço','algodão','alumínio','bronze','cera','cerâmica','cobre','couro','ferro','gesso','latão','linho','louça','madeira','mármore','metal','nitrato','ouro','papel','pedra','pergaminho','plástico','poliéster','prata','seda','vidro','vinil'];
?>
<select name="medium">
    <option value=""><?= txt('midia') ?>?</option>
    <?php foreach ($meds as $key => $med): ?>
        <option value="<?= $med ?>"><?= $med ?></option>
    <?php endforeach ?>
</select>

<br><?= txt('hamarca') ?>? <?= txt('transdescr') ?>:<br>
<div id='lwatermark' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="watermark" name="watermark" placeholder="<?= txt('hamarca') ?>?" maxlength="199">

<br><?= txt('paginas') ?>:<br>
<div id='lpages' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,4);" type="tel" id="pages" name="pages" placeholder="<?= txt('paginas') ?>" maxlength="4" onChange="this.value=this.value.replace(/[^0-9]+/g, '');"> <!-- regex refuses all but numbers -->

<br><?= txt('folhas') ?>:<br>
<div id='lleafs' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,4);" type="tel" id="leafs" name="leafs" placeholder="<?= txt('folhas') ?>" maxlength="4" onChange="this.value=this.value.replace(/[^0-9]+/g, '');">

<br><?= txt('largura') ?> (cm.):<br>
<div id='lwidth' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,3);" type="tel" id="width" name="width" placeholder="<?= txt('largura') ?>" maxlength="3" onChange="this.value=this.value.replace(/[^0-9]+/g, '');">

<br><?= txt('altura') ?> (cm.):<br>
<div id='lheight' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,3);" type="tel" id="height" name="height" placeholder="<?= txt('altura') ?>" maxlength="3" onChange="this.value=this.value.replace(/[^0-9]+/g, '');">
    
<br><?= txt('anexos') ?>? <?= txt('transdescr') ?>:<br>
<div id='lanex' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="anex" name="anex" placeholder="<?= txt('anexos') ?>" maxlength="199">

<br><?= txt('envelope') ?>? <?= txt('transdescr') ?>:<br>
<div id='lenvelope' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="envelope" name="envelope" placeholder="<?= txt('envelope') ?>" maxlength="199">

<br><?= txt('selo') ?>? <?= txt('transdescr') ?>:<br>
<div id='lstamp' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="stamp" name="stamp" placeholder="<?= txt('selo') ?>" maxlength="199">

<br><?= txt('carimbo') ?>? <?= txt('transdescr') ?>:<br>
<div id='limprint' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="imprint" name="imprint" placeholder="<?= txt('carimbo') ?>" maxlength="199">

<br><?= txt('datapost') ?>:<br>
<input type="date" name="post">

<br><?= txt('aspecdatapost') ?>:<br>
<select name="post_type">
<option value="0"><?= txt('aspecdatapost') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('datarec') ?>:<br>
<input type="date" name="receipt">

<br><?= txt('aspecdatarec') ?>:<br>
<select name="receipt_type">
<option value="0"><?= txt('aspecdatarec') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('portador') ?>? <?= txt('transdescr') ?>:<br>
<div id='lcarrier' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="carrier" name="carrier" placeholder="<?= txt('portador') ?>" maxlength="199">

<br><?= txt('emmaos') ?>?<br>
<select name="in_hands">
<option value="0"><?= txt('emmaos') ?>?</option>
<option value="1"><?= txt('sim') ?></option>
<option value="2"><?= txt('nao') ?></option>
</select>

<br><?= txt('notadest') ?>? <?= txt('transdescr') ?>:<br>
<div id='lnotes_recipient' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="notes_recipient" name="notes_recipient" placeholder="<?= txt('notadest') ?>" maxlength="199">

<br><?= txt('notaterc') ?>? <?= txt('transdescr') ?>:<br>
<div id='lnotes_third' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="notes_third" name="notes_third" placeholder="<?= txt('notaterc') ?>" maxlength="199">

<br><?= txt('conserva') ?><sup><a href="javascript:alert('MESICON\n\nDescreva detalhes, em item específico dentro de \'Nota da Pesquisa\', ao final, se possível historiando atividades de conservação e restauro. Ademais: descreva manchas, rasgos, quebras, dobras, ferrugem etc.\n\nDescribe details, in a specific item within the \'Research Note\', in the end, if possible historizing conservation and restoration activities. In addition: describe stains, tears, breaks, folds, rust etc.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<select name="conservation">
<option value="0"><?= txt('conserva') ?></option>
<option value="1"><?= txt('conservab') ?></option>
<option value="2"><?= txt('conservar') ?></option>
<option value="3"><?= txt('conservam') ?></option>
</select>

<br><?= txt('local') ?>:<br>
<div id='laddress' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="address" name="address" placeholder="<?= txt('local') ?>" maxlength="99">

<br><?= txt('acervo') ?>?<br>
<div id='lcollection' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="collection" name="collection" placeholder="<?= txt('acervo') ?>" maxlength="99">

<br><?= txt('acervoref') ?><sup><a href="javascript:alert('MESICON\n\nNúmero do documento, pasta e/ou caixa onde se encontra.\n\nDocument number, folder and/or box where it is located.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<div id='lref' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="ref" name="ref" placeholder="<?= txt('acervoref') ?>" maxlength="99">

<br><?= txt('onomastico') ?> (<?= txt('sobrenome') ?>, <?= txt('nome') ?>):<br>
<div id='lonomastic' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,255);" type="text" id="onomastic" name="onomastic" placeholder="<?= txt('onomastico') ?>" maxlength="255">

<br><?= txt('pseudo') ?>:<br>
<div id='lpseudonyms' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,255);" type="text" id="pseudonyms" name="pseudonyms" placeholder="<?= txt('pseudo') ?>" maxlength="255">

<br><?= txt('livrosmen') ?>:<br>
<div id='lmentioned_works' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,255);" type="text" id="mentioned_works" name="mentioned_works" placeholder="<?= txt('livrosmen') ?>" maxlength="255">

<br><?= txt('jornais') ?>:<br>
<div id='lperiodics' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,255);" type="text" id="periodics" name="periodics" placeholder="<?= txt('jornais') ?>" maxlength="255">

<br><?= txt('proveniencia') ?>:<br>
<div id='lhistoric' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,255);" type="text" id="historic" name="historic" placeholder="<?= txt('proveniencia') ?>" maxlength="255">

<br><?= txt('formaacq') ?>:<br>
<?php
$acqs = ['Lending/Comodato','Purchase/Compra','Custody/Custódia','Deposit/Depósito','Donation/Doação','Loan/Empréstimo','Bequest/Legado','Exchange/Permuta','Retreat/Recolhimento','Reinstatement/Reintegração','Transference/Transferência'];
?>
<select name="acquisition">
    <option value="" selected disabled><?= txt('formaacq') ?>?</option>
    <?php foreach ($acqs as $key => $acq): ?>
        <option value="<?= $acq ?>"><?= $acq ?></option>
    <?php endforeach ?>
</select>

<br><?= txt('dataacq') ?>:<br>
<input type="date" name="acq_date">

<br><?= txt('notadapesquisa') ?>:<br>
<div id='ladd_info' class='ct'></div>
<textarea onkeyup="statosdotcom_Count(this,65535);" name="add_info" id="add_info" rows=20 placeholder="<?= txt('notapesqtxt') ?>." maxlength="65535"></textarea>

<input type="hidden" name="updated_at" value="<?= randomDate() ?>">

<br>

<button type="submit" class="btn" name="create_manuscript" id="idBtnSend"><?= txt('revisar_M') ?></button>

<p id="endrefs" style="padding: 20px; font-size: 12px; text-align: justify">Refs.:
<br><a href="#source1">&nbsp;^ 1)</a> <?= txt('manref1') ?>.<br>
<br><a href="#source2">&nbsp;^ 2)</a> <?= txt('manref2') ?>.<br>
<br><a href="#source3">&nbsp;^ 3)</a> <?= txt('manref3') ?>.<br>
</p>

</h4>
</form>

<?php
} else {
    header("location: index.php");
    exit(0);
}

include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
