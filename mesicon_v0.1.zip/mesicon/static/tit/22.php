      dBBBBBBb  dBBBP.dBBBBP   dBP dBBBP  dBBBBP dBBBBb
       '   dB'       BP                  dB'.BP     dBP
    dB'dB'dB' dBBP   `BBBBb  dBP dBP    dB'.BP dBP dBP 
   dB'dB'dB' dBP        dBP dBP dBP    dB'.BP dBP dBP  
  dB'dB'dB' dBBBBP dBBBBP' dBP dBBBBP dBBBBP dBP dBP