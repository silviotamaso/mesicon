    dMMMMMMMMb  dMMMMMP .dMMMb  dMP .aMMMb  .aMMMb  dMMMMb 
   dMP"dMP"dMP dMP     dMP" VP amr dMP"VMP dMP"dMP dMP dMP 
  dMP dMP dMP dMMMP    VMMMb  dMP dMP     dMP dMP dMP dMP  
 dMP dMP dMP dMP     dP .dMP dMP dMP.aMP dMP.aMP dMP dMP   
dMP dMP dMP dMMMMMP  VMMMP" dMP  VMMMP"  VMMMP" dMP dMP