//////////////////////////////////////////////////
// https://github.com/silviotamaso/mesicon
// Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio
//
// This file is part of MESICON.
//
// MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with Foobar. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////

//Getting value from "ajax"
function fill(Value) {

   //Assigning value to "search" div in "search.php" file
   $('#search').val(Value);

   //Hiding "display" div in "search.php" file
   $('#display').hide();

}

$(document).ready(function() {

   //On pressing a key on "Search box" in "search.php" file. This function will be called
   $("#search").keyup(function() {

       //Assigning search box value to javascript variable named as "name"
       var name = $('#search').val();

       //Validating, if "name" is empty
       if (name == "") {

           //Assigning empty value to "display" div in "search.php" file
           $("#display").html("");

       }

       //If name is not empty
       else {

           //AJAX is called
           $.ajax({

               //AJAX type is "Post"
               type: "POST",

               //Data will be sent to "search_ajax.php"
               url: "search_ajax.php",

               //Data, that will be sent to "search_ajax.php"
               data: {

                   //Assigning value of "name" into "search" variable
                   search: name

               },

               //If result found, this funtion will be called
               success: function(html) {

                   //Assigning result to "display" div in "search.php" file
                   $("#display").html(html).show();

               }

           });

       }

   });

});
