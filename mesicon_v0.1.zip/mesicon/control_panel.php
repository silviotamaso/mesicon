<?php
include('config.php'); // start session, open conn, set charset
// include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');
?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->
 
<title>MESICON - Control Panel / Painel de Controle</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

    <h1><?= txt('paineldecontrole') ?></h1>
	
	<?php
    include('incl_messages.php');
	if ($_SESSION['user']['status'] == "Suspended") {
		echo "<h2><center><font color=red>User waiting for approval (Usuário aguardando aprovação).</font></center></h2>";
	} // suspended user; let him fight!
	?>

    <h2><br>
    <?php
        
    if ($_SESSION['user']['role'] == "Administrator") {
        // mt_rand(min,max), php function in below line, is four times faster than default "rand()". Both raise 10 chars and in "mt" if max < min it goes HADOUKEN
        echo "<a href='posts_adm.php?i=1#" . mt_rand(0000000000,9999999999) . "'>Posts</a><br>";
        echo "<br><a href='users.php#" . mt_rand(0000000000,9999999999) . "'>Users</a><br>";
        echo "<br><a href='create_book.php'>" . txt('cadastrarlivro') ."</a><br>";
        echo "<br><a href='create_manuscript.php'>" . txt('cadastrarmanuscrito') ."</a><br>";
        echo "<br><a href='link_book.php'>" . txt('vincularlivro') ."</a><br>";
        echo "<br><a href='comments.php#" . mt_rand(0000000000,9999999999) . "'>" . txt('avaliarcomentario') ."</a><br>";
        echo "<br><a href='latest.php#" . mt_rand(0000000000,9999999999) . "'>Latest Updates (home)</a><br>";
        echo "<br><a href='posts.php?i=1#" . mt_rand(0000000000,9999999999) . "'>" . txt('minhaspostagens') ."</a><br>";
        echo "<br><a href='user.php?id=" . $_SESSION['user']['id'] . "&v=p'>" . txt('meuperfil') ."</a>";
        
    } else if ($_SESSION['user']['role'] == "Manager") {
        if ($_SESSION['user']['status'] == "Waiting") echo "<br>Perfil em análise/Profile under analysis.<br><br>Por favor aguarde email com autorização/Please wait instructions by e-mail.";
        if ($_SESSION['user']['status'] == "Authorized") {
            echo "<a href='create_book.php'>" . txt('cadastrarlivro') ."</a><br>";
            echo "<br><a href='create_manuscript.php'>" . txt('cadastrarmanuscrito') ."</a><br>";
            echo "<br><a href='link_book.php'>" . txt('vincularlivro') ."</a><br>";
            echo "<br><a href='comments.php#" . mt_rand(0000000000,9999999999) . "'>" . txt('avaliarcomentario') ."</a><br>";
            echo "<br><a href='posts.php?o=created_at&o2=DESC#" . mt_rand(0000000000,9999999999) . "'>" . txt('minhaspostagens') ."</a><br>";
            echo "<br><a href='user.php?id=" . $_SESSION['user']['id'] . "&v=p'>" . txt('meuperfil') ."</a>";
        }
    } else {
        header("location: logout.php?p=index");
        exit(0);
    }

    ?>
    </h2>
	
<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>

