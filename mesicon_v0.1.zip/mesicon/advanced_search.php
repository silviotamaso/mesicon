<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php'); // using, by now, "esc()" and "getlastword()"
?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Advanced Search / Busca Avançada</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body, open pagediv -->

<?php
echo $_SESSION['message'];
?>

<h1><?= txt('busca_avancada') ?></h1><br>
(<?= txt('porenquantolivros') ?>) <!-- TODO -->

<?php
if ($_POST['p'] == 1) { // show results

global $conn;
$num_registros = 0;

$author = esc($_POST['author']);
$title = esc($_POST['title']);
$publisher = esc($_POST['publisher']);
$city = esc($_POST['city']);
//$etc = esc($_POST['etc']);

$sql = "SELECT * FROM 02_mesicon_books WHERE";

if ($_POST['author']) $sql = $sql . " author LIKE '%" . $author . "%'";
    
if ($_POST['title']) {
    if (getLastWord($sql) != "WHERE") $sql = $sql . " AND";
    $sql = $sql . " title LIKE '%" . $title . "%'";
}
    
if ($_POST['publisher']) {
    if (getLastWord($sql) != "WHERE") $sql = $sql . " AND"; 
    $sql = $sql . " publisher LIKE '%" . $publisher . "%'";
}
    
if ($_POST['city']) {
    if (getLastWord($sql) != "WHERE") $sql = $sql . " AND"; 
    $sql = $sql . " city LIKE '%" . $city . "%'";
}

if ($_POST['year'] != 0) {
    if (getLastWord($sql) != "WHERE") $sql = $sql . " AND"; 
    $sql = $sql . " year = " . $_POST['year'];
}

if ($_POST['manuscript'] != 0) {
    if (getLastWord($sql) != "WHERE") $sql = $sql . " AND"; 
    $sql = $sql . " manuscript = " . $_POST['manuscript'];
}

if ($_POST['idiom'] != 0) {
    if (getLastWord($sql) != "WHERE") $sql = $sql . " AND"; 
    if ($_POST['idiom'] == "pt") $sql = $sql . " idiom = 'pt'";
    else $sql = $sql . " idiom != 'pt'";
}

if ($_POST['country'] != 0) {
    if (getLastWord($sql) != "WHERE") $sql = $sql . " AND"; 
    if ($_POST['country'] == "Brasil") $sql = $sql . " country = 'Brasil'";
    else $sql = $sql . " country != 'Brasil'";
}

if ($_POST['exlibris'] != 0) {
    if (getLastWord($sql) != "WHERE") $sql = $sql . " AND"; 
    $sql = $sql . " exlibris = " . $_POST['exlibris'];
}

function searchAllDB($search){
    global $conn;
    $table = "02_mesicon_books";
    $out = "";
    $total = 0;
    $sql = "SHOW TABLES";
    $rs = $conn->query($sql);
    if($rs->num_rows > 0){
        while($r = $rs->fetch_array()){
            $table = $r[0];
            $sql_search = "select * from ".$table." where ";
            $sql_search_fields = Array();
            $sql2 = "SHOW COLUMNS FROM ".$table;
            $rs2 = $conn->query($sql2);
            if($rs2->num_rows > 0){
                while($r2 = $rs2->fetch_array()){
                    $colum = $r2[0];
                    $sql_search_fields[] = $colum." like('%".$search."%')";
                    if(strpos($colum,$search))
                    {
                        echo "FIELD NAME: ".$colum."\n";
                    }
                }
                $rs2->close();
            }
            $sql_search .= implode(" OR ", $sql_search_fields);
            $rs3 = $conn->query($sql_search);
            if($rs3 && $rs3->num_rows > 0)
            {
                $out .= $table.": ".$rs3->num_rows."\n";
                if($rs3->num_rows > 0){
                    $total += $rs3->num_rows;
                    $out.= print_r($rs3->fetch_all(),1);
                    $rs3->close();
                }
            }
        }
        $out .= "\n\nTotal results:".$total;
        $rs->close();
    }
    return $out;
}

if ($_POST['etc']) {
    //print_r(searchAllDB(esc($_POST['etc'])));
}

if ($_POST['author']) $sql = $sql . " ORDER BY title ASC";
else $sql = $sql . " ORDER BY author ASC";

// echo "<br><br>" . $sql . "<br>"; // debug ---------------------------------------

$result = mysqli_query($conn, $sql);
if ($result === FALSE) {
    echo "Error at advanced_search - mysqli.";
    die(); // TODO: better error handling
} else {
    $posts = array();
    while ($row = $result->fetch_assoc()) {
        $posts[] = $row;
        $num_registros++;
    }
}

echo "<br><br><h2>";

if ($_POST['author']) echo txt('autor') . " =~ '" . $_POST['author'] . "'<br>";
if ($_POST['title']) echo txt('titulo') . " =~ '" . $_POST['title'] . "'<br>";
if ($_POST['publisher']) echo txt('editora') . " =~ '" . $_POST['publisher'] . "'<br>";
if ($_POST['city']) echo txt('cidade') . " =~ '" . $_POST['city'] . "'<br>";
if ($_POST['year'] != 0) echo txt('anodepublicacao') . " = '" . $_POST['year'] . "'<br>";
if ($_POST['manuscript'] != 0) {
    if ($_POST['manuscript'] == 1) echo "apenas manuscritos<br>";
    else echo "manuscritos e livros<br>";
}
if ($_POST['idiom'] != 0) {
    echo txt('idioma');
    if ($_POST['idiom'] == "pt") echo ": português<br>";
    else echo ": não em português<br>"; // TODO: improve this
}
if ($_POST['country'] != 0) {
    echo txt('paisdepublicacao');
    if ($_POST['country'] == "Brasil") echo ": Brasil<br>";
    else echo ": não no Brasil<br>"; // TODO: improve this
}
if ($_POST['exlibris'] != 0) {
    echo txt('haexlibris');
    if ($_POST['exlibris'] == 1) echo ": " . txt('sim') . "<br>";
    else echo ": " . txt('nao') . "<br>";
}
//if ($_POST['etc']) echo "Etc =~ '" . $_POST['etc'] . "'<br>";

echo "<br><a href=advanced_search.php>&lt;&lt; " . txt('voltar') . "</a></h2><br><br>";

    echo "<p align=left>"; // TODO: implement function below and use it also on simple search

    if ($num_registros == 0) echo "<img src='static/spacer.gif' width='5%' height='1px'>" . txt('nenhumregistro') . ".<br><br>";
    
    for ($contador = 0; $contador < $num_registros; $contador++) {
        echo "<img src='static/spacer.gif' width='5%' height='1px'>" . $contador+1 . ". <a href='post.php?id=" . $posts[$contador]['id'] . "&t=1'>" . $posts[$contador]['author'] . ". <i>" . $posts[$contador]['title'] . "</i>.";
        
        if ($posts[$contador]['ed_number'] != 0) echo " " . $posts[$contador]['ed_number'] . ". ed.";

        if ($posts[$contador]['city'] != 0) echo " " . $posts[$contador]['city'];

        if (($posts[$contador]['city'] != 0) && ($posts[$contador]['publisher'] != 0)) echo ":";
        else echo ".";

        if ($posts[$contador]['publisher'] != 0) echo " " . $posts[$contador]['publisher'];

        if (($posts[$contador]['publisher'] != 0) && ($posts[$contador]['year'] != 0)) echo ",";
        else echo ".";

        if ($posts[$contador]['year'] != 0) echo " " . $posts[$contador]['year'];
        
        echo "</a> (" . txt('cadastradoem') . " " . $posts[$contador]['created_at'] . ", " . txt('por') . " <a href='user.php?id=" . $posts[$contador]['creator_id'] . "&v=p'>" . $posts[$contador]['creator'] . ")</a><br><br>";

}
    echo "</p>";

} else {

?>

<script>
<!--
window.addEventListener('load', 
  function() { 
    //alert('pg ended loading!');
    document.statosdotcomForm.author.focus();
  }, false);
function vai(el,m) {alert(m);el.focus();}
function i(f) { // TODO: complete validation
	//if (f.author.value=="") {vai(f.author,"MESICON\n\nDigite autor ou título/Type author or title.");return false;}
	//else {
		return true;
	//}
}
//function pensa() {document.body.style.cursor='wait';}

    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//-->
</script>

<form name="statosdotcomForm" method="post" action="advanced_search.php" onSubmit="return i(this);" style="display: inline; margin: 0;"><input type="hidden" name="p" value="1">

<input type="text" name="author" placeholder="<?= txt('autor') ?>">

<?= txt('eou') ?><br>

<input type="text" name="title" placeholder="<?= txt('titulo') ?>">

<?= txt('eou') ?><br>
    
<input type="text" name="publisher" placeholder="<?= txt('editora') ?>">

<?= txt('eou') ?><br>
    
<input type="text" name="city" placeholder="<?= txt('cidade') ?>">

<br><br><?= txt('eou') ?><br>

<select name="year" id="year">
<option value="0"><?= txt('anodepublicacao') ?></option>
<?php 
$contador = date("Y") + 1;
while ($contador>1882){
    $contador--;
    echo "<option value=" . $contador . ">" . $contador . "</option>";
}
?>
</select><br><br>  

<!-- TODO
e/ou<br>

<select name="manuscript" id="manuscript">
<option value="0">Só manuscritos ou também livros?</option>
<option value="1">Só manuscritos</option>
<option value="2">Apenas livros</option></select><br><br>  
-->
    
<?= txt('eou') ?><br>

<select name="idiom" id="idiom">
<option value="0"><?= txt('idioma') ?>?</option>
<option value="pt">Português</option>
<option value="1">Outro(s)/Another (und. constr.)</option></select><br><br> <!-- TODO: melhorar -->

<?= txt('eou') ?><br>

<select name="country" id="country">
<option value="0"><?= txt('paisdepublicacao') ?></option>
<option value="Brasil">Brasil</option>
<option value="1">Outro/Another (und. constr.)</option></select><br><br> <!-- TODO: melhorar -->  

<?= txt('eou') ?><br>

<select name="exlibris" id="exlibris">
<option value="0"><?= txt('haexlibris') ?>?</option>
<option value="1">Sim/Yes</option>
<option value="2">Não/No</option></select><br><br>  

<!--
e/ou<br>

<input type="text" name="etc" placeholder="Etc">
-->

<br><button type="submit" class="btn"><?= txt('buscar_M') ?></button><br>

<h4><a href=# onclick="javascript:statosdotcomForm.reset();"><?= txt('limpacampos') ?></a> - <a href="index.php"><?= txt('buscasimples') ?></a><br><br></h4>

</form>

<?php } ?>

<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
