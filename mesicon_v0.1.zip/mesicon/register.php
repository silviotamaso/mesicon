<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_registration_login.php');
?>

<script>
function vai(el,m) {alert(m);el.focus();}
window.addEventListener('load', 
	function() { // alert('pg ended loading!');
		document.statosdotcomForm.nome.focus();
	}, false
);
function i(f) {
	var letters = /^[A-Za-z]+$/;
	var my_checkbox = document.getElementById('check1');
	if (f.nome.value.match(letters)) { // limita entrada apenas a letras, sem acentos
		if (f.nome.value.length < 3) {alert('MESICON\n\nNome de usuário com ao menos três letras.\n\nUser name with at least 3 letters.');return false;}
		if (f.email1.value=="") {vai(f.email1,"MESICON\n\nE-mail?");return false;}
		else if (f.email1.value.indexOf("@")==-1 || f.email1.value.indexOf(".")==-1 || f.email1.value.indexOf(" ")==1 || f.email1.value.indexOf("/")==1 || f.email1.value.indexOf("@.")==1 || f.email1.value.indexOf(".@")==1) {vai(f.email1,"MESICON\n\nEmail inválido.\n\nInvalid e-mail.");return false;}
		else if (f.email2.value=="") {vai(f.email2,"MESICON\n\nRepita o email.\n\nRepeat e-mail.");return false;}
		else if (f.email1.value!=f.email2.value) {vai(f.email2,"MESICON\n\nEmails são diferentes.\n\nE-mails are different.");return false;}
		else if (f.pass.value=="") {
				vai(f.pass,"MESICON\n\nDigite uma senha.\n\nType in a password to use here.");return false;
			} else {
				if (my_checkbox.checked) {
                    var objBtn = document.getElementById('id-reg-user');
                    objBtn.style = 'color: #000000; background: #00ff00; cursor: not-allowed;';
                    objBtn.textContent = 'Aguarde/Wait...';
                    f.nome.value = f.nome.value.toLowerCase();
					f.encpass.value = sha3_224(f.pass.value);
					return true;
				} else {
					alert('MESICON\n\nVocê deve concordar com os Termos de Uso.\n\nYou have to agree with the Terms of Use.');
					return false;
				}
			}
	} else {
		// alert('Name rejected');
		alert('MESICON\n\nUse apenas letras no nome. Não use espaço, acento ou caracteres especiais.\n\nOnly letters allowed as user name. Do not use blank spaces or special chars.');
		return false;
	}
}
function statosdotcom_Count(obj,max) { if ((max-10) < obj.value.length) { document.getElementById("l"+obj.name).innerHTML = '<span style="color: red;">'+(max-obj.value.length)+'</span>'; } else { document.getElementById("l"+obj.name).innerHTML = (max-obj.value.length); }}
// function pensa() {document.body.style.cursor='wait';}
</script>
<script src="static/sha3-min.js"></script>

<style>
.ct { position: absolute; }
</style>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Register/Cadastro</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->
    
    <form name="statosdotcomForm" id="statosdotcomForm" method="post" action="register.php" onSubmit="return i(this);">
        <h1><?= txt('cadastro') ?></h1>
        <?php
        //include(ROOT_PATH . '/incl_errors.php')
        include('incl_errors.php');
        ?>
        <br><h3><?= txt('nomedeusuario') ?>:</h3>
        <div id='lnome' class='ct'></div>
        <input type="text" id="nome" name="nome" placeholder="<?= txt('nomedeusuario') ?>" onkeyup="statosdotcom_Count(this,8);" onchange="this.value=this.value.replace(/[\d]/g, '');" maxlength="8"> <!-- regex to forbid numbers -->
        <br><h3>Email:</h3>
        <input type="email" name="email1" placeholder="Email" maxlength="99">
        <br><h3><?= txt('repitaoemail') ?>:</h3>
        <input type="email" name="email2" placeholder="<?= txt('repitaoemail') ?>" maxlength="99">
        <br><h3><?= txt('senha') ?>:</h3>
        <div id='lpass' class='ct'></div>
        <input onkeyup="statosdotcom_Count(this,8);" type='password' id='pass' name='pass' placeholder="<?= txt('senha') ?>" maxlength="8"><input type="hidden" name="encpass">
        <br>
        <label for="check1"><input type="checkbox" id="check1"><h3><?= txt('aceitoos') ?> <a href="TOU.php" target="_blank"><?= txt('tou') ?></a></h3></label>
        
        <br><button name="reg-user" id="id-reg-user" type="submit" class="btn"><?= txt('cadastrar_M') ?></button>
        <br>
        <h3><?= txt('jacada') ?>? <a href="logout.php?p=login"><?= txt('entre') ?></a></h3>
    </form>

<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
