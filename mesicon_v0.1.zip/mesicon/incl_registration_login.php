<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<?php
// variable declaration
$username = "";
$email    = "";
$errors = array();




// REGISTER USER
if (isset($_POST['reg-user'])) {
    
    // receive values from the form
    $username = esc($_POST['nome']);
    $email = esc($_POST['email1']);
    $password = esc($_POST['encpass']);

    // form validation: ensure that the form is correctly filled
    if (empty($username)) array_push($errors, "Name?/Por favor, forneça o nome de usuário");
    if (empty($email)) array_push($errors, "Password?/Por favor, forneça a senha");
    if (empty($password)) array_push($errors, "Wrong pass/Senha errada");

    // Ensure that no user is registered twice. The email and usernames should be unique
    $user_check_query = "SELECT * FROM 02_mesicon_users WHERE username='$username' OR email='$email' LIMIT 1";

    $result = mysqli_query($conn, $user_check_query);
    $user = mysqli_fetch_assoc($result);

    if ($user) { // if user exists
        if ($user['username'] === $username) array_push($errors, "Name already used/Este nome de usuário já existe no sistema");
        if ($user['email'] === $email) array_push($errors, "Email already used/Este email já existe no sistema");
    }

    // register user if there are no errors in the form
    // loko demais, mas é isso mesmo: aqui os valores default vão sem acento mas quando vão entrar no banco ele reconhece o que já está enumerado lá (acentuado), e guarda o valor acentuado, ok por enquanto
    if (count($errors) == 0) {
        $query = "INSERT INTO 02_mesicon_users (username, email, role, password, status, created_at, updated_at, history) 
                  VALUES('$username', '$email', 'Manager', '$password', 'Authorized', now(), now(), '0')";
        mysqli_query($conn, $query);

        // get id of created user
        $reg_user_id = mysqli_insert_id($conn); 

        // put logged in user into session array
        // $_SESSION['user'] = getUserById($reg_user_id);
        $_SESSION['user']['id'] = getUserById($reg_user_id);

        $_SESSION['message'] = "Ok! Entre/Log in 2";

            // send confirmation mail

            $emailSubject = "(OK REGISTRO/REGISTER) MESICON";
            $msg = "Esta é uma mensagem automática, por favor não a responda\nThis is an automatic message, please do not respond to it.\n\n";
            $msg .= "----------\n";
            $msg .= "Seu nome de usuário:\nYour username:\n" . $username;
            $msg .= "\n\nSeu email cadastrado:\nYour registered e-mail:\n" . $email;
            $msg .= "\n\nSua senha não será exibida aqui por segurança. Para alterá-la utilize a opção 'Lembrar senha' no link abaixo:\nYour password will not be displayed here for security. To change it use 'Recover password ' here:\n\nhttp://statos.com/mesicon/login.php?e=" . $email . "\n";
            $msg .= "----------\n\n";
            $msg .= "Manuscritos e Edições SIstema de CONtrole - MESICON\n";
            $msg .= "statos.com/mesicon\n\n";
            $msg .= "Possui poder de decisão dentro de uma instituição pública? MESICON está disponível para doação!\nDo you have decision power within a public institution? MESICON is available for donation!\n\n";
            $msg .= "Se você considera esta mensagem um erro, delete-a sem problemas.\nIf you consider this message an error, please delete it.\n\n\n\n";

            $emailsender = "apps@statos.com";

            $headers = "MIME-Version: 1.1\n";
            $headers .= "Content-type: text/plain; charset=UTF-8\n";
            $headers .= "X-Priority: 1\n"; // send in max priority
            $headers .= "From: " . $emailsender . "\n"; // sender
            $headers .= "Return-Path: " . $emailsender . "\n"; // return-path

            // TODO - why email goes also on "else"??????????
            if(!mail($email, $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Postfix
                // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // not Postfix
                mail($email, $emailSubject, $msg, $headers );
                // sent
            } else {
                // error - TODO: error message!
            }

            // warns GOD
            $emailSubject = "(" . $email . " USER) MESICON";
            $msg = "Click to evaluate/Clique para avaliar:\n\n";
            $msg .= "http://www.statos.com/mesicon/new_user.php?e=" . $email . "&i=" . $_SESSION['user']['id'];
            $headers = "MIME-Version: 1.1\n";
            $headers .= "Content-type: text/plain; charset=UTF-8\n";
            $headers .= "X-Priority: 1\n"; // send in max priority
            $headers .= "From: " . $emailsender . "\n"; // sender
            $headers .= "Return-Path: " . $emailsender . "\n"; // return-path
            if(!mail("opeltrezero@gmail.com", $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Postfix
                // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // not Postfix
                mail("opeltrezero@gmail.com", $emailSubject, $msg, $headers );
                // sent
            } else {
                // error - TODO: error message!
            }

        header('location: login.php');
        exit(0);
    }
}










// TODO: flag in DB when used logged last time, this will ease delete those who registered and never logged in
// LOG USER IN
if (isset($_POST['login-btn'])) {
    $email = esc($_POST['email']);
    $password = esc($_POST['encpass']);

    if (empty($email)) { array_push($errors, "Email?"); }
    if (empty($password)) { array_push($errors, "Senha? Password?"); }
    if (empty($errors)) {
        $sql = "SELECT * FROM 02_mesicon_users WHERE email='$email' and password='$password' LIMIT 1";

        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            // get id of created user
            $reg_user_id = mysqli_fetch_assoc($result)['id']; 

            // put logged in user into session array
            $_SESSION['user'] = getUserById($reg_user_id);
            // $_SESSION['user']['id'] = getUserById($reg_user_id); 

            $_SESSION['message'] = "";
            //$_SESSION['user']['id'] = "";

            // if ADM enters without knock
            if ($_SESSION['user']['role'] == "Administrator") {
                $_SESSION['message'] = "God's in da house 1";
                header('location: control_panel.php');
                exit(0);
            }

            // only allows not suspended users
            if ($_SESSION['user']['status'] == "Suspended") {
                $_SESSION['message'] = "Error: envio/sending. Tente novamente/Try again 3";
                header('location: login.php'); exit(0);
            } else {
                //$_SESSION['message'] = "Manager 2";
                $_SESSION['message'] = "Gerente/Manager 2";
                if ($_SESSION['user']['role'] == "Manager") header('location: control_panel.php');
                else header('location: index.php');
                exit(0);
            }

        } else {
            array_push($errors, 'Email ou senha inválidos/Bad e-mail or password');
        }
    }
}











function esc(String $value) {
    global $conn;
	$val = trim($value); // remove empty space sorrounding string
	$val = str_replace('"','',$val); // del "
    $val = str_replace("'","",$val); // del '
    $val = str_replace("´","",$val); // del ´
    $val = str_replace("`","",$val); // del `
    $val = mysqli_real_escape_string($conn, $value);
    return $val;
} // escapes form submitted value, hence, preventing SQL injection // this function is also in "incl_functions.php", whan this change, change that also MOFO!

// Get user info from user id
function getUserById($id) {
    global $conn;
    $sql = "SELECT * FROM 02_mesicon_users WHERE id=$id LIMIT 1";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);
    // returns user in an array format: 
    // ['id'=>1 'username' => 'Awa', 'email'=>'a@a.com', 'password'=> 'mypass']
    return $user; 
} // this function only exists here, avoids that who is logged in loads "incl_functions.php" - if this will not be used in the future, delete from here MOFOOOOOOOOOO

?>


