<!DOCTYPE html>

<html> <!-- will be closed in incl_footer.php -->
    
<head>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->
     _        _                                 
    | |      | |                                
 ___| |_ __ _| |_ ___  ___   ___ ___  _ __ ___  
/ __| __/ _` | __/ _ \/ __| / __/ _ \| '_ ` _ \ 
\__ \ || (_| | || (_) \__ \| (_| (_) | | | | | |
|___/\__\__,_|\__\___/|___(_)___\___/|_| |_| |_|, May 2022.

-->

<link rel="stylesheet" href="static/css.css">

<meta name="viewport" content="width=device-width, initial-scale=1">
    
<?php
include('incl_lang.php');
?>

