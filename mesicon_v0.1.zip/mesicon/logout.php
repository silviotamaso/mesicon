<?php 

session_start();

//$_SESSION['user']['username'] == "";
//$_SESSION['user']['id'] == "";
$_SESSION['user'] == ""; // é o array raiz, que contém todos os ramos

// session_unset($_SESSION['user']); // talvez alteração abaixo corrija problema para deslogar - ago. 2021
// funfanfo perfeto - comentei pq quero manter o session do idioma // session_unset();

// funfanfo perfeto - comentei pq quero manter o session do idioma // session_destroy();






$_SESSION['user']['id'] = "";
$_SESSION['user']['username'] = "";
$_SESSION['user']['role'] = "";
$_SESSION['user']['status'] = "";
$_SESSION['message'] = "";










$page2go = $_GET['p'];

// session_start();

if ($page2go == "index") $_SESSION['message'] = "Deslogado/Logged out 2";

header('location: ' . $page2go . '.php');

exit()
        
?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->
