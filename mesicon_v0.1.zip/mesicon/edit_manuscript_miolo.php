<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<input type='hidden' name='id' value='<?php echo $id; ?>'>
<input type='hidden' name='creator' value='<?= $post['creator'] ?>'>
<input type='hidden' name='creator_id' value='<?= $post['creator_id'] ?>'>

<br><?= txt('casohajainfo') ?>.<br><br>

<font color='red'>*</font> <?= txt('autorman') ?><sup><a href="javascript:alert('MESICON\n\nUse \';\' para separar nomes.\n\nUse \';\' to separate names.');">&nbsp;&#9432;&nbsp;</a></sup> (<?= txt('sobrenome') ?>, <?= txt('nome') ?>):<br>
<div id='lauthor' class='ct'></div>
<input onkeyup='statosdotcom_Count(this,199);' type='text' name='author' id='author' value='<?= $post['author'] ?>' placeholder='<?= txt('autorman') ?>' maxlength='199'>

<br><?= txt('aspectoautor') ?>:<br>
<select name='author_type' id='author_type'>
<?php
if ($post['author_type'] == '0') echo "<option value='0' selected>" . txt('aspectoautor') . "?</option>";
if ($post['author_type'] == '1') echo "<option value='1' selected>" . txt('expresso') . "</option>";
if ($post['author_type'] == '2') echo "<option value='2' selected>" . txt('presumido') . "</option>";
?>
<option value='0'><?= txt('aspectoautor') ?>?</option>
<option value='1'><?= txt('expresso') ?></option>
<option value='2'><?= txt('presumido') ?></option>
</select>

<br><?= txt('originalidade') ?>:<br>
<select name='original' id='original'>
<?php
if ($post['original'] == '0') echo "<option value='0' selected>" . txt('originalidade') . "?</option>";
if ($post['original'] == '1') echo "<option value='1' selected>" . txt('originalidade') . " " . txt('expresso') . "</option>";
if ($post['original'] == '2') echo "<option value='2' selected>" . txt('copiaourep') . " " . txt('expresso') . "</option>";
if ($post['original'] == '3') echo "<option value='3' selected>" . txt('originalidade') . "/" . txt('copiaourep') . " " . txt('presumido') . "</option>";
?>
<option value='0'><?= txt('originalidade') ?>?</option>
<option value='1'><?= txt('originalidade') ?> <?= txt('expresso') ?></option>
<option value='2'><?= txt('copiaourep') ?> <?= txt('expresso') ?></option>
<option value='3'><?= txt('originalidade') ?>/<?= txt('copiaourep') ?> <?= txt('presumido') ?></option>
</select>

<br><?= txt('copiadetalhe') ?><sup><a href="javascript:alert('MESICON\n\nÉ cópia carbono, qual a cor? Impresso por computador? Cópia datilográfica? Forneça detalhes.\n\nIs it a carbon copy? Printed by computer or typerwitten? Give details.');">&nbsp;&#9432;&nbsp;</a></sup><br>
<div id='lcopy' class='ct'></div>
<?php
if ($post['copy'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='copy' id='copy' placeholder='" . txt('copiadetalhe') . "' maxlength='99'>";
else echo "<input onkeyup='statosdotcom_Count(this,99);' value='" . $post['copy'] . "' type='text' name='copy' id='copy' placeholder='" . txt('copiadetalhe') . "' maxlength='99'>";
?>

<br><?= txt('titulo') ?>:<br>
<div id='ltitle' class='ct'></div>
<?php
if ($post['title'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' name='title' id='title' placeholder='" . txt('titulo') . "' maxlength='99'>";
else echo "<input onkeyup='statosdotcom_Count(this,99);' value='" . $post['title'] . "' type='text' name='title' id='title' placeholder='" . txt('titulo') . "' maxlength='99'>";
?>

<br><?= txt('aspectotitulo') ?>:<br>
<select name='title_type' id='title_type'>
<?php
if ($post['title_type'] == '0') echo "<option value='0' selected>" . txt('aspectotitulo') . "</option>";
if ($post['title_type'] == '1') echo "<option value='1' selected>" . txt('expresso') . "</option>";
if ($post['title_type'] == '2') echo "<option value='2' selected>" . txt('presumido') . "</option>";
?>
<option value='0'><?= txt('aspectotitulo') ?>?</option>
<option value='1'><?= txt('expresso') ?></option>
<option value='2'><?= txt('presumido') ?></option>
</select>

<br><?= txt('autorsign') ?>:<br>
<div id='lsignature' class='ct'></div>
<?php
if ($post['signature'] == 0) echo "<input onkeyup='statosdotcom_Count(this,49);' type='text' name='signature' id='signature' placeholder='" . txt('autorsign') . "' maxlength='49'>";
else echo "<input onkeyup='statosdotcom_Count(this,49);' value='" . $post['signature'] . "' type='text' name='signature' id='signature' placeholder='" . txt('autorsign') . "' maxlength='49'>";
?>

<br><?= txt('localorigem') ?>:<br>
<div id='lsource_local' class='ct'></div>
<?php
if ($post['source_local'] == 0) echo "<input onkeyup='statosdotcom_Count(this,49);' type='text' id='source_local' name='source_local' placeholder='" . txt('localorigem') . "' maxlength='49'>";
else echo "<input onkeyup='statosdotcom_Count(this,49);' value='" . $post['source_local'] . "' type='text' id='source_local' name='source_local' placeholder='" . txt('localorigem') . "' maxlength='49'>";
?>

<br><?= txt('aspectoorigem') ?>:<br>
<select name='source_local_type' id='source_local_type'>
<?php
if ($post['source_local_type'] == '0') echo "<option value='0' selected>" . txt('aspectoorigem') . "</option>";
if ($post['source_local_type'] == '1') echo "<option value='1' selected>" . txt('expresso') . "</option>";
if ($post['source_local_type'] == '2') echo "<option value='2' selected>" . txt('presumido') . "</option>";
?>
<option value='0'><?= txt('aspectoorigem') ?>?</option>
<option value='1'><?= txt('expresso') ?></option>
<option value='2'><?= txt('presumido') ?></option>
</select>

<br><?= txt('destinatario') ?><sup><a href="javascript:alert('MESICON\n\nUse \';\' para separar nomes.\n\nUse \';\' to separate names.');">&nbsp;&#9432;&nbsp;</a></sup> (<?= txt('sobrenome') ?>, <?= txt('nome') ?>):<br>
<div id='lrecipient' class='ct'></div>
<?php
if ($post['recipient'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' name='recipient' id='recipient' placeholder='" . txt('destinatario') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['recipient'] . "' type='text' name='recipient' id='recipient' placeholder='" . txt('destinatario') . "' maxlength='199'>";
?>

<br><?= txt('aspectodestinatario') ?>:<br>
<select name='recipient_type' id='recipient_type'>
<?php
if ($post['recipient_type'] == '0') echo "<option value='0' selected>" . txt('aspectodestinatario') . "</option>";
if ($post['recipient_type'] == '1') echo "<option value='1' selected>" . txt('expresso') . "</option>";
if ($post['recipient_type'] == '2') echo "<option value='2' selected>" . txt('presumido') . "</option>";
?>
<option value='0'><?= txt('aspectodestinatario') ?>?</option>
<option value='1'><?= txt('expresso') ?></option>
<option value='2'><?= txt('presumido') ?></option>
</select>

<br><?= txt('localdestino') ?>:<br>
<div id='ldestination' class='ct'></div>
<?php
if ($post['destination'] == 0) echo "<input onkeyup='statosdotcom_Count(this,49);' type='text' name='destination' id='destination' placeholder='" . txt('localdestino') . "' maxlength='49'>";
else echo "<input onkeyup='statosdotcom_Count(this,49);' value='" . $post['destination'] . "' type='text' name='destination' id='destination' placeholder='" . txt('localdestino') . "' maxlength='49'>";
?>

<br><?= txt('aspectodestino') ?>:<br>
<select name='destination_type' id='destination_type'>
<?php
if ($post['destination_type'] == '0') echo "<option value='0' selected>" . txt('aspectodestino') . "</option>";
if ($post['destination_type'] == '1') echo "<option value='1' selected>" . txt('expresso') . "</option>";
if ($post['destination_type'] == '2') echo "<option value='2' selected>" . txt('presumido') . "</option>";
?>
<option value='0'><?= txt('aspectodestino') ?>?</option>
<option value='1'><?= txt('expresso') ?></option>
<option value='2'><?= txt('presumido') ?></option>
</select>

<br><?= txt('formatrata') ?><sup><a href="javascript:alert('MESICON\n\nComo o autor se dirige ao destinatário.\n\nHow the author addesses the recipient.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<div id='ltreatment' class='ct'></div>
<?php
if ($post['treatment'] == 0) echo "<input onkeyup='statosdotcom_Count(this,49);' type='text' id='treatment' name='treatment' placeholder='" . txt('formatrata') . "' maxlength='49'>";
else echo "<input onkeyup='statosdotcom_Count(this,49);' value='" . $post['treatment'] . "' type='text' id='treatment' name='treatment' placeholder='" . txt('formatrata') . "' maxlength='49'>";
?>

<br>Post scriptum<sup><a href="javascript:alert('MESICON\n\nHá anotações posteriores, mesmo que de terceiros? Há assinatura? Descreva e/ou transcreva.\n\nThere is/are later notes? Signed? Describe/transcribe it.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<div id='lpostscript' class='ct'></div>
<?php
if ($post['postscript'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='postscript' name='postscript' placeholder='Post scriptum' maxlength='199' style='display: inline; margin: 0;'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['postscript'] . "' type='text' id='postscript' name='postscript' placeholder='Post scriptum' maxlength='199' style='display: inline; margin: 0;'>";
?>

<br><br><br><?= txt('data') ?>:<br>
<input type='date' name='data' value='<?= $post['data'] ?>'>

<br><?= txt('aspectodata') ?>:<br>
<select name='data_type' id='data_type'>
<?php
if ($post['data_type'] == '0') echo "<option value='0' selected>" . txt('aspectodata') . "</option>";
if ($post['data_type'] == '1') echo "<option value='1' selected>" . txt('expresso') . "</option>";
if ($post['data_type'] == '2') echo "<option value='2' selected>" . txt('presumido') . "</option>";
?>
<option value='0'><?= txt('aspectodata') ?>?</option>
<option value='1'><?= txt('expresso') ?></option>
<option value='2'><?= txt('presumido') ?></option>
</select>

<br><br><?= txt('idioma') ?> (<?= txt('predominante') ?>):<br>
<!-- <label for='idiom'>Idioma:</label> -->
<select id='idiom' name='idiom'>
<?php
if ($post['idiom'] == '0') echo "<option value='0' selected>" . txt('idioma') . "</option>";
if ($post['idiom'] == 'pt') echo "<option value='pt' selected>Português</option>";
if ($post['idiom'] == 'af') echo "<option value='af' selected>Afrikaans</option>";
if ($post['idiom'] == 'sq') echo "<option value='sq' selected>Albanian</option>";
if ($post['idiom'] == 'ar') echo "<option value='ar' selected>Arabic</option>";
if ($post['idiom'] == 'hy') echo "<option value='hy' selected>Armenian</option>";
if ($post['idiom'] == 'az') echo "<option value='az' selected>Azerbaijani</option>";
if ($post['idiom'] == 'eu') echo "<option value='eu' selected>Basque</option>";
if ($post['idiom'] == 'be') echo "<option value='be' selected>Belarusian</option>";
if ($post['idiom'] == 'bs') echo "<option value='bs' selected>Bosnian</option>";
if ($post['idiom'] == 'bg') echo "<option value='bg' selected>Bulgarian</option>";
if ($post['idiom'] == 'ca') echo "<option value='ca' selected>Catalan</option>";
if ($post['idiom'] == 'zh') echo "<option value='zh' selected>Chinese</option>";
if ($post['idiom'] == 'hr') echo "<option value='hr' selected>Croatian</option>";
if ($post['idiom'] == 'cs') echo "<option value='cs' selected>Czech</option>";
if ($post['idiom'] == 'da') echo "<option value='da' selected>Danish</option>";
if ($post['idiom'] == 'nl') echo "<option value='nl' selected>Dutch</option>";
if ($post['idiom'] == 'en') echo "<option value='en' selected>English</option>";
if ($post['idiom'] == 'eo') echo "<option value='eo' selected>Esperanto</option>";
if ($post['idiom'] == 'et') echo "<option value='et' selected>Estonian</option>";
if ($post['idiom'] == 'fl') echo "<option value='fl' selected>Filipino</option>";
if ($post['idiom'] == 'fi') echo "<option value='fi' selected>Finnish</option>";
if ($post['idiom'] == 'fr') echo "<option value='fr' selected>French</option>";
if ($post['idiom'] == 'de') echo "<option value='de' selected>German</option>";
if ($post['idiom'] == 'el') echo "<option value='el' selected>Greek</option>";
if ($post['idiom'] == 'gn') echo "<option value='gn' selected>Guarani</option>";
if ($post['idiom'] == 'hn') echo "<option value='hn' selected>Hawaiian</option>";
if ($post['idiom'] == 'he') echo "<option value='he' selected>Hebrew</option>";
if ($post['idiom'] == 'hi') echo "<option value='hi' selected>Hindi</option>";
if ($post['idiom'] == 'hu') echo "<option value='hu' selected>Hungarian</option>";
if ($post['idiom'] == 'is') echo "<option value='is' selected>Icelandic</option>";
if ($post['idiom'] == 'id') echo "<option value='id' selected>Indonesian</option>";
if ($post['idiom'] == 'ga') echo "<option value='ga' selected>Irish</option>";
if ($post['idiom'] == 'it') echo "<option value='it' selected>Italian</option>";
if ($post['idiom'] == 'ja') echo "<option value='ja' selected>Japanese</option>";
if ($post['idiom'] == 'kk') echo "<option value='kk' selected>Kazakh</option>";
if ($post['idiom'] == 'ko') echo "<option value='ko' selected>Korean</option>";
if ($post['idiom'] == 'la') echo "<option value='la' selected>Latin</option>";
if ($post['idiom'] == 'lv') echo "<option value='lv' selected>Latvian</option>";
if ($post['idiom'] == 'lt') echo "<option value='lt' selected>Lithuanian</option>";
if ($post['idiom'] == 'mk') echo "<option value='mk' selected>Macedonian</option>";
if ($post['idiom'] == 'ms') echo "<option value='ms' selected>Malay</option>";
if ($post['idiom'] == 'mt') echo "<option value='mt' selected>Maltese</option>";
if ($post['idiom'] == 'mn') echo "<option value='mn' selected>Mongolian</option>";
if ($post['idiom'] == 'ne') echo "<option value='ne' selected>Nepali</option>";
if ($post['idiom'] == 'no') echo "<option value='no' selected>Norwegian</option>";
if ($post['idiom'] == 'fa') echo "<option value='fa' selected>Persian</option>";
if ($post['idiom'] == 'pl') echo "<option value='pl' selected>Polish</option>";
if ($post['idiom'] == 'pt') echo "<option value='pt' selected>Português</option>";
if ($post['idiom'] == 'pa') echo "<option value='pa' selected>Punjabi</option>";
if ($post['idiom'] == 'qu') echo "<option value='qu' selected>Quechua</option>";
if ($post['idiom'] == 'ro') echo "<option value='ro' selected>Romanian</option>";
if ($post['idiom'] == 'rm') echo "<option value='rm' selected>Romansh</option>";
if ($post['idiom'] == 'ru') echo "<option value='ru' selected>Russian</option>";
if ($post['idiom'] == 'gd') echo "<option value='gd' selected>Scottish Gaelic</option>";
if ($post['idiom'] == 'sr') echo "<option value='sr' selected>Serbian</option>";
if ($post['idiom'] == 'sk') echo "<option value='sk' selected>Slovak</option>";
if ($post['idiom'] == 'sl') echo "<option value='sl' selected>Slovenian</option>";
if ($post['idiom'] == 'es') echo "<option value='es' selected>Spanish</option>";
if ($post['idiom'] == 'su') echo "<option value='su' selected>Sundanese</option>";
if ($post['idiom'] == 'sw') echo "<option value='sw' selected>Swahili</option>";
if ($post['idiom'] == 'sv') echo "<option value='sv' selected>Swedish</option>";
if ($post['idiom'] == 'th') echo "<option value='th' selected>Thai</option>";
if ($post['idiom'] == 'tp') echo "<option value='tp' selected>Tupi</option>";
if ($post['idiom'] == 'tr') echo "<option value='tr' selected>Turkish</option>";
if ($post['idiom'] == 'uk') echo "<option value='uk' selected>Ukrainian</option>";
if ($post['idiom'] == 'uz') echo "<option value='uz' selected>Uzbek</option>";
if ($post['idiom'] == 'vi') echo "<option value='vi' selected>Vietnamese</option>";
if ($post['idiom'] == 'cy') echo "<option value='cy' selected>Welsh</option>";
if ($post['idiom'] == 'yi') echo "<option value='yi' selected>Yiddish</option>";
if ($post['idiom'] == 'yo') echo "<option value='yo' selected>Yoruba</option>";
if ($post['idiom'] == 'zu') echo "<option value='zu' selected>Zulu</option>";
?>
<option value='0'><?= txt('idioma') ?></option>
<option value='pt'>Português</option>
<option value='af'>Afrikaans</option>
<option value='sq'>Albanian</option>
<option value='ar'>Arabic</option>
<option value='hy'>Armenian</option>
<option value='az'>Azerbaijani</option>
<option value='eu'>Basque</option>
<option value='be'>Belarusian</option>
<option value='bs'>Bosnian</option>
<option value='bg'>Bulgarian</option>
<option value='ca'>Catalan</option>
<option value='zh'>Chinese</option>
<option value='hr'>Croatian</option>
<option value='cs'>Czech</option>
<option value='da'>Danish</option>
<option value='nl'>Dutch</option>
<option value='en'>English</option>
<option value='eo'>Esperanto</option>
<option value='et'>Estonian</option>
<option value='fl'>Filipino</option>
<option value='fi'>Finnish</option>
<option value='fr'>French</option>
<option value='de'>German</option>
<option value='el'>Greek</option>
<option value='gn'>Guarani</option>
<option value='hn'>Hawaiian</option>
<option value='he'>Hebrew</option>
<option value='hi'>Hindi</option>
<option value='hu'>Hungarian</option>
<option value='is'>Icelandic</option>
<option value='id'>Indonesian</option>
<option value='ga'>Irish</option>
<option value='it'>Italian</option>
<option value='ja'>Japanese</option>
<option value='kk'>Kazakh</option>
<option value='ko'>Korean</option>
<option value='la'>Latin</option>
<option value='lv'>Latvian</option>
<option value='lt'>Lithuanian</option>
<option value='mk'>Macedonian</option>
<option value='ms'>Malay</option>
<option value='mt'>Maltese</option>
<option value='mn'>Mongolian</option>
<option value='ne'>Nepali</option>
<option value='no'>Norwegian</option>
<option value='fa'>Persian</option>
<option value='pl'>Polish</option>
<option value='pt'>Português</option>
<option value='pa'>Punjabi</option>
<option value='qu'>Quechua</option>
<option value='ro'>Romanian</option>
<option value='rm'>Romansh</option>
<option value='ru'>Russian</option>
<option value='gd'>Scottish Gaelic</option>
<option value='sr'>Serbian</option>
<option value='sk'>Slovak</option>
<option value='sl'>Slovenian</option>
<option value='es'>Spanish</option>
<option value='su'>Sundanese</option>
<option value='sw'>Swahili</option>
<option value='sv'>Swedish</option>
<option value='th'>Thai</option>
<option value='tp'>Tupi</option>
<option value='tr'>Turkish</option>
<option value='uk'>Ukrainian</option>
<option value='uz'>Uzbek</option>
<option value='vi'>Vietnamese</option>
<option value='cy'>Welsh</option>
<option value='yi'>Yiddish</option>
<option value='yo'>Yoruba</option>
<option value='zu'>Zulu</option>
</select>

<br><?= txt('genero') ?><sup><a id='source1' href='#endrefs'>&nbsp;1&nbsp;</a></sup>:<br>
<select name='gender' id='gender'>
<?php
if ($post['gender'] == '0') echo "<option value='0' selected>" . txt('genero') . "?</option>";
if ($post['gender'] == '1') echo "<option value='1' selected>" . txt('bibliografico') . "</option>";
if ($post['gender'] == '2') echo "<option value='2' selected>" . txt('cartografico') . "</option>";
if ($post['gender'] == '3') echo "<option value='3' selected>" . txt('eletronico') . "</option>";
if ($post['gender'] == '4') echo "<option value='4' selected>" . txt('filmografico') . "</option>";
if ($post['gender'] == '5') echo "<option value='5' selected>" . txt('iconografico') . "</option>";
if ($post['gender'] == '6') echo "<option value='6' selected>" . txt('micrografico') . "</option>";
if ($post['gender'] == '7') echo "<option value='7' selected>" . txt('sonoro') . "</option>";
if ($post['gender'] == '8') echo "<option value='8' selected>Textual</option>";
if ($post['gender'] == '9') echo "<option value='9' selected>" . txt('tridimensional') . "</option>";
?>
<option value='0'><?= txt('genero') ?>?</option>
<option value='1'><?= txt('bibliografico') ?></option>
<option value='2'><?= txt('cartografico') ?></option>
<option value='3'><?= txt('eletronico') ?></option>
<option value='4'><?= txt('filmografico') ?></option>
<option value='5'><?= txt('iconografico') ?></option>
<option value='6'><?= txt('micrografico') ?></option>
<option value='7'><?= txt('sonoro') ?></option>
<option value='8'>Textual</option>
<option value='9'><?= txt('tridimensional') ?></option>
</select>

<br><?= txt('especie') ?><sup><a id='source2' href='#endrefs'>&nbsp;2&nbsp;</a></sup>:<br>
<select name='species' id='species'>
<?php
if ($post['species'] == '0') echo "<option value='0' selected>" . txt('especie') . "</option>";
if ($post['species'] == '1') echo "<option value='1' selected>Abaixo-assinado</option>";
if ($post['species'] == '2') echo "<option value='2' selected>Acordo</option>";
if ($post['species'] == '3') echo "<option value='3' selected>Alvará</option>";
if ($post['species'] == '4') echo "<option value='4' selected>Assento</option>";
if ($post['species'] == '5') echo "<option value='5' selected>Ata</option>";
if ($post['species'] == '6') echo "<option value='6' selected>Atestado</option>";
if ($post['species'] == '7') echo "<option value='7' selected>Auto</option>";
if ($post['species'] == '8') echo "<option value='8' selected>Aviso</option>";
if ($post['species'] == '9') echo "<option value='9' selected>Bilhete</option>";
if ($post['species'] == '10') echo "<option value='10' selected>Carta</option>";
if ($post['species'] == '11') echo "<option value='11' selected>Carta aberta/Manifesto</option>";
if ($post['species'] == '12') echo "<option value='12' selected>Cartão de visita</option>";
if ($post['species'] == '13') echo "<option value='13' selected>Cartão de ponto</option>";
if ($post['species'] == '14') echo "<option value='14' selected>Cartaz</option>";
if ($post['species'] == '15') echo "<option value='15' selected>Cédula de identidade</option>";
if ($post['species'] == '16') echo "<option value='16' selected>Certidão</option>";
if ($post['species'] == '17') echo "<option value='17' selected>Certificado</option>";
if ($post['species'] == '18') echo "<option value='18' selected>Cheque</option>";
if ($post['species'] == '19') echo "<option value='19' selected>Circular</option>";
if ($post['species'] == '20') echo "<option value='20' selected>Comunicação/Paper</option>";
if ($post['species'] == '21') echo "<option value='21' selected>Comunicado</option>";
if ($post['species'] == '22') echo "<option value='22' selected>Contrato</option>";
if ($post['species'] == '23') echo "<option value='23' selected>Convenção</option>";
if ($post['species'] == '24') echo "<option value='24' selected>Convite</option>";
if ($post['species'] == '25') echo "<option value='25' selected>Convocação</option>";
if ($post['species'] == '26') echo "<option value='26' selected>Cópia autêntica</option>";
if ($post['species'] == '27') echo "<option value='27' selected>Crachá</option>";
if ($post['species'] == '28') echo "<option value='28' selected>Currículo</option>";
if ($post['species'] == '29') echo "<option value='29' selected>Declaração</option>";
if ($post['species'] == '30') echo "<option value='30' selected>Decreto</option>";
if ($post['species'] == '31') echo "<option value='31' selected>Depoimento</option>";
if ($post['species'] == '32') echo "<option value='32' selected>Despacho</option>";
if ($post['species'] == '33') echo "<option value='33' selected>Diário</option>";
if ($post['species'] == '34') echo "<option value='34' selected>Diploma</option>";
if ($post['species'] == '35') echo "<option value='35' selected>Dissertação</option>";
if ($post['species'] == '36') echo "<option value='36' selected>Dossiê</option>";
if ($post['species'] == '37') echo "<option value='37' selected>Edital</option>";
if ($post['species'] == '38') echo "<option value='38' selected>Ementa</option>";
if ($post['species'] == '39') echo "<option value='39' selected>Escritura</option>";
if ($post['species'] == '40') echo "<option value='40' selected>Estatuto</option>";
if ($post['species'] == '41') echo "<option value='41' selected>Expediente</option>";
if ($post['species'] == '42') echo "<option value='42' selected>Extrato</option>";
if ($post['species'] == '43') echo "<option value='43' selected>Fatura</option>";
if ($post['species'] == '44') echo "<option value='44' selected>Ficha</option>";
if ($post['species'] == '45') echo "<option value='45' selected>Folheto/Folder/Prospecto</option>";
if ($post['species'] == '46') echo "<option value='46' selected>Formulário</option>";
if ($post['species'] == '47') echo "<option value='47' selected>Guia</option>";
if ($post['species'] == '48') echo "<option value='48' selected>Histórico</option>";
if ($post['species'] == '49') echo "<option value='49' selected>Informe</option>";
if ($post['species'] == '50') echo "<option value='50' selected>Instrução</option>";
if ($post['species'] == '51') echo "<option value='51' selected>Inventário</option>";
if ($post['species'] == '52') echo "<option value='52' selected>Laudo</option>";
if ($post['species'] == '53') echo "<option value='53' selected>Layout</option>";
if ($post['species'] == '54') echo "<option value='54' selected>Lei</option>";
if ($post['species'] == '55') echo "<option value='55' selected>Lista/Listagem</option>";
if ($post['species'] == '56') echo "<option value='56' selected>Livro</option>";
if ($post['species'] == '57') echo "<option value='57' selected>Mapa</option>";
if ($post['species'] == '58') echo "<option value='58' selected>Memorando</option>";
if ($post['species'] == '59') echo "<option value='59' selected>Memória/Memorial</option>";
if ($post['species'] == '60') echo "<option value='60' selected>Minuta</option>";
if ($post['species'] == '61') echo "<option value='61' selected>Moção</option>";
if ($post['species'] == '62') echo "<option value='62' selected>Norma</option>";
if ($post['species'] == '63') echo "<option value='63' selected>Nota</option>";
if ($post['species'] == '64') echo "<option value='64' selected>Ofício</option>";
if ($post['species'] == '65') echo "<option value='65' selected>Orçamento</option>";
if ($post['species'] == '66') echo "<option value='66' selected>Ordem de serviço</option>";
if ($post['species'] == '67') echo "<option value='67' selected>Organograma</option>";
if ($post['species'] == '68') echo "<option value='68' selected>Original/Rascunho</option>";
if ($post['species'] == '69') echo "<option value='69' selected>Panfleto</option>";
if ($post['species'] == '70') echo "<option value='70' selected>Papeleta</option>";
if ($post['species'] == '71') echo "<option value='71' selected>Parecer</option>";
if ($post['species'] == '72') echo "<option value='72' selected>Partilha</option>";
if ($post['species'] == '73') echo "<option value='73' selected>Partitura</option>";
if ($post['species'] == '74') echo "<option value='74' selected>Passaporte</option>";
if ($post['species'] == '75') echo "<option value='75' selected>Pauta</option>";
if ($post['species'] == '76') echo "<option value='76' selected>Petição</option>";
if ($post['species'] == '77') echo "<option value='77' selected>Planilha</option>";
if ($post['species'] == '78') echo "<option value='78' selected>Planta</option>";
if ($post['species'] == '79') echo "<option value='79' selected>Portaria</option>";
if ($post['species'] == '80') echo "<option value='80' selected>Processo</option>";
if ($post['species'] == '81') echo "<option value='81' selected>Procuração</option>";
if ($post['species'] == '82') echo "<option value='82' selected>Programa</option>";
if ($post['species'] == '83') echo "<option value='83' selected>Projeto</option>";
if ($post['species'] == '84') echo "<option value='84' selected>Prontuário</option>";
if ($post['species'] == '85') echo "<option value='85' selected>Proposta</option>";
if ($post['species'] == '86') echo "<option value='86' selected>Protocolo</option>";
if ($post['species'] == '87') echo "<option value='87' selected>Prova</option>";
if ($post['species'] == '88') echo "<option value='88' selected>Quadro</option>";
if ($post['species'] == '89') echo "<option value='89' selected>Questionário</option>";
if ($post['species'] == '90') echo "<option value='90' selected>Receita</option>";
if ($post['species'] == '91') echo "<option value='91' selected>Recibo</option>";
if ($post['species'] == '92') echo "<option value='92' selected>Recorte/Clip</option>";
if ($post['species'] == '93') echo "<option value='93' selected>Recurso</option>";
if ($post['species'] == '94') echo "<option value='94' selected>Regimento</option>";
if ($post['species'] == '95') echo "<option value='95' selected>Registro</option>";
if ($post['species'] == '96') echo "<option value='96' selected>Regulamento</option>";
if ($post['species'] == '97') echo "<option value='97' selected>Relação/Rol</option>";
if ($post['species'] == '98') echo "<option value='98' selected>Relatório</option>";
if ($post['species'] == '99') echo "<option value='99' selected>Release/Press release</option>";
if ($post['species'] == '100') echo "<option value='100' selected>Requerimento/Requisição</option>";
if ($post['species'] == '101') echo "<option value='101' selected>Resolução</option>";
if ($post['species'] == '102') echo "<option value='102' selected>Resumo</option>";
if ($post['species'] == '103') echo "<option value='103' selected>Roteiro</option>";
if ($post['species'] == '104') echo "<option value='104' selected>Sinopse</option>";
if ($post['species'] == '105') echo "<option value='105' selected>Solicitação</option>";
if ($post['species'] == '106') echo "<option value='106' selected>Tabela</option>";
if ($post['species'] == '107') echo "<option value='107' selected>Telegrama</option>";
if ($post['species'] == '108') echo "<option value='108' selected>Termo</option>";
if ($post['species'] == '109') echo "<option value='109' selected>Tese</option>";
if ($post['species'] == '110') echo "<option value='110' selected>TCC</option>";
if ($post['species'] == '111') echo "<option value='111' selected>Título de crédito</option>";
if ($post['species'] == '112') echo "<option value='112' selected>Vale</option>";
?>
<option value="0"><?= txt('especie') ?></option>
<option value="1">Abaixo-assinado</option>
<option value="2">Acordo</option>
<option value="3">Alvará</option>
<option value="4">Assento</option>
<option value="5">Ata</option>
<option value="6">Atestado</option>
<option value="7">Auto</option>
<option value="8">Aviso</option>
<option value="9">Bilhete</option>
<option value="10">Carta</option>
<option value="11">Carta aberta/Manifesto</option>
<option value="12">Cartão de visita</option>
<option value="13">Cartão de ponto</option>
<option value="14">Cartaz</option>
<option value="15">Cédula de identidade</option>
<option value="16">Certidão</option>
<option value="17">Certificado</option>
<option value="18">Cheque</option>
<option value="19">Circular</option>
<option value="20">Comunicação/Paper</option>
<option value="21">Comunicado</option>
<option value="22">Contrato</option>
<option value="23">Convenção</option>
<option value="24">Convite</option>
<option value="25">Convocação</option>
<option value="26">Cópia autêntica</option>
<option value="27">Crachá</option>
<option value="28">Currículo</option>
<option value="29">Declaração</option>
<option value="30">Decreto</option>
<option value="31">Depoimento</option>
<option value="32">Despacho</option>
<option value="33">Diário</option>
<option value="34">Diploma</option>
<option value="35">Dissertação</option>
<option value="36">Dossiê</option>
<option value="37">Edital</option>
<option value="38">Ementa</option>
<option value="39">Escritura</option>
<option value="40">Estatuto</option>
<option value="41">Expediente</option>
<option value="42">Extrato</option>
<option value="43">Fatura</option>
<option value="44">Ficha</option>
<option value="45">Folheto/Folder/Prospecto</option>
<option value="46">Formulário</option>
<option value="47">Guia</option>
<option value="48">Histórico</option>
<option value="49">Informe</option>
<option value="50">Instrução</option>
<option value="51">Inventário</option>
<option value="52">Laudo</option>
<option value="53">Layout</option>
<option value="54">Lei</option>
<option value="55">Lista/Listagem</option>
<option value="56">Livro</option>
<option value="57">Mapa</option>
<option value="58">Memorando</option>
<option value="59">Memória/Memorial</option>
<option value="60">Minuta</option>
<option value="61">Moção</option>
<option value="62">Norma</option>
<option value="63">Nota</option>
<option value="64">Ofício</option>
<option value="65">Orçamento</option>
<option value="66">Ordem de serviço</option>
<option value="67">Organograma</option>
<option value="68">Original/Rascunho</option>
<option value="69">Panfleto</option>
<option value="70">Papeleta</option>
<option value="71">Parecer</option>
<option value="72">Partilha</option>
<option value="73">Partitura</option>
<option value="74">Passaporte</option>
<option value="75">Pauta</option>
<option value="76">Petição</option>
<option value="77">Planilha</option>
<option value="78">Planta</option>
<option value="79">Portaria</option>
<option value="80">Processo</option>
<option value="81">Procuração</option>
<option value="82">Programa</option>
<option value="83">Projeto</option>
<option value="84">Prontuário</option>
<option value="85">Proposta</option>
<option value="86">Protocolo</option>
<option value="87">Prova</option>
<option value="88">Quadro</option>
<option value="89">Questionário</option>
<option value="90">Receita</option>
<option value="91">Recibo</option>
<option value="92">Recorte/Clip</option>
<option value="93">Recurso</option>
<option value="94">Regimento</option>
<option value="95">Registro</option>
<option value="96">Regulamento</option>
<option value="97">Relação/Rol</option>
<option value="98">Relatório</option>
<option value="99">Release/Press release</option>
<option value="100">Requerimento/Requisição</option>
<option value="101">Resolução</option>
<option value="102">Resumo</option>
<option value="103">Roteiro</option>
<option value="104">Sinopse</option>
<option value="105">Solicitação</option>
<option value="106">Tabela</option>
<option value="107">Telegrama</option>
<option value="108">Termo</option>
<option value="109">Tese</option>
<option value="110">TCC- Trab. Concl. de Curso</option>
<option value="111">Título de crédito</option>
<option value="112">Vale</option>
</select>

<br><?= txt('tipodoc') ?><sup><a id='source3' href='#endrefs'>&nbsp;3&nbsp;</a></sup>:<br>
<div id='ltype' class='ct'></div>
<?php
if ($post['type'] == 0 || strlen($post['type']) < 3) echo "<input onkeyup='statosdotcom_Count(this,49);' value='' type='text' name='type' id='type' placeholder='" . txt('tipodoc') . "' maxlength='49'>";
else echo "<input onkeyup='statosdotcom_Count(this,49);' value='" . $post['type'] . "' type='text' name='type' id='type' placeholder='" . txt('tipodoc') . "' maxlength='49'>";
?>

<br><?= txt('numitens') ?>:<br>
<select name='items' id='items'>
    <?php if ($post['items'] != 0) echo "<option selected value=" . $post['items'] . ">" . $post['items'] . "</option>"; ?>
    <option value=0><?= txt('numitens') ?></option>
    <?php
    $contador = 0;
    while ($contador<99){
        $contador++;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
    }
    ?>
</select>

<br><?= txt('descricao') ?>:<br>
<div id='ldescription' class='ct'></div>
<?php
if ($post['description'] == 0) echo "<textarea onkeyup='statosdotcom_Count(this,255);' id='description' name='description' rows=5 placeholder='" . txt('descricao') . "' maxlength='255'></textarea>";
else echo "<textarea onkeyup='statosdotcom_Count(this,255);' id='description' name='description' rows=5 placeholder='" . txt('descricao') . "' maxlength='255'>" . $post['description'] . "</textarea>";
?>

<br><?= txt('conteudo') ?>; <?= txt('transdescr') ?>:<br>
<div id='lcontents' class='ct'></div>
<?php
if ($post['contents'] == 0) echo "<textarea onkeyup='statosdotcom_Count(this,65535);' id='contents' name='contents' rows=20 placeholder='" . txt('conteudo') . "' maxlength='65535'></textarea>";
else echo "<textarea onkeyup='statosdotcom_Count(this,65535);' id='contents' name='contents' rows=20 placeholder='" . txt('conteudo') . "' maxlength='65535'>" . $post['contents'] . "</textarea>";
?>

<br><?= txt('autografo') ?> (<?= txt('escritoamao') ?>)?<br>
<select name='autograph'>
<?php
if ($post['autograph'] == '0') echo "<option value='0' selected>" . txt('autografo') . " (" . txt('escritoamao') . ")?</option>";
if ($post['autograph'] == '1') echo "<option value='1' selected>" . txt('lapis') . "</option>";
if ($post['autograph'] == '2') echo "<option value='2' selected>" . txt('canetaesf') . "</option>";
if ($post['autograph'] == '3') echo "<option value='3' selected>" . txt('canetatint') . "</option>";
?>
<option value='0'><?= txt('autografo') ?>?</option>
<option value='1'><?= txt('lapis') ?></option>
<option value='2'><?= txt('canetaesf') ?></option>
<option value='3'><?= txt('canetatint') ?></option>
</select>

<br><?= txt('coraut') ?>:<br>
<div id='lautograph_color' class='ct'></div>
<?php
if ($post['autograph_color'] == 0) echo "<input onkeyup='statosdotcom_Count(this,19);' type='text' name='autograph_color' id='autograph_color' placeholder='" . txt('coraut') . "' maxlength='19'>";
else echo "<input onkeyup='statosdotcom_Count(this,19);' value='" . $post['autograph_color'] . "' type='text' name='autograph_color' id='autograph_color' placeholder='" . txt('coraut') . "' maxlength='19'>";
?>

<br><?= txt('datiloscrito') ?> (<?= txt('escritoamaq') ?>)?<br>
<select name='typewritten'>
<?php
if ($post['typewritten'] == '0') echo "<option value='0' selected>" . txt('datiloscrito') . "?</option>";
if ($post['typewritten'] == '1') echo "<option value='1' selected>" . txt('sim') . "</option>";
if ($post['typewritten'] == '2') echo "<option value='2' selected>" . txt('nao') . "</option>";
?>
<option value='0'><?= txt('datiloscrito') ?>?</option>
<option value='1'><?= txt('sim') ?></option>
<option value='2'><?= txt('nao') ?></option>
</select>

<br><?= txt('datiloscritocor') ?>:<br>
<div id='ltypewritten_color' class='ct'></div>
<?php
if ($post['typewritten_color'] == 0) echo "<input onkeyup='statosdotcom_Count(this,19);' type='text' name='typewritten_color' placeholder='" . txt('datiloscritocor') . "' maxlength='19'>";
else echo "<input onkeyup='statosdotcom_Count(this,19);' value='" . $post['typewritten_color'] . "' type='text' name='typewritten_color' placeholder='" . txt('datiloscritocor') . "' maxlength='19'>";
?>

<br><?= txt('midia') ?><sup><a href="javascript:alert('MESICON\n\nMaterial no qual são registradas as informações.\n\nMaterial in which information is recorded.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<?php
$meds = ['acetato','aço','algodão','alumínio','bronze','cera','cerâmica','cobre','couro','ferro','gesso','latão','linho','louça','madeira','mármore','metal','nitrato','ouro','papel','pedra','pergaminho','plástico','poliéster','prata','seda','vidro','vinil'];
?>
<select name='medium'>
    <?php if ($post['medium'] != 0) echo "<option selected value=" . $post['medium'] . ">" . $post['medium'] . "</option>"; ?>
    <option value=""><?= txt('midia') ?></option>
    <?php foreach ($meds as $key => $med): ?>
        <option value="<?= $med ?>"><?= $med ?></option>
    <?php endforeach ?>
</select>

<br><?= txt('marcadagua') ?>? <?= txt('manuscrito') ?>? <?= txt('trandescr') ?>:<br>
<div id='lwatermark' class='ct'></div>
<?php
if ($post['watermark'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='watermark' name='watermark' placeholder='" . txt('marcadagua') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['watermark'] . "' type='text' id='watermark' name='watermark' placeholder='" . txt('marcadagua') . "' maxlength='199'>";
?>

<br><?= txt('paginas') ?>:<br>
<div id='lpages' class='ct'></div>
<?php
    if ($post['pages'] != 0 && $post['pages'] != "") $paginas = $post['pages'];
?>
<input onkeyup='statosdotcom_Count(this,4);' value='<?= $paginas ?>' type='tel' id='pages' name='pages' placeholder='<?= txt('paginas') ?>' maxlength='4' onChange="this.value=this.value.replace(/[^0-9]+/g, '');"> <!-- regex recusa tudo menos números -->

<br><?= txt('folhas') ?>:<br>
<div id='lleafs' class='ct'></div>
<?php
    if ($post['leafs'] != 0 && $post['leafs'] != "") $folhas = $post['leafs'];
?>
<input onkeyup='statosdotcom_Count(this,4);' value='<?= $folhas ?>' type='tel' id='leafs' name='leafs' placeholder='<?= txt('folhas') ?>' maxlength='4' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">

<br><?= txt('largura') ?> (cm.):<br>
<div id='lwidth' class='ct'></div>
<?php
    if ($post['width'] != 0 && $post['width'] != "") $largura = $post['width'];
?>
<input onkeyup='statosdotcom_Count(this,3);' value='<?= $largura ?>' type='tel' id='width' name='width' placeholder='<?= txt('largura') ?>' maxlength='3' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">

<br><?= txt('altura') ?> (cm.):<br>
<div id='lheight' class='ct'></div>
<?php
    if ($post['height'] != 0 && $post['height'] != "") $altura = $post['height'];
?>
<input onkeyup='statosdotcom_Count(this,3);' value='<?= $altura ?>' type='tel' id='height' name='height' placeholder='<?= txt('altura') ?>' maxlength='3' onChange="this.value=this.value.replace(/[^0-9]+/g, '');">
    
<br><?= txt('anexos') ?>? <?= txt('transdescr') ?>:<br>
<div id='lanex' class='ct'></div>
<?php
if ($post['anex'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='anex' name='anex' placeholder='" . txt('anexos') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['anex'] . "' type='text' id='anex' name='anex' placeholder='" . txt('anexos') . "' maxlength='199'>";
?>

<br><?= txt('envelope') ?>? <?= txt('transdescr') ?>:<br>
<div id='lenvelope' class='ct'></div>
<?php
if ($post['envelope'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='envelope' name='envelope' placeholder='" . txt('envelope') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['envelope'] . "' type='text' id='envelope' name='envelope' placeholder='" . txt('envelope') . "' maxlength='199'>";
?>

<br><?= txt('selo') ?>? <?= txt('transdescr') ?>:<br>
<div id='lstamp' class='ct'></div>
<?php
if ($post['stamp'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='stamp' name='stamp' placeholder='" . txt('selo') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['stamp'] . "' type='text' id='stamp' name='stamp' placeholder='" . txt('selo') . "' maxlength='199'>";
?>

<br><?= txt('carimbo') ?>? <?= txt('transdescr') ?>:<br>
<div id='limprint' class='ct'></div>
<?php
if ($post['imprint'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='imprint' name='imprint' placeholder='" . txt('carimbo') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['imprint'] . "' type='text' id='imprint' name='imprint' placeholder='" . txt('carimbo') . "' maxlength='199'>";
?>

<br><?= txt('dataproducao') ?>:<br>
<input type='date' name='post' value='<?= $post['post'] ?>'>

<br><?= txt('aspectodata') ?>:<br>
<select name='post_type'>
<?php
if ($post['post_type'] == '0') echo "<option value='0' selected>" . txt('aspectodata') . "?</option>";
if ($post['post_type'] == '1') echo "<option value='1' selected>" . txt('expresso') . "</option>";
if ($post['post_type'] == '2') echo "<option value='2' selected>" . txt('presumido') . "</option>";
?>
<option value="0"><?= txt('aspectodata') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('datarec') ?>:<br>
<input type='date' name='receipt' value='<?= $post['receipt'] ?>'>

<br><?= txt('aspectodata') ?>:<br>
<select name='receipt_type'>
<?php
if ($post['receipt_type'] == '0') echo "<option value='0' selected>" . txt('aspectodata') . "?</option>";
if ($post['receipt_type'] == '1') echo "<option value='1' selected>" . txt('expresso') . "</option>";
if ($post['receipt_type'] == '2') echo "<option value='2' selected>" . txt('presumido') . "</option>";
?>
<option value='0'><?= txt('aspectodata') ?>?</option>
<option value="1"><?= txt('expresso') ?></option>
<option value="2"><?= txt('presumido') ?></option>
</select>

<br><?= txt('portador') ?>? <?= txt('transdescr') ?>:<br>
<div id='lcarrier' class='ct'></div>
<?php
if ($post['carrier'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='carrier' name='carrier' placeholder='" . txt('portador') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['carrier'] . "' type='text' id='carrier' name='carrier' placeholder='" . txt('portador') . "' maxlength='199'>";
?>

<br><?= txt('emmaos') ?>?<br>
<select name='in_hands'>
<?php
if ($post['in_hands'] == '0') echo "<option value='0' selected>" . txt('emmaos') . "?</option>";
if ($post['in_hands'] == '1') echo "<option value='1' selected>" . txt('sim') . "</option>";
if ($post['in_hands'] == '2') echo "<option value='2' selected>" . txt('nao') . "</option>";
?>
<option value='0'><?= txt('emmaos') ?>?</option>
<option value='1'><?= txt('sim') ?></option>
<option value='2'><?= txt('nao') ?></option>
</select>

<br><?= txt('notadest') ?>? <?= txt('transdescr') ?>:<br>
<div id='lnotes_recipient' class='ct'></div>
<?php
if ($post['notes_recipient'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='notes_recipient' name='notes_recipient' placeholder='" . txt('notadest') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['notes_recipient'] . "' type='text' id='notes_recipient' name='notes_recipient' placeholder='" . txt('notadest') . "' maxlength='199'>";
?>

<br><?= txt('notaterc') ?>? <?= txt('transdescr') ?>:<br>
<div id='lnotes_third' class='ct'></div>
<?php
if ($post['notes_third'] == 0) echo "<input onkeyup='statosdotcom_Count(this,199);' type='text' id='notes_third' name='notes_third' placeholder='" . txt('notaterc') . "' maxlength='199'>";
else echo "<input onkeyup='statosdotcom_Count(this,199);' value='" . $post['notes_third'] . "' type='text' id='notes_third' name='notes_third' placeholder='" . txt('notaterc') . "' maxlength='199'>";
?>

<br><?= txt('conserva') ?><sup><a href="javascript:alert('MESICON\n\nDescreva detalhes, em item específico dentro de \'Nota da Pesquisa\', ao final, se possível historiando atividades de conservação e restauro. Ademais: descreva manchas, rasgos, quebras, dobras, ferrugem etc.\n\nDescribe details, in a specific item within the \'Research Note\', in the end, if possible historizing conservation and restoration activities. In addition: describe stains, tears, breaks, folds, rust etc.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<select name='conservation'>
<?php
if ($post['conservation'] == '0') echo "<option value='0' selected>" . txt('conserva') . "</option>";
if ($post['conservation'] == '1') echo "<option value='1' selected>" . txt('conservab') . "</option>";
if ($post['conservation'] == '2') echo "<option value='2' selected>" . txt('conservar') . "</option>";
if ($post['conservation'] == '3') echo "<option value='3' selected>" . txt('conservam') . "</option>";
?>
<option value='0'><?= txt('conserva') ?></option>
<option value='1'><?= txt('conservab') ?></option>
<option value='2'><?= txt('conservar') ?></option>
<option value='3'><?= txt('conservam') ?></option>
</select>

<br><?= txt('local') ?>:<br>
<div id='laddress' class='ct'></div>
<?php
if ($post['address'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' id='address' name='address' placeholder='" . txt('local') . "' maxlength='99'>";
else echo "<input onkeyup='statosdotcom_Count(this,99);' value='" . $post['address'] . "' type='text' id='address' name='address' placeholder='" . txt('local') . "' maxlength='99'>";
?>

<br><?= txt('acervo') ?>?<br>
<div id='lcollection' class='ct'></div>
<?php
if ($post['collection'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' id='collection' name='collection' placeholder='" . txt('acervo') . "' maxlength='99'>";
else echo "<input onkeyup='statosdotcom_Count(this,99);' value='" . $post['collection'] . "' type='text' id='collection' name='collection' placeholder='" . txt('acervo') . "' maxlength='99'>";
?>

<br><?= txt('acervoref') ?><sup><a href="javascript:alert('MESICON\n\nNúmero de documento, pasta e/ou caixa onde se encontra.\n\nDocument number, folder and/or box where it is located.');">&nbsp;&#9432;&nbsp;</a></sup>:<br>
<div id='lref' class='ct'></div>
<?php
if ($post['ref'] == 0) echo "<input onkeyup='statosdotcom_Count(this,99);' type='text' id='ref' name='ref' placeholder='" . txt('acervoref') . "' maxlength='99'>";
else echo "<input onkeyup='statosdotcom_Count(this,99);' value='" . $post['ref'] . "' type='text' id='ref' name='ref' placeholder='" . txt('acervoref') . "' maxlength='99'>";
?>

<br><?= txt('onomastico') ?> (<?= txt('sobrenome') ?>, <?= txt('nome') ?>):<br>
<div id='lonomastic' class='ct'></div>
<?php
if ($post['onomastic'] == 0) echo "<input onkeyup='statosdotcom_Count(this,255);' type='text' id='onomastic' name='onomastic' placeholder='" . txt('onomastico') . "' maxlength='255'>";
else echo "<input onkeyup='statosdotcom_Count(this,255);' value='" . $post['onomastic'] . "' type='text' id='onomastic' name='onomastic' placeholder='" . txt('onomastico') . "' maxlength='255'>";
?>

<br><?= txt('pseudo') ?>:<br>
<div id='lpseudonyms' class='ct'></div>
<?php
if ($post['pseudonyms'] == 0) echo "<input onkeyup='statosdotcom_Count(this,255);' type='text' id='pseudonyms' name='pseudonyms' placeholder='" . txt('pseudo') . "' maxlength='255'>";
else echo "<input onkeyup='statosdotcom_Count(this,255);' value='" . $post['pseudonyms'] . "' type='text' id='pseudonyms' name='pseudonyms' placeholder='" . txt('pseudo') . "' maxlength='255'>";
?>

<br><?= txt('livrosmen') ?>:<br>
<div id='lmentioned_works' class='ct'></div>
<?php
if ($post['mentioned_works'] == 0) echo "<input onkeyup='statosdotcom_Count(this,255);' type='text' id='mentioned_works' name='mentioned_works' placeholder='" . txt('livrosmen') . "' maxlength='255'>";
else echo "<input onkeyup='statosdotcom_Count(this,255);' value='" . $post['mentioned_works'] . "' type='text' id='mentioned_works' name='mentioned_works' placeholder='" . txt('livrosmen') . "' maxlength='255'>";
?>

<br><?= txt('jornais') ?>:<br>
<div id='lperiodics' class='ct'></div>
<?php
if ($post['periodics'] == 0) echo "<input onkeyup='statosdotcom_Count(this,255);' type='text' id='periodics' name='periodics' placeholder='" . txt('jornai') . "' maxlength='255'>";
else echo "<input onkeyup='statosdotcom_Count(this,255);' value='" . $post['periodics'] . "' type='text' id='periodics' name='periodics' placeholder='" . txt('jornais') . "' maxlength='255'>";
?>

<br><?= txt('proveniencia') ?>:<br>
<div id='lhistoric' class='ct'></div>
<?php
if ($post['historic'] == 0) echo "<input onkeyup='statosdotcom_Count(this,255);' type='text' id='historic' name='historic' placeholder='" . txt('proviniencia') . "' maxlength='255'>";
else echo "<input onkeyup='statosdotcom_Count(this,255);' value='" . $post['historic'] . "' type='text' id='historic' name='historic' placeholder='" . txt('proveniencia') . "' maxlength='255'>";
?>

<br><?= txt('formaacq') ?>:<br>
<?php
//$acqs = ['Comodato','Compra','Custódia','Depósito','Doação','Empréstimo','Legado','Permuta','Recolhimento','Reintegração','Transferência'];
$acqs = ['Comodato - Lending','Compra - Purchase','Custódia - Custody','Depósito - Deposit','Doação - Donation','Empréstimo - Loan','Legado - Legacy','Permuta - Exchange','Recolhimento - Retreat','Reintegração - Reintegration','Transferência - Transfer'];
?>
<select name='acquisition'>
    <?php if ($post['acq'] != 0) echo "<option selected value=" . $post['acq'] . ">" . $post['acq'] . "</option>"; ?>
    <option value="" selected disabled><?= txt('formaacq') ?>?</option>
    <?php foreach ($acqs as $key => $acq): ?>
        <option value="<?= $acq ?>"><?= $acq ?></option>
    <?php endforeach ?>
</select>

<br><?= txt('dataacq') ?>:<br>
<input type='date' name='acq_date' value='<?= $post['acq_date'] ?>'>

<br><?= txt('notadapesquisa') ?>:<br>
<?php
if ($post['add_info'] == 0) echo "<textarea name='add_info' rows=20 placeholder='" . txt('notapesqtxt') . "' maxlength=65535></textarea>";
else echo "<textarea name='add_info' rows=20 placeholder='" . txt('notapesqtxt') . "' maxlength=65535>" . $post['add_info'] . "</textarea>";
?>

<br>