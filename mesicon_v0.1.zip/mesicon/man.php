<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

$tabela = 3; // aqui a tabela é sempre a oficial manuscritos
if ($_GET['id']) {
	$posts = getBAM($_GET['id'], $tabela);
} else {
	$posts = getPublishedPosts();
}
$entrou = 0;
?>

<style>
.comments {
    width: 100%;
    font-size: 1.3em;
    margin: 1px;
    padding: 9px 9px;
    background-color: #dddddd;
    display: none;
    box-sizing: border-box;
    border-radius: 20px;
}
</style>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Post</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<?php 
    foreach ($posts as $post):

    $entrou = 1;
    if (($post['creator_id'] == $_SESSION['user']['id']) || ($_SESSION['user']['role'] == "Administrator")) {
        if ($tabela == 2 || $tabela == 3) echo "<a href='edit_manuscript.php?i=" . $post['id'] . "&t=" . $tabela . "'>EDITAR</a>";
        // OLD echo "<a href='edit_book.php?i=" . $post['id'] . "&t=" . $tabela . "'>EDITAR</a>";
    }
    ?>

    <!-- 
    <div class="copyrightcontainer">
    <img src="static/copyright.gif"> 
    -->
    <div class="copyright">
    <img src="static/copyright.gif" width="100%">
    <div class="copyright crdiv">

    <?php 

	//echo "<div class='post-wrapper'>";
	/*
    if (($_SESSION['user']['role'] == "Administrator") || ($_SESSION['user']['role'] == "Manager")) {
		echo "<h2>";
		if ($post['published'] == 0) echo "<font color=red>Não </font>";
		echo "Publicado<br></h2>";
	}
    */
        
    if ($tabela == 3) if ($post['link_id'] != 0) echo "<center><b>" . txt('esteman') . "<br><a href='post.php?id=" . $post['link_id'] . "&t=1'><i>" . $post['link_title'] . "</i></a>.</b><br><font size=-1><a href='post.php?id=" . $post['link_id'] . "&t=1'>http://statos.com/mesicon/post.php?id=" . $post['link_id'] . "&t=1</a></font><br><br></center>";

    echo "<b>" . txt('autorman') . ":</b> <h2 style='display: inline; margin: 0;'>" . $post['author'] . "</h2><br>";
    if ($post['author_type'] != 0) echo txt('autoria') . " ";
    if ($post['author_type'] == 1) echo txt('expresso') . ".<br>";
    if ($post['author_type'] == 2) echo txt('presumido') . ".<br>";
    echo "<br>";
    
    echo "<b>" . txt('titulo') . ":</b> <h2 class='title' style='display: inline; margin: 0;'>";
    if (strlen(trim($post['copy'])) > 2) echo $post['title'];
    else echo " - sem título - ";
    echo "</h2><br>";
    if ($post['title_type'] != 0) echo txt('titulo') . " ";
    if ($post['title_type'] == 1) echo txt('expresso') . ".<br>";
    if ($post['title_type'] == 2) echo txt('presumido') . ".<br>";
    echo "<br>";
    
    if ($post['original'] == 1) echo txt('originalidade') . " " . txt('expresso') . ".";
    if ($post['original'] == 2) echo txt('copiaourep') . " " . txt('expresso') . ".";
    if ($post['original'] == 3) echo txt('originalidade') . "/" . txt('copiaourep') . " " . txt('presumido') . ".";
    if ($post['original'] != 0) echo "<br><br>";
        
	if (strlen(trim($post['copy'])) > 2) echo "<b> " . txt('possivelcopia') . ":</b> " . $post['copy'] . "<br><br>";
    if (strlen(trim($post['signature'])) > 2) echo "<b>" . txt('autorsign') . ":</b> " . $post['signature'] . "<br><br>";
	if (strlen(trim($post['source_local'])) > 2) echo "<b>" . txt('localorigem') . ":</b> " . $post['source_local'] . "<br><br>";
        
	if (strlen(trim($post['recipient'])) > 2) echo "<b>" . txt('destinatario') . ":</b> " . $post['recipient'] . "<br>";
    if ($post['recipient_type'] == 1) echo txt('destinatario2') . " " . txt('expresso') . ".<br>";
    if ($post['recipient_type'] == 2) echo txt('destinatario2') . " " . txt('presumido') . ".<br>";
    if ((strlen(trim($post['recipient'])) > 2) || ($post['recipient_type'] != 0)) echo "<br>";
        
	if (strlen(trim($post['destination'])) > 2) echo "<b>" . txt('localdestino') . ":</b> " . $post['destination'] . "<br>";
    if ($post['destination_type'] == 1) echo txt('destino') . " " . txt('expresso') . ".<br>";
    if ($post['destination_type'] == 2) echo txt('destino') . " " . txt('presumido') . ".<br>";
    if ((strlen(trim($post['destination'])) > 2) || ($post['destination_type'] != 0)) echo "<br>";

	if (strlen(trim($post['treatment'])) > 2) echo "<b>" . txt('formatrata') . ":</b> " . $post['treatment'] . "<br><br>";
	if (strlen(trim($post['postscript'])) > 2) echo "<b>Post scriptum:</b> " . $post['postscript'] . "<br><br>";

    if ($post['data'] != "0000-00-00") echo "<b>" . txt('dataproducao') . ":</b> " . $post['data'];
    if ($post['data_type'] == 1) echo " (" . txt('expresso') . ")";
    if ($post['data_type'] == 2) echo " (" . txt('presumido') . ")";
    if (($post['data'] != "0000-00-00") || ($post['data_type'] != 0)) echo "<br><br>";
        
	// TODO: colocar links para tipo documental, gênero    

    if (strlen($post['idiom']) > 1) {
        echo "<b>" . txt('idioma') . " (" . txt('predominante') . "):</b> ";
        if ($post['idiom'] == "af") echo "Afrikaans";
        if ($post['idiom'] == "sq") echo "Albanian";
        if ($post['idiom'] == "ar") echo "Arabic";
        if ($post['idiom'] == "hy") echo "Armenian";
        if ($post['idiom'] == "az") echo "Azerbaijani";
        if ($post['idiom'] == "eu") echo "Basque";
        if ($post['idiom'] == "be") echo "Belarusian";
        if ($post['idiom'] == "bs") echo "Bosnian";
        if ($post['idiom'] == "bg") echo "Bulgarian";
        if ($post['idiom'] == "ca") echo "Catalan";
        if ($post['idiom'] == "zh") echo "Chinese";
        if ($post['idiom'] == "hr") echo "Croatian";
        if ($post['idiom'] == "cs") echo "Czech";
        if ($post['idiom'] == "da") echo "Danish";
        if ($post['idiom'] == "nl") echo "Dutch";
        if ($post['idiom'] == "en") echo "English";
        if ($post['idiom'] == "eo") echo "Esperanto";
        if ($post['idiom'] == "et") echo "Estonian";
        if ($post['idiom'] == "fl") echo "Filipino";
        if ($post['idiom'] == "fi") echo "Finnish";
        if ($post['idiom'] == "fr") echo "French";
        if ($post['idiom'] == "de") echo "German";
        if ($post['idiom'] == "el") echo "Greek";
        if ($post['idiom'] == "gn") echo "Guarani";
        if ($post['idiom'] == "hn") echo "Hawaiian";
        if ($post['idiom'] == "he") echo "Hebrew";
        if ($post['idiom'] == "hi") echo "Hindi";
        if ($post['idiom'] == "hu") echo "Hungarian";
        if ($post['idiom'] == "is") echo "Icelandic";
        if ($post['idiom'] == "id") echo "Indonesian";
        if ($post['idiom'] == "ga") echo "Irish";
        if ($post['idiom'] == "it") echo "Italian";
        if ($post['idiom'] == "ja") echo "Japanese";
        if ($post['idiom'] == "kk") echo "Kazakh";
        if ($post['idiom'] == "ko") echo "Korean";
        if ($post['idiom'] == "la") echo "Latin";
        if ($post['idiom'] == "lv") echo "Latvian";
        if ($post['idiom'] == "lt") echo "Lithuanian";
        if ($post['idiom'] == "mk") echo "Macedonian";
        if ($post['idiom'] == "ms") echo "Malay";
        if ($post['idiom'] == "mt") echo "Maltese";
        if ($post['idiom'] == "mn") echo "Mongolian";
        if ($post['idiom'] == "ne") echo "Nepali";
        if ($post['idiom'] == "no") echo "Norwegian";
        if ($post['idiom'] == "fa") echo "Persian";
        if ($post['idiom'] == "pl") echo "Polish";
        if ($post['idiom'] == "pt") echo "Português";
        if ($post['idiom'] == "pa") echo "Punjabi";
        if ($post['idiom'] == "qu") echo "Quechua";
        if ($post['idiom'] == "ro") echo "Romanian";
        if ($post['idiom'] == "rm") echo "Romansh";
        if ($post['idiom'] == "ru") echo "Russian";
        if ($post['idiom'] == "gd") echo "Scottish Gaelic";
        if ($post['idiom'] == "sr") echo "Serbian";
        if ($post['idiom'] == "sk") echo "Slovak";
        if ($post['idiom'] == "sl") echo "Slovenian";
        if ($post['idiom'] == "es") echo "Spanish";
        if ($post['idiom'] == "su") echo "Sundanese";
        if ($post['idiom'] == "sw") echo "Swahili";
        if ($post['idiom'] == "sv") echo "Swedish";
        if ($post['idiom'] == "th") echo "Thai";
        if ($post['idiom'] == "tp") echo "Tupi";
        if ($post['idiom'] == "tr") echo "Turkish";
        if ($post['idiom'] == "uk") echo "Ukrainian";
        if ($post['idiom'] == "uz") echo "Uzbek";
        if ($post['idiom'] == "vi") echo "Vietnamese";
        if ($post['idiom'] == "cy") echo "Welsh";
        if ($post['idiom'] == "yi") echo "Yiddish";
        if ($post['idiom'] == "yo") echo "Yoruba";
        if ($post['idiom'] == "zu") echo "Zulu";
        echo "<br>"; 
    }

    if ($post['gender'] != 0) {
        echo "<b>" . txt('genero') . ":</b> ";
        if ($post['gender'] == 1) echo txt('bibliografico');
        if ($post['gender'] == 2) echo txt('cartografico');
        if ($post['gender'] == 3) echo txt('eletronico');
        if ($post['gender'] == 4) echo txt('filmografico');
        if ($post['gender'] == 5) echo txt('iconografico');
        if ($post['gender'] == 6) echo txt('micrografico');
        if ($post['gender'] == 7) echo txt('sonoro');
        if ($post['gender'] == 8) echo "Textual";
        if ($post['gender'] == 9) echo txt('tridimensional');
        echo "<br>";
    }
            
    if ($post['species'] != 0) { // TODO !!!!!!!!!!!!!!!!!!!!!!!!
		echo "<b>" . txt('especie') . ":</b> ";
		if ($post['species'] == 1) echo "impressa";
        if ($post['species'] == 1) echo "Abaixo-assinado";
        if ($post['species'] == 2) echo "Acordo";
        if ($post['species'] == 3) echo "Alvará";
        if ($post['species'] == 4) echo "Assento";
        if ($post['species'] == 5) echo "Ata";
        if ($post['species'] == 6) echo "Atestado";
        if ($post['species'] == 7) echo "Auto";
        if ($post['species'] == 8) echo "Aviso";
        if ($post['species'] == 9) echo "Bilhete";
        if ($post['species'] == 10) echo "Carta";
        if ($post['species'] == 11) echo "Carta aberta/Manifesto";
        if ($post['species'] == 12) echo "Cartão de visita";
        if ($post['species'] == 13) echo "Cartão de ponto";
        if ($post['species'] == 14) echo "Cartaz";
        if ($post['species'] == 15) echo "Cédula de identidade";
        if ($post['species'] == 16) echo "Certidão";
        if ($post['species'] == 17) echo "Certificado";
        if ($post['species'] == 18) echo "Cheque";
        if ($post['species'] == 19) echo "Circular";
        if ($post['species'] == 20) echo "Comunicação/Paper";
        if ($post['species'] == 21) echo "Comunicado";
        if ($post['species'] == 22) echo "Contrato";
        if ($post['species'] == 23) echo "Convenção";
        if ($post['species'] == 24) echo "Convite";
        if ($post['species'] == 25) echo "Convocação";
        if ($post['species'] == 26) echo "Cópia autêntica";
        if ($post['species'] == 27) echo "Crachá";
        if ($post['species'] == 28) echo "Currículo";
        if ($post['species'] == 29) echo "Declaração";
        if ($post['species'] == 30) echo "Decreto";
        if ($post['species'] == 31) echo "Depoimento";
        if ($post['species'] == 32) echo "Despacho";
        if ($post['species'] == 33) echo "Diário";
        if ($post['species'] == 34) echo "Diploma";
        if ($post['species'] == 35) echo "Dissertação";
        if ($post['species'] == 36) echo "Dossiê";
        if ($post['species'] == 37) echo "Edital";
        if ($post['species'] == 38) echo "Ementa";
        if ($post['species'] == 39) echo "Escritura";
        if ($post['species'] == 40) echo "Estatuto";
        if ($post['species'] == 41) echo "Expediente";
        if ($post['species'] == 42) echo "Extrato";
        if ($post['species'] == 43) echo "Fatura";
        if ($post['species'] == 44) echo "Ficha";
        if ($post['species'] == 45) echo "Folheto/Folder/Prospecto";
        if ($post['species'] == 46) echo "Formulário";
        if ($post['species'] == 47) echo "Guia";
        if ($post['species'] == 48) echo "Histórico";
        if ($post['species'] == 49) echo "Informe";
        if ($post['species'] == 50) echo "Instrução";
        if ($post['species'] == 51) echo "Inventário";
        if ($post['species'] == 52) echo "Laudo";
        if ($post['species'] == 53) echo "Layout";
        if ($post['species'] == 54) echo "Lei";
        if ($post['species'] == 55) echo "Lista/Listagem";
        if ($post['species'] == 56) echo "Livro";
        if ($post['species'] == 57) echo "Mapa";
        if ($post['species'] == 58) echo "Memorando";
        if ($post['species'] == 59) echo "Memória/Memorial";
        if ($post['species'] == 60) echo "Minuta";
        if ($post['species'] == 61) echo "Moção";
        if ($post['species'] == 62) echo "Norma";
        if ($post['species'] == 63) echo "Nota";
        if ($post['species'] == 64) echo "Ofício";
        if ($post['species'] == 65) echo "Orçamento";
        if ($post['species'] == 66) echo "Ordem de serviço";
        if ($post['species'] == 67) echo "Organograma";
        if ($post['species'] == 68) echo "Original/Rascunho";
        if ($post['species'] == 69) echo "Panfleto";
        if ($post['species'] == 70) echo "Papeleta";
        if ($post['species'] == 71) echo "Parecer";
        if ($post['species'] == 72) echo "Partilha";
        if ($post['species'] == 73) echo "Partitura";
        if ($post['species'] == 74) echo "Passaporte";
        if ($post['species'] == 75) echo "Pauta";
        if ($post['species'] == 76) echo "Petição";
        if ($post['species'] == 77) echo "Planilha";
        if ($post['species'] == 78) echo "Planta";
        if ($post['species'] == 79) echo "Portaria";
        if ($post['species'] == 80) echo "Processo";
        if ($post['species'] == 81) echo "Procuração";
        if ($post['species'] == 82) echo "Programa";
        if ($post['species'] == 83) echo "Projeto";
        if ($post['species'] == 84) echo "Prontuário";
        if ($post['species'] == 85) echo "Proposta";
        if ($post['species'] == 86) echo "Protocolo";
        if ($post['species'] == 87) echo "Prova";
        if ($post['species'] == 88) echo "Quadro";
        if ($post['species'] == 89) echo "Questionário";
        if ($post['species'] == 90) echo "Receita";
        if ($post['species'] == 91) echo "Recibo";
        if ($post['species'] == 92) echo "Recorte/Clip";
        if ($post['species'] == 93) echo "Recurso";
        if ($post['species'] == 94) echo "Regimento";
        if ($post['species'] == 95) echo "Registro";
        if ($post['species'] == 96) echo "Regulamento";
        if ($post['species'] == 97) echo "Relação/Rol";
        if ($post['species'] == 98) echo "Relatório";
        if ($post['species'] == 99) echo "Release/Press release";
        if ($post['species'] == 100) echo "Requerimento/Requisição";
        if ($post['species'] == 101) echo "Resolução";
        if ($post['species'] == 102) echo "Resumo";
        if ($post['species'] == 103) echo "Roteiro";
        if ($post['species'] == 104) echo "Sinopse";
        if ($post['species'] == 105) echo "Solicitação";
        if ($post['species'] == 106) echo "Tabela";
        if ($post['species'] == 107) echo "Telegrama";
        if ($post['species'] == 108) echo "Termo";
        if ($post['species'] == 109) echo "Tese";
        if ($post['species'] == 110) echo "TCC- Trab. Concl. de Curso";
        if ($post['species'] == 111) echo "Título de crédito";
        if ($post['species'] == 112) echo "Vale";       
        echo "<br>";
	}
        
	if (strlen(trim($post['type'])) > 2) echo "<b>" . txt('tipodoc') . ":</b> " . $post['type'] . "<br><br>";
	if ($post['items'] != 0) echo "<b>" . txt('numitens') . ":</b> " . $post['items'] . "<br><br>";
    
    if (strlen(trim($post['description'])) > 2) echo "<b>" . txt('descricao') . ":</b> " . $post['description'] . "<br><br>";
    if (strlen(trim($post['contents'])) > 2) echo "<b>" . txt('conteudo') . ":</b> " . $post['contents'] . "<br><br>";

    if ($post['autograph'] != 0) {
        echo "<b>" . txt('autografo') . ":</b> ";
        if ($post['autograph'] == 1) echo txt('lapis');
        if ($post['autograph'] == 2) echo txt('canetaesf');
        if ($post['autograph'] == 3) echo txt('canetatint');
        echo "<br>";
        if (strlen(trim($post['autograph_color'])) > 2) echo "<b>" . txt('coraut') . ":</b> " . $post['autograph_color'] . "<br><br>";
        else echo "<br>";
    }
        
    if ($post['typewritten'] != 0) {
        echo "<b>" . txt('datiloscrito') . ":</b> ";
        if ($post['typewritten'] == 1) echo txt('sim');
        if ($post['typewritten'] == 2) echo txt('nao');
        echo "<br>";
        if (strlen(trim($post['typewritten_color'])) > 2) echo "<b>" . txt('cordat') . ":</b> " . $post['typewritten_color'] . "<br><br>";
        else echo "<br>";
    }
        
    // TODO if ($post['medium'] != 0) echo "<b>Mídia/Suporte:</b> " . $post['medium'] . "<br>";

    if (strlen(trim($post['watermark'])) > 2) echo "<b>" . txt('marcadagua') . ":</b> " . $post['watermark'] . "<br><br>";

    if ($post['pages'] != 0) echo "<b>" . txt('paginas') . ":</b> " . $post['pages'] . "<br><br>";
    if ($post['leafs'] != 0) echo "<b>" . txt('folhas') . ":</b> " . $post['leafs'] . "<br><br>";
    if ($post['width'] != 0) echo "<b>" . txt('largura') . " (cm.):</b> " . $post['width'] . "<br><br>";
    if ($post['height'] != 0) echo "<b>" . txt('altura') . " (cm.):</b> " . $post['height'] . "<br><br>";

    if (strlen(trim($post['anex'])) > 2) echo "<b>" . txt('anexos') . ":</b> " . $post['anex'] . "<br><br>";
    if (strlen(trim($post['envelope'])) > 2) echo "<b>" . txt('envelope') . ":</b> " . $post['envelope'] . "<br><br>";
    if (strlen(trim($post['stamp'])) > 2) echo "<b>" . txt('selo') . ":</b> " . $post['stamp'] . "<br><br>";
    if (strlen(trim($post['imprint'])) > 2) echo "<b>" . txt('carimbo') . ":</b> " . $post['imprint'] . "<br><br>";

    if ($post['post'] != "0000-00-00") echo "<b>" . txt('datapost') . ":</b> " . $post['post'];
    if ($post['post_type'] == 1) echo " (" . txt('expresso') . ")";
    if ($post['post_type'] == 2) echo " (" . txt('presumido') . ")";
    if (($post['post'] != "0000-00-00") || ($post['post_type'] != 0)) echo "<br><br>";

    if ($post['receipt'] != "0000-00-00") echo "<b>" . txt('datarec') . ":</b> " . $post['receipt'];
    if ($post['receipt_type'] == 1) echo " (" . txt('expresso') . ")";
    if ($post['receipt_type'] == 2) echo " (" . txt('presumido') . ")";
    if (($post['receipt'] != "0000-00-00") || ($post['receipt_type'] != 0)) echo "<br><br>";
        
    if ($post['in_hands'] == 1) echo "<b>" . txt('emmaos') . ":</b> " . txt('sim') . "<br>";
    if ($post['in_hands'] == 2) echo "<b>" . txt('emmaos') . ":</b> " . txt('nao') . "<br>";
    if (strlen(trim($post['carrier'])) > 2) echo "<b>" . txt('portador') . ":</b> " . $post['carrier'] . "<br>";
    if ((strlen(trim($post['carrier'])) > 2) || ($post['in_hands'] != 0)) echo "<br>";

    if (strlen(trim($post['notes_recipient'])) > 2) echo "<b>" . txt('notadest') . ":</b> " . $post['notes_recipient'] . "<br><br>";
    if (strlen(trim($post['notes_third'])) > 2) echo "<b>" . txt('notaterc') . ":</b> " . $post['notes_third'] . "<br><br>";

    if ($post['conservation'] == 1) echo txt('conservab') . ".<br><br>";
    if ($post['conservation'] == 2) echo txt('conservar') . ".<br><br>";
    if ($post['conservation'] == 3) echo txt('conservam') . ".<br><br>";
        
    if (strlen(trim($post['address'])) > 2) echo "<b>" . txt('local') . ":</b> " . $post['address'] . "<br><br>";
    if (strlen(trim($post['collection'])) > 2) echo "<b>" . txt('acervo') . ":</b> " . $post['collection'] . "<br><br>";
    if (strlen(trim($post['ref'])) > 2) echo "<b>" . txt('acervoref') . ":</b> " . $post['ref'] . "<br><br>";
    if (strlen(trim($post['onomastic'])) > 2) echo "<b>" . txt('onomastico') . ":</b> " . $post['onomastic'] . "<br><br>";
    if (strlen(trim($post['pseudonyms'])) > 2) echo "<b>" . txt('pseudo') . ":</b> " . $post['pseudonyms'] . "<br><br>";
    if (strlen(trim($post['mentioned_works'])) > 2) echo "<b>" . txt('livrosmen') . ":</b> " . $post['mentioned_works'] . "<br><br>";
    if (strlen(trim($post['periodics'])) > 2) echo "<b>" . txt('jornais') . ":</b> " . $post['periodics'] . "<br><br>";
    if (strlen(trim($post['historic'])) > 2) echo "<b>" . txt('proveniencia') . ":</b> " . $post['historic'] . "<br><br>";
    
    if ($post['acquisition'] != null) echo "<b>" . txt('formaacq') . ":</b> " . $post['acquisition'] . "<br><br>";

    if ($post['acq_date'] != "0000-00-00") echo "<b>" . txt('dataacq') . ":</b> " . $post['acq_date'] . "<br><br>";

    if (strlen($post['add_info']) > 2) echo "<b>" . txt('notadapesquisa') . ":</b> " . $post['add_info'] . "<br><br>";
    
	echo "<center>";
    echo "<font size='-1'>--------------------</font>";
	getUserBio($post['creator_id']);
	echo "<font size='-1'>--------------------<br>";
	echo "<font size='-2'><b>" . txt('cadastradoem') . ":</b> " . $post['created_at'] . "&nbsp;|&nbsp;<b>" . txt('atualizacao') . ":</b> ". $post['updated_at'] . "<br></font>";
	echo "<font size='-1'>--------------------<br></font>";
	
    if ((strlen($post['publisher']) > 2) && (strlen($post['city']) > 2) && (strlen($post['year']) > 1) && ($post['ed_number'] != 0)) {
        echo $post['author'] . ". <i>" . $post['title'] . "</i>. " . $post['ed_number'] . ". ed. " . $post['city'] . ": " . $post['publisher'] . ", " . $post['year'] . ".";
        if (strlen($post['series']) > 2) echo " (" . $post['series'];
        if ($post['num_series'] != 0) echo ", " . $post['num_series'];
        if (strlen($post['series']) > 2) echo ").";
        echo "<br>--------------------<br>";
    }
    
    //echo "<a href=http://statos.com" . $_SERVER['REQUEST_URI'] . ">http://statos.com" . $_SERVER['REQUEST_URI'] . "</a><br>(<font size='-1'>" . date('F j, Y, g:i a') . "</font>)<br>";
    //echo date('Y') . " &copy; MESICON<br>--------------------<br>";
    $myUrl = "http://statos.com" . $_SERVER['REQUEST_URI'];
    echo "<a href=" . $myUrl . ">" . $myUrl . "</a> <a href=# title=Share onclick=javascript:copyToClipboard('" . $myUrl . "');alert('MESICON_Copiado_Copied!');><img src='static/share2.gif' alt=Share height=9vh border=0></a><br>(<font size='-1'>" . date('F j, Y, g:i a') . "</font>)<br>";
    echo date('Y') . " &copy; MESICON<br>--------------------<br>";
        ?>
        <script>
        </script>
        <?


    /*
    echo "<b>" . txt('comentarios') . " ";
    if ($_SESSION['user']['role'] == "Administrator" || $_SESSION['user']['role'] == "Manager") {
        if ($post['published'] == 1) { // só permite inserir comentários se o post está publicado
            ?>
            (<a href="#" onclick="javascript:div_comments.style.display = 'block'; statosdotcomForm.txt.focus();" title="<?= txt('utilizeoscomments') ?>"><?= txt('adicionar') ?></a>):
            <div id='div_comments' class='comments' style='display:none'>
            <form name='statosdotcomForm' id='statosdotcomForm' method='post' action='do_comment.php' onsubmit='return valida(this);'>
            <?php
            echo $_SESSION['user']['username'] . ":";
            echo "<input type='hidden' name='username_commenter' value='" . $_SESSION['user']['username'] . "'>";
            echo "<input type='hidden' name='id_commenter' value='" . $_SESSION['user']['id'] . "'>";
            echo "<input type='hidden' name='creator_id' value='" . $post['creator_id'] . "'>";
            echo "<input type='hidden' name='id_post' value='" . $post['id'] . "'>";
            echo "<input type='hidden' name='tabela' value='1'>";
            echo "<textarea name='txt' rows='3' placeholder='" . txt('utilizeoscomments') . " (max. 255 chars).' maxlength='255'></textarea>";
            ?>
            <table width="100%"><tr><td align="center"><input type="button" class="btn" onclick="javascript:div_comments.style.display = 'none';" value="<?= txt('cancelar_M') ?>"></td><td align="center"><button type="submit" class="btn" id="post-comment"><?= txt('enviar_M') ?></button></td></tr></table>
            </form></div>

            <script>
            var _formConfirm_submitted = false; // impede múltiplas postagens
            function vai(el,m) {alert(m);el.focus();}
            function valida(f) {
                if (f.txt.value.length < 16) { vai(f.txt,'MESICON\n\nNo mínimo 15 letras.\n\nAt least 15 chars.');return false; }
                else if ((f.txt.value=="") || (f.txt.value==" ")) {
                    vai(f.txt,"MESICON\n\nInserir comentário.\n\nInsert comment.");return false;
                } else {
                    var objForm = document.getElementById('statosdotcomForm');
                    var objBtn = document.getElementById('post-comment');
                    objBtn.style = 'color: #000000; background: #00ff00; cursor: not-allowed;';
                    objBtn.textContent = 'Aguarde/Wait...';
                    // document.getElementById('div_comments').innerHTML = ''; // limpa div
                    _formConfirm_submitted = true;
                    //alert('Comentário enviado/Comment sent 2');
                    return true;
                }
            }
            </script>        
        <?php
        }
        echo "<br><br>";
    } else {
        //$_SESSION['message'] = "Entre para comentar 1";
        echo "(<a href='login.php' title='Utilize os comentários para solicitar mais informações ou sugerir melhoramentos.'>adicionar</a>):<br><br>";
    }

    echo "</b>";
    if (trim(strlen($post['comments']>13))) echo "<p align=left><font color='#666666'>" . $post['comments'] . "<br></font></p>";
    */  
    ?>
        
        
</center>
</div>
</div>

<?php 
    endforeach;
    if ($entrou == 0) {
        header('location: logout.php?p=index');
        exit();
    }

include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>


