<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

$randomDate = $_GET['c']; // se veio de create_post(): recebeu random como sinalizador em updated_at (formato unix datetime "yyyy-mm-dd hh:mm:ss")
$posts = getBook2Review($randomDate);

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON | Review Book/Revisar Livro</title>

<!-- TODO: validation doesn't work; desabilitar botão de cadastro depois de apertado e sinalizar tambem ainda sem funfar -->

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->


<h1><?= txt('revisar') ?> <?= txt('livro') ?></h1>

<script>
var _formConfirm_submitted = false; // junto com "onsubmit" no form serve para impedir múltiplas postagens
function statosdotcomVeseman() {
    if (statosdotcomForm.manuscript.value == 1) alert('MESICON\n\nSe este livro é também um manuscrito, vincule um manuscrito a ele.\n\nIf this book is also a manuscript, link a manuscript to it.');
}
function statosdotcomVai() {
    if ( _formConfirm_submitted == false ) {
        _formConfirm_submitted = true; 
        return true;
    } else {
        alert('MESICON\n\nAguarde/Wait...'); 
        return false; 
    }
}
</script>

<?php foreach ($posts as $post): ?>

<?php if (($_SESSION['user']['role'] == "Administrator") || ($_SESSION['user']['role'] == "Manager")) { ?>
    <form id="statosdotcomForm" method="post" action="" onsubmit="statosdotcomVai();">
<?php } ?>

<!-- validation errors for the form -->
<?php include('incl_errors.php') ?>
<?php include('incl_messages.php') ?>

<?php
// TODO: fazer com que apenas o dono do post ou GOD tenham acesso e possam revisar ou salvar
// $_SESSION['user']['id'];
// $_SESSION['user']['username'];
?>

<h4>

<input type="hidden" name="id" value="<?= $post['id'] ?>">
<input type="hidden" name="creator" value="<?= $post['creator'] ?>">
<input type="hidden" name="creator_id" value="<?= $post['creator_id'] ?>">
<input type="hidden" name="updated_at" value="<?= $randomDate ?>">    
				
<br><font color="#990000"><?= txt('titulo') ?>:<br></font>
<?php
echo $post['title'] . "<input type='hidden' name='title' value='" . $post['title'] . "'>";
?><br><br>

<font color="#990000"><?= txt('autor') ?>:<br></font>
<?php
echo $post['author'] . "<input type='hidden' name='author' value='" . $post['author'] . "'>";
?><br><br>

<font color="#990000"><?= txt('ehorganizador') ?>?<br></font>
<?php
if ($post['org'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='org' value='0'>";
else if ($post['org'] == 1) echo txt('expressamente') . "<input type='hidden' name='org' value='1'>";
else echo txt('presumivelmente') . "<input type='hidden' name='org' value='2'>";
?><br><br>

<font color="#990000"><?= txt('numeroedicao') ?>: </font>
<?php
if ($post['ed_number'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='ed_number' value='0'>";
else echo $post['ed_number'] . "<input type='hidden' name='ed_number' value='" . $post['ed_number'] . "'>";
?><br><br>

<font color="#990000">Volumes: </font>
<?php
if ($post['tomos'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='tomos' value='0'>";
else echo $post['tomos'] . "<input type='hidden' name='tomos' value='" . $post['tomos'] . "'>";
?><br><br>

<font color="#990000"><?= txt('series') ?>:<br></font>
<?php
if ($post['series'] == 0 || $post['series'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='series' value='0'>";
else echo $post['series'] . "<input type='hidden' name='series' value='" . $post['series'] . "'>";
?><br><br>

<font color="#990000"><?= txt('numseries') ?>:</font>
<?php
if ($post['num_series'] == 0) echo "<br><font style='color: gray'>" . txt('naoespecificado') . "</font><input type='hidden' name='num_series' value='0'>";
else echo " " . $post['num_series'] . "<input type='hidden' name='num_series' value='" . $post['num_series'] . "'>";
?><br><br>

<font color="#990000"><?= txt('editora') ?>:<br></font>
<?php
if ($post['publisher'] == 0 || $post['publisher'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='publisher' value='0'>";
else echo $post['publisher'] . "<input type='hidden' name='publisher' value='" . $post['publisher'] . "'>";
?><br><br>

<font color="#990000"><?= txt('cidade') ?>:</font>
<?php
if ($post['city'] == 0 || $post['city'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='city' value='0'>";
else echo $post['city'] . "<input type='hidden' name='city' value='" . $post['city'] . "'>";
?><br><br>

<font color="#990000"><?= txt('estado') ?>: </font>
<?php
if ($post['state'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='state' value='0'>";
else {
    printaestado($post['state']);
    echo "<input type='hidden' name='state' value='" . $post['state'] . "'>";
}
?><br><br>

<font color="#990000"><?= txt('paisdepublicacao') ?>: </font>
<?php
if ($post['country'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='country' value='0'>";
else {
    printapais($post['country']);
    //echo "<input type='hidden' name='country' value='" . $post['country'] . "'>";
}
// TODO: melhorar
?><br><br>

<font color="#990000"><?= txt('mesdepublicacao') ?>: </font>
<?php
if ($post['month'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='month' value='0'>";
else {
    printames($post['month']);
    echo "<input type='hidden' name='month' value='" . $post['month'] . "'>";
}
?><br><br>

<font color="#990000"><?= txt('anodepublicacao') ?>: </font>
<?php
if ($post['year'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='year' value='0'>";
else echo $post['year'] . "<input type='hidden' name='year' value='" . $post['year'] . "'>";
?><br><br>

<font color="#990000"><?= txt('edimpressaoudig') ?>?<br></font>
<?php
if ($post['digital'] == "0") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='digital' value='0'>";
if ($post['digital'] == "1") echo txt('impressa') . "<input type='hidden' name='digital' value='1'>";
if ($post['digital'] == "2") echo "Digital<input type='hidden' name='digital' value='2'>";
?><br><br>

<font color="#990000"><?= txt('paginas') ?>: </font>
<?php
if ($post['pages'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='pages' value='0'>";
else echo $post['pages'] . "<input type='hidden' name='pages' value='" . $post['pages'] . "'>";
?><br><br>

<font color="#990000">ISBN: </font>
<?php
if ($post['isbn'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='isbn' value='0'>";
else echo $post['isbn'] . "<input type='hidden' name='isbn' value='" . $post['isbn'] . "'>";
?><br><br>

<font color="#990000"><?= txt('largura') ?> (cm.): </font>
<?php
if ($post['width'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='width' value='0'>";
else echo $post['width'] . "<input type='hidden' name='width' value='" . $post['width'] . "'>";
?><br><br>

<font color="#990000"><?= txt('altura') ?> (cm.): </font>
<?php
if ($post['height'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='height' value='0'>";
else echo $post['height'] . "<input type='hidden' name='height' value='" . $post['height'] . "'>";
?><br><br>

<font color="#990000"><?= txt('encadernacao') ?>: </font>
<?php
if ($post['paperback'] == "0") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='paperback' value='0'>";
if ($post['paperback'] == "1") echo txt('capadura') . "<input type='hidden' name='paperback' value='1'>";
if ($post['paperback'] == "2") echo txt('brochura') . "<input type='hidden' name='paperback' value='2'>";
?><br><br>

<font color="#990000"><?= txt('haexlibris') ?>? </font>
<?php
if ($post['exlibris'] == "0") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='exlibris' value='0'>";
if ($post['exlibris'] == "1") echo txt('nao') . "<input type='hidden' name='exlibris' value='1'>";
if ($post['exlibris'] == "2") echo txt('sim') . "<input type='hidden' name='exlibris' value='2'>";
?><br><br>

<font color="#990000"><?= txt('idioma') ?>: </font>
<?php
if ($post['idiom'] == 0) echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='idiom' value='0'>";
else {
    printaidioma($post['idiom']);
    echo "<input type='hidden' name='idiom' value='" . $post['idiom'] . "'>";
}
?><br><br>

<font color="#990000"><?= txt('tradutor') ?>:<br></font>
<?php
if ($post['translator'] == 0 || $post['translator'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='translator' value='0'>";
else echo $post['translator'] . "<input type='hidden' name='translator' value='" . $post['translator'] . "'>";
?><br><br>

<font color="#990000"><?= txt('outroidioma') ?>?<br></font>
<?php 
if ($post['more_idioms'] == 0 || $post['more_idioms'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='more_idioms' value='0'>";
else echo $post['more_idioms'] . "<input type='hidden' name='more_idioms' value='" . $post['more_idioms'] . "'>";
?><br><br>

<font color="#990000"><?= txt('dedicatoriaimpressa') ?>?<br></font>
<?php 
if ($post['printed_dedication'] == 0 || $post['printed_dedication'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='printed_dedication' value='0'>";
else echo $post['printed_dedication'] . "<input type='hidden' name='printed_dedication' value='" . $post['printed_dedication'] . "'>";
?><br><br>

<font color="#990000"><?= txt('haprefaciador') ?>:<br></font>
<?php 
if ($post['preface'] == 0 || $post['preface'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='preface' value='0'>";
else echo $post['preface'] . "<input type='hidden' name='preface' value='" . $post['preface'] . "'>";
?><br><br>

<font color="#990000"><?= txt('hamanuscrito') ?>?<br></font>
<?php
if ($post['manuscript'] == "0") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='manuscript' value='0'>";
if ($post['manuscript'] == "1") echo txt('sim') . "<input type='hidden' name='manuscript' value='1'>";
if ($post['manuscript'] == "2") echo txt('nao') . "<input type='hidden' name='manuscript' value='2'>";
?><br><br>

<font color="#990000"><?= txt('hailustracapa') ?>:<br></font>
<?php 
if ($post['front_illustrator'] == 0 || $post['front_illustrator'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='front_illustrator' value='0'>";
else echo $post['front_illustrator'] . "<input type='hidden' name='front_illustrator' value='" . $post['front_illustrator'] . "'>";
?><br><br>

<font color="#990000"><?= txt('hailustrainterno') ?>:<br></font>
<?php 
if ($post['inside_illustrator'] == 0 || $post['inside_illustrator'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='inside_illustrator' value='0'>";
else echo $post['inside_illustrator'] . "<input type='hidden' name='inside_illustrator' value='" . $post['inside_illustrator'] . "'>";
?><br><br>

<font color="#990000"><?= txt('haprimaaba') ?>?<br></font>
<?php 
if ($post['first_ear'] == 0 || $post['first_ear'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='first_ear' value='0'>";
else echo $post['first_ear'] . "<input type='hidden' name='first_ear' value='" . $post['first_ear'] . "'>";
?><br><br>

<font color="#990000"><?= txt('hasegundaaba') ?>?<br></font>
<?php
if ($post['second_ear'] == 0 || $post['second_ear'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='second_ear' value='0'>";
else echo $post['second_ear'] . "<input type='hidden' name='second_ear' value='" . $post['second_ear'] . "'>";
?><br><br>

<font color="#990000"><?= txt('haverso') ?>?<br></font>
<?php 
if ($post['back'] == 0 || $post['back'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='back' value='0'>";
else echo $post['back'] . "<input type='hidden' name='back' value='" . $post['back'] . "'>";
?><br><br>

<font color="#990000"><?= txt('notadapesquisa') ?>:<br></font>
<?php 
if ($post['add_info'] == 0 || $post['add_info'] == "") echo "<font style='color: gray'>" . txt('naoespecificado') . "</font>" . "<input type='hidden' name='add_info' value='0'>";
else echo $post['add_info'] . "<input type='hidden' name='add_info' value='" . $post['add_info'] . "'>";
?><br><br>

</h4>

<?php endforeach; ?>

<?php if (($_SESSION['user']['role'] == "Administrator") || ($_SESSION['user']['role'] == "Manager")) { ?>
    <br>
    <button type="submit" class="btn" name="edit_book" id="idBtnReview">&lt;&lt; <?= txt('corrigir_M') ?></button><br><br>
    <button type="submit" class="btn" name="update_book_from_review" id="idBtnSend" onclick="javascript:statosdotcomVeseman();"><?= txt('gravar_M') ?> &gt;&gt;</button>
    </form>
<?php } ?>

<script>
<!--
var objForm = document.getElementById("statosdotcomForm");
objForm.addEventListener('submit', function (e) {
    var objBtnSend = document.getElementById('idBtnSend');
    objBtnSend.textContent = 'Aguarde/Wait...';
    objBtnSend.style = "color: #000000; background: #00ff00; cursor: not-allowed;";
    //objBtnSend.disabled = 'disabled'; // can't disable the button because without it the associated command don't go by POST (and this is needed). Going by GET can't make to work at the end.
    var objBtnReview = document.getElementById('idBtnReview');
    objBtnReview.textContent = 'Aguarde/Wait...';
    objBtnReview.style = "color: #000000; background: #00ff00; cursor: not-allowed;";
    //objBtnReview.disabled = 'disabled'; // can't disable the button because without it the associated command don't go by POST (and this is needed). Going by GET can't make to work at the end.
});
//-->
</script>

<br><br><br><br><br>

<?php

function printames(string $m) {
if ($m == "1") echo txt('mesdepublicacao');
if ($m == "1") echo "Janeiro";
if ($m == "2") echo "Fevereiro";
if ($m == "3") echo "Março";
if ($m == "4") echo "Abril";
if ($m == "5") echo "Maio";
if ($m == "6") echo "Junho";
if ($m == "7") echo "Julho";
if ($m == "8") echo "Agosto";
if ($m == "9") echo "Setembro";
if ($m == "10") echo "Outubro";
if ($m == "11") echo "Novembro";
if ($m == "12") echo "Dezembro";
}
function printaestado(string $e) {
if ($e == '0') echo txt('estado');
if ($e == 'AC') echo "Acre";
if ($e == 'AL') echo "Alagoas";
if ($e == 'AP') echo "Amapá";
if ($e == 'AM') echo "Amazonas";
if ($e == 'BA') echo "Bahia";
if ($e == 'CE') echo "Ceará";
if ($e == 'DF') echo "Distrito Federal";
if ($e == 'ES') echo "Espirito Santo";
if ($e == 'GO') echo "Goiás";
if ($e == 'MA') echo "Maranhão";
if ($e == 'MS') echo "Mato Grosso do Sul";
if ($e == 'MT') echo "Mato Grosso";
if ($e == 'MG') echo "Minas Gerais";
if ($e == 'PA') echo "Pará";
if ($e == 'PB') echo "Paraíba";
if ($e == 'PR') echo "Paraná";
if ($e == 'PE') echo "Pernambuco";
if ($e == 'PI') echo "Piauí";
if ($e == 'RJ') echo "Rio de Janeiro";
if ($e == 'RN') echo "Rio Grande do Norte";
if ($e == 'RS') echo "Rio Grande do Sul";
if ($e == 'RO') echo "Rondônia";
if ($e == 'RR') echo "Roraima";
if ($e == 'SC') echo "Santa Catarina";
if ($e == 'SP') echo "São Paulo";
if ($e == 'SE') echo "Sergipe";
if ($e == 'TO') echo "Tocantins";
}
function printapais(string $p) {
if ($p == '0') echo txt('paisdepublicacao');
if ($p == 'Afganistan') echo "Afganistan";
if ($p == 'Albania') echo "Albania";
if ($p == 'Algeria') echo "Algeria";
if ($p == 'Angola') echo "Angola";
if ($p == 'Argentina') echo "Argentina";
if ($p == 'Armenia') echo "Armenia";
if ($p == 'Aruba') echo "Aruba";
if ($p == 'Australia') echo "Australia";
if ($p == 'Austria') echo "Austria";
if ($p == 'Azerbaijan') echo "Azerbaijan";
if ($p == 'Bahamas') echo "Bahamas";
if ($p == 'Bahrain') echo "Bahrain";
if ($p == 'Barbados') echo "Barbados";
if ($p == 'Belarus') echo "Belarus";
if ($p == 'Belgium') echo "Belgium";
if ($p == 'Bolivia') echo "Bolivia";
if ($p == 'Bosnia & Herzegovina') echo "Bosnia & Herzegovina";
if ($p == 'Brasil') echo "Brasil";
if ($p == 'Bulgaria') echo "Bulgaria";
if ($p == 'Cambodia') echo "Cambodia";
if ($p == 'Cameroon') echo "Cameroon";
if ($p == 'Canada') echo "Canada";
if ($p == 'Cape Verde') echo "Cape Verde";
if ($p == 'Chile') echo "Chile";
if ($p == 'China') echo "China";
if ($p == 'Colombia') echo "Colombia";
if ($p == 'Congo') echo "Congo";
if ($p == 'Costa Rica') echo "Costa Rica";
if ($p == 'Cote DIvoire') echo "Cote DIvoire";
if ($p == 'Croatia') echo "Croatia";
if ($p == 'Cuba') echo "Cuba";
if ($p == 'Cyprus') echo "Cyprus";
if ($p == 'Czech Republic') echo "Czech Republic";
if ($p == 'Denmark') echo "Denmark";
if ($p == 'East Timor') echo "East Timor";
if ($p == 'Ecuador') echo "Ecuador";
if ($p == 'Egypt') echo "Egypt";
if ($p == 'El Salvador') echo "El Salvador";
if ($p == 'Estonia') echo "Estonia";
if ($p == 'Finland') echo "Finland";
if ($p == 'France') echo "France";
if ($p == 'French Guiana') echo "French Guiana";
if ($p == 'Germany') echo "Germany";
if ($p == 'Great Britain') echo "Great Britain";
if ($p == 'Greece') echo "Greece";
if ($p == 'Grenada') echo "Grenada";
if ($p == 'Guatemala') echo "Guatemala";
if ($p == 'Guinea') echo "Guinea";
if ($p == 'Guyana') echo "Guyana";
if ($p == 'Haiti') echo "Haiti";
if ($p == 'Hawaii') echo "Hawaii";
if ($p == 'Honduras') echo "Honduras";
if ($p == 'Hong Kong') echo "Hong Kong";
if ($p == 'Hungary') echo "Hungary";
if ($p == 'Iceland') echo "Iceland";
if ($p == 'Indonesia') echo "Indonesia";
if ($p == 'India') echo "India";
if ($p == 'Iran') echo "Iran";
if ($p == 'Iraq') echo "Iraq";
if ($p == 'Ireland') echo "Ireland";
if ($p == 'Israel') echo "Israel";
if ($p == 'Italy') echo "Italy";
if ($p == 'Jamaica') echo "Jamaica";
if ($p == 'Japan') echo "Japan";
if ($p == 'Kazakhstan') echo "Kazakhstan";
if ($p == 'Korea South') echo "Korea South";
if ($p == 'Latvia') echo "Latvia";
if ($p == 'Lebanon') echo "Lebanon";
if ($p == 'Libya') echo "Libya";
if ($p == 'Liechtenstein') echo "Liechtenstein";
if ($p == 'Lithuania') echo "Lithuania";
if ($p == 'Luxembourg') echo "Luxembourg";
if ($p == 'Macau') echo "Macau";
if ($p == 'Macedonia') echo "Macedonia";
if ($p == 'Malaysia') echo "Malaysia";
if ($p == 'Maldives') echo "Maldives";
if ($p == 'Mali') echo "Mali";
if ($p == 'Malta') echo "Malta";
if ($p == 'Martinique') echo "Martinique";
if ($p == 'Mexico') echo "Mexico";
if ($p == 'Moldova') echo "Moldova";
if ($p == 'Monaco') echo "Monaco";
if ($p == 'Mongolia') echo "Mongolia";
if ($p == 'Morocco') echo "Morocco";
if ($p == 'Mozambique') echo "Mozambique";
if ($p == 'Nepal') echo "Nepal";
if ($p == 'Netherlands') echo "Netherlands";
if ($p == 'New Zealand') echo "New Zealand";
if ($p == 'Nigeria') echo "Nigeria";
if ($p == 'Norway') echo "Norway";
if ($p == 'Pakistan') echo "Pakistan";
if ($p == 'Panama') echo "Panama";
if ($p == 'Paraguay') echo "Paraguay";
if ($p == 'Peru') echo "Peru";
if ($p == 'Phillipines') echo "Phillipines";
if ($p == 'Poland') echo "Poland";
if ($p == 'Portugal') echo "Portugal";
if ($p == 'Puerto Rico') echo "Puerto Rico";
if ($p == 'Qatar') echo "Qatar";
if ($p == 'Republic of Montenegro') echo "Republic of Montenegro";
if ($p == 'Republic of Serbia') echo "Republic of Serbia";
if ($p == 'Romania') echo "Romania";
if ($p == 'Russia') echo "Russia";
if ($p == 'Sao Tome & Principe') echo "Sao Tome & Principe";
if ($p == 'Saudi Arabia') echo "Saudi Arabia";
if ($p == 'Senegal') echo "Senegal";
if ($p == 'Singapore') echo "Singapore";
if ($p == 'Slovakia') echo "Slovakia";
if ($p == 'Slovenia') echo "Slovenia";
if ($p == 'South Africa') echo "South Africa";
if ($p == 'Spain') echo "Spain";
if ($p == 'Sudan') echo "Sudan";
if ($p == 'Sweden') echo "Sweden";
if ($p == 'Switzerland') echo "Switzerland";
if ($p == 'Syria') echo "Syria";
if ($p == 'Taiwan') echo "Taiwan";
if ($p == 'Thailand') echo "Thailand";
if ($p == 'Tunisia') echo "Tunisia";
if ($p == 'Turkey') echo "Turkey";
if ($p == 'Uganda') echo "Uganda";
if ($p == 'United Kingdom') echo "United Kingdom";
if ($p == 'Ukraine') echo "Ukraine";
if ($p == 'United Arab Erimates') echo "United Arab Erimates";
if ($p == 'United States of America') echo "United States of America";
if ($p == 'Uruguay') echo "Uruguay";
if ($p == 'Vatican City State') echo "Vatican City State";
if ($p == 'Venezuela') echo "Venezuela";
if ($p == 'Vietnam') echo "Vietnam";
if ($p == 'Zimbabwe') echo "Zimbabwe";
}
function printaidioma(string $i) {
if ($i == "0") echo txt('idioma');
if ($i == "af") echo "Afrikaans";
if ($i == "sq") echo "Albanian";
if ($i == "ar") echo "Arabic";
if ($i == "hy") echo "Armenian";
if ($i == "az") echo "Azerbaijani";
if ($i == "eu") echo "Basque";
if ($i == "be") echo "Belarusian";
if ($i == "bs") echo "Bosnian";
if ($i == "bg") echo "Bulgarian";
if ($i == "ca") echo "Catalan";
if ($i == "zh") echo "Chinese";
if ($i == "hr") echo "Croatian";
if ($i == "cs") echo "Czech";
if ($i == "da") echo "Danish";
if ($i == "nl") echo "Dutch";
if ($i == "en") echo "English";
if ($i == "eo") echo "Esperanto";
if ($i == "et") echo "Estonian";
if ($i == "fl") echo "Filipino";
if ($i == "fi") echo "Finnish";
if ($i == "fr") echo "French";
if ($i == "de") echo "German";
if ($i == "el") echo "Greek";
if ($i == "gn") echo "Guarani";
if ($i == "hn") echo "Hawaiian";
if ($i == "he") echo "Hebrew";
if ($i == "hi") echo "Hindi";
if ($i == "hu") echo "Hungarian";
if ($i == "is") echo "Icelandic";
if ($i == "id") echo "Indonesian";
if ($i == "ga") echo "Irish";
if ($i == "it") echo "Italian";
if ($i == "ja") echo "Japanese";
if ($i == "kk") echo "Kazakh";
if ($i == "ko") echo "Korean";
if ($i == "la") echo "Latin";
if ($i == "lv") echo "Latvian";
if ($i == "lt") echo "Lithuanian";
if ($i == "mk") echo "Macedonian";
if ($i == "ms") echo "Malay";
if ($i == "mt") echo "Maltese";
if ($i == "mn") echo "Mongolian";
if ($i == "ne") echo "Nepali";
if ($i == "no") echo "Norwegian";
if ($i == "fa") echo "Persian";
if ($i == "pl") echo "Polish";
if ($i == "pt") echo "Português";
if ($i == "pa") echo "Punjabi";
if ($i == "qu") echo "Quechua";
if ($i == "ro") echo "Romanian";
if ($i == "rm") echo "Romansh";
if ($i == "ru") echo "Russian";
if ($i == "gd") echo "Scottish Gaelic";
if ($i == "sr") echo "Serbian";
if ($i == "sk") echo "Slovak";
if ($i == "sl") echo "Slovenian";
if ($i == "es") echo "Spanish";
if ($i == "su") echo "Sundanese";
if ($i == "sw") echo "Swahili";
if ($i == "sv") echo "Swedish";
if ($i == "th") echo "Thai";
if ($i == "tp") echo "Tupi";
if ($i == "tr") echo "Turkish";
if ($i == "uk") echo "Ukrainian";
if ($i == "uz") echo "Uzbek";
if ($i == "vi") echo "Vietnamese";
if ($i == "cy") echo "Welsh";
if ($i == "yi") echo "Yiddish";
if ($i == "yo") echo "Yoruba";
if ($i == "zu") echo "Zulu";    
}

include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
