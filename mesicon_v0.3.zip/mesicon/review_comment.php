<?php
include('config.php'); // start session, open conn, set charset
include('incl_lang.php');
include('incl_functions.php');
// include('incl_debug.php');


global $lang;
$lang = $_SESSION['user']['lang'];

if ($_SESSION['user']['role'] == "Manager" || $_SESSION['user']['role'] == "Administrator") {

    global $conn;
    $sql = "SELECT * FROM 02_mesicon_comments_temp WHERE created_at LIKE '%" . $_GET['c'] . "%' AND status=1"; // só permite ao receptor do comentário avaliar uma vez
    $result = mysqli_query($conn, $sql);
    $field = mysqli_fetch_assoc($result);
    if ($field) {

        /*
        echo "id: " . $field['id'] . "<br>";
        echo "username_commenter: " . $field['username_commenter'] . "<br>";
        echo "id_commenter: " . $field['id_commenter'] . "<br>";
        echo "id_creator: " . $field['id_creator'] . "<br>";
        echo "id_post: " . $field['id_post'] . "<br>";
        echo "tabela: " . $field['tabela'] . "<br>"; // "table" é nome protegido no mysql
        echo "status: " . $field['status'] . "<br>";
        echo "txt: " . $field['txt'] . "<br>";
        echo "created_at: " . $field['created_at'] . "<br>";
        */

        $id = $field['id'];
        $id_post = $field['id_post'];
        $tabela = $field['tabela'];
        $id_commenter = $field['id_commenter'];
        $username_commenter = $field['username_commenter'];
        $created_at = $field['created_at'];
        $txt = $field['txt'];
        // echo $sql; //debug
        if ($tabela == 1) $table = "02_mesicon_books";
        $sql = "SELECT author, title FROM $table WHERE id = $id_post";
        $io = mysqli_fetch_assoc(mysqli_query($conn, $sql));
        //echo $sql; //debug

        ?>

        <!DOCTYPE html><html><head>
        <style>
        .comments {
            width: 90%;
            font-size: 1.5em;
            text-align: left;
            padding: 19px;
            background-color: #dddddd;
            display: block;
            border-radius: 20px;
        }
        </style>
        <script>
        function reject() { return confirm('MESICON\n\nConfirma rejeitar?\n\nConfirm reject?'); }
        function approve() { return confirm('MESICON\n\nConfirma aprovar?\n\nConfirm approve?'); }
        </script>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

        </head><body>

        <div><center><h1><br><br><a href='https://statos.com/mesicon' target='_blank'>statos.com/mesicon</a><br><br>------------------------------------<br><br>

        <a href="user.php?id=<?= $id_commenter ?>&v=p" target="_blank"><?= $username_commenter ?></a> <?= txt('escreveu') ?> (<?= $created_at ?>):
        <br><br>

        <div class="comments"><?= $txt ?></div><br>

        <?= txt('com1') ?>: <a href="post.php?id=<?= $id_post ?>&t=1" target="_blank"><?= $io['author'] ?>. <i><?= $io['title'] ?></i></a>.<br><br>

        <?= txt('com2') ?>.<br><br>

        <?php
        if ($_SESSION['user']['role'] == "Manager") {
            echo "<br><a href='comments.php?approve_comments=$id&t=1' onclick='return approve();'>" . txt('aprovar_M') . "</a> ----- <a href='comments.php?delete_post=$id&t=4&go2=comments' onclick='return reject();'>" . txt('rejeitar_M') . "</a>";
        }
    } else echo "<html><body><div><center><h1><br><br><a href='https://statos.com/mesicon' target='_blank'>statos.com/mesicon</a><br><br>------------------------------------<br><br>" . txt('com4') . ".";
    ?>

    <br><br><br><?= txt('com3') ?>.<br><br></center></div>

    </body></html>

    <?php

} else {
    echo txt('proibido');
}

?>










