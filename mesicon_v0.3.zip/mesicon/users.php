<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

$admins = getUsers();

$roles = ['Manager', 'User'];
$statuses = ['Waiting', 'Authorized', 'Suspended'];
error_reporting(0);
$emailatualizado = $_GET['emailatualizado'];
error_reporting(1);

	if ($emailatualizado) { // TODO: enviar email de autorizado apenas para autorizados! se mudar de grupo, manda email comunicando apenas isso !!!!
        // TODO: send email with authorization only to authorized! If his user/permission group changes, send message informing only this!
		echo $emailatualizado . " atualizado/updated !";
		$emailSubject = "(AUTORIZADO/AUTHORIZED) MESICON";
        $msg = "Esta é uma mensagem automática, por favor não a responda.\nThis is an automatic message, please do not respond to it.";
        $msg .= "\n----------\n";
		$msg .= "Bem-vinda(o) ao MESICON!\nWelcome to MESICON!\n\n";
		$msg .= "Você está autorizada(o).\nYou are authorized.\n\n";
		$msg .= "Seu nome de usuário:\nYour user name:\n" . $username;
		$msg .= "\n\nSeu email:\nYour e-mail:\n" . $emailatualizado;
        $msg .= "\n\nSua senha não será exibida aqui por segurança. Para alterá-la utilize a opção 'Lembrar senha' no link abaixo:\nYour password will not be displayed here for security. To change it use 'Recover password ' here: https://statos.com/mesicon/login.php?e=" . $email . "\n";
            $msg .= "\n----------\n\n";
            $msg .= "Manuscritos e Edições SIstema de CONtrole - MESICON\n";
            $msg .= "statos.com/mesicon\n\n";
            $msg .= "Se você considera esta mensagem um erro, delete-a sem problemas.\nIf you consider this message an error, please delete it.\n\n\n\n";
		
		$emailsender = "apps@statos.com";

		$headers = "MIME-Version: 1.1\n";
		$headers .= "Content-type: text/plain; charset=UTF-8\n";
		$headers .= "X-Priority: 1\n"; // send with max priority
		$headers .= "From: " . $emailsender . "\n"; // sender
		$headers .= "Return-Path: " . $emailsender . "\n"; // return-path

		// TODO - discover why, in the below code, email is sent even in "else"
		if(!mail($emailatualizado, $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Postfix
			// $headers .= "Return-Path: " . $emailsender . $quebra_linha; // not Postfix
			mail($emailatualizado, $emailSubject, $msg, $headers );
			// sent
		} else {
			// error - TODO: error message here lazy boy!
		}
	}

?>


<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>Admin | Manage Users</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<!-- Only Admin can access -->
<?php if ($_SESSION['user']['role'] == "Administrator"): ?>


    <!-- 
        // mt_rand(min,max), php function in below line, is four times faster than default "rand()". Both raise 10 chars and in "mt" if max < min it goes HADOUKEN
    -->
    <?php echo "<center><h1>Usuários<br></h1><h3><a href='control_panel.php'>&lt;&lt; Volta Painel</a></h3></center>"; ?>

    <!-- <div class="table-div"> commented because it was repeated below without style -->

        <!-- Display notification message -->
        <?php include('incl_messages.php') ?>

        <?php if (empty($admins)): ?>
            <h1>No admins in the database.</h1>
        <?php else: ?>

            <table class="table" align="center" width="100%">
                <thead>
                    <th><font size="-1">#</font></th>
                    <th><font size="-1">user</font></th>
                    <th><font size="-1">id</font></th>
                    <th><font size="-1">role</font></th>
                    <th><font size="-1">status</font></th>
                    <th colspan=2><font size="-1">actions</font></th>
                    <th><font size="-1">created_at</font></th>
                </thead>
                <tbody>
                <?php foreach ($admins as $key => $admin): ?>
                    <tr>
                        <td><font size="-1"><?= $key + 1 ?></font></td>

                        <td><font size="-1"><?php 
                            // TODO: create page to contact user -->
                            echo "<a href=enviaemail.php?p=statos&email=" . $admin['email'] . " target=_blank>" . $admin['username'] . "</a>";
                        ?></font></td>

                        <td><font size="-1"><?= $admin['id'] ?></font></td>
                        
                        <td><?= mb_substr($admin['role'], 0, 1) ?></td>

                        <td>
                        <?php
                            if ($admin['status'] == "Authorized") echo "ok";
                            else echo mb_substr($admin['status'], 0, 4);
                        ?>
                        </td>

                        <td>
                        <?php if ($admin['role'] != "Administrator") { ?>
                            <a href="user.php?id=<?= $admin['id'] ?>&v=p">edit</a></td>
                        <?php } ?>

                        <td>
                        <?php if ($admin['role'] != "Administrator") { ?>
                            <script>
                                function vai(i) {return confirm('Excluir - ' + i + ' - ?');}
                            </script>
                            <a href="users.php?delete_post=<?= $admin['id'] ?>&t=5&go2=users" onclick="return vai('<?= $admin['username'] ?>');">del</a>
                        <?php } ?>
                        </td>

                        <td><font size="-1"><a href="javascript:alert('MESICON\n\nAtualizado em <?= $admin['updated_at'] ?>');"><?= mb_substr($admin['created_at'],0,10) ?></a></font></td>

                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        <?php endif ?>

    <!-- // Display records from DB -->
		




<?php else: ?>

    <h1 style="text-align: center; margin-top: 20px;">
    <?= txt('proibido') ?>.
    </h1>

<?php endif ?>

<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
