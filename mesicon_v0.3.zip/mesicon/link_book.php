<?php
include('config.php'); // start session, open conn, set charset
// include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');
?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Vincular Livro a Manuscrito / Link Book to Manuscript</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<h1><?= txt('vincularlam') ?></h1>

<?php echo "<h3><a href=control_panel.php>&lt;&lt; " . txt('voltar') . " " . txt('paineldecontrole') . "</a></h3>"; ?>
	
    <br><br><?= txt('vinculartxt') ?>.<br><br>

    <?php
    include('incl_messages.php');
	if ($_SESSION['user']['status'] == "Suspended") {
		echo "<h2><center><font color=red>" . txt('proibido') . "</font></center></h2>";
	} // usuário suspenso, ele que lute
	?>

    <h2><br>
    <?php
        
    if ($_SESSION['user']['role'] == "Administrator" || $_SESSION['user']['role'] == "Manager") {
    
        echo "<form name='statosdotcomForm' method='' action='' onsubmit='getOptionText()'>";
        
        $order = "created_at";
        $asc_or_desc = "desc";
        $table = "2"; // corresponde ao array que vai ler info apenas nas oficiais "books" e "manuscripts"
        $posts = getAllBAM($table, $order, $asc_or_desc);

        $fechaform = 1; 
        
        
        /////////////////////////////////////////////////        
        $contabela = 0;
        foreach ($posts as $key => $post):

            //debug echo "<br>key: " . $key . "<br>";        
            if ($key == "02_mesicon_books") {
                echo txt('selivro') . ":<br><select name=book id=book>";
                $contabela = 0; // zera o contador para começar a exibir registros desde o início do "key" (tabela)
                while ($contabela < count($post)) {                
                    //debug echo "<br>count(post): " . count($post) . "<br>"; // exibe total de registros na "key" (tabela) atual
                    //debug echo "creator_id: " . $post[$contabela]['creator_id'] . "<br>";                
                    if (($_SESSION['user']['id'] == $post[$contabela]['creator_id']) && ($post[$contabela][''] == "")) :
                        if ($post[$contabela]['link_id'] == 0) {
                            echo "<option value=" . $post[$contabela]['id'] . ">";
                                if (strlen($post[$contabela]['title']) > 31) echo substr($post[$contabela]['title'],0,30) . "...";
                                else echo $post[$contabela]['title'];
                                if ($post[$contabela]['ed_number'] != 0) echo " " . $post[$contabela]['ed_number'] . "ed";
                            echo "</option>";
                            
                            //echo "</option><input type=hidden name=link_title value='" . $post[$contabela]['title'] . "'>";
                            
                            // echo "contabela: " . $contabela . "<br>"; // debug
                            //debug echo "author: " . $post[$contabela]['author'] . "<br>";
                        } // só lista quem ainda não linkado
                    endif;
                    $contabela++;
                }
                echo "</select><input type=hidden name=link_title><br><br>"; // this hidden input receives the choosen book as the first action of the posting
            }

            //debug echo "<br>key: " . $key . "<br>";        
            if ($key == "02_mesicon_manuscripts") {
                echo txt('selman') . ":<br><select name=manuscript id=manuscript>";
                $contabela = 0; // zera o contador para começar a exibir registros desde o início do "key" (tabela)
                while ($contabela < count($post)) {                
                    //debug echo "<br>count(post): " . count($post) . "<br>"; // exibe total de registros na "key" (tabela) atual
                    //debug echo "creator_id: " . $post[$contabela]['creator_id'] . "<br>";                
                    if ($_SESSION['user']['id'] == $post[$contabela]['creator_id']) :
                        if ($post[$contabela]['link_id'] == 0) {
                            echo "<option value=" . $post[$contabela]['id'] . ">";
                                if (strlen($post[$contabela]['author']) > 31) echo substr($post[$contabela]['author'],0,30) . "...";
                                else echo $post[$contabela]['author'];
                            echo "</option>";
                            //debug echo "contabela: " . $contabela . "<br>";
                            //debug echo "author: " . $post[$contabela]['author'] . "<br>";
                        } // só lista quem ainda não linkado
                    endif;
                    $contabela++;
                }
                echo "</select>";
            }

        endforeach;

        //debug echo "<br>contabela: $contabela<br><br>";
        
        if ($contabela == 0) {
            //echo "Você não possui livro para vincular";
            $fechaform++;
        }

        ?>

        <script>
        function getOptionText() {
            var sel = document.getElementById("book");
            var text= sel.options[sel.selectedIndex].text;
            this.document.statosdotcomForm.link_title.value = text;
        }
        </script>

        <input id=notb type=hidden value="<?= txt('vincularnotb') ?>">
        <input id=notm type=hidden value="<?= txt('vincularnotm') ?>">
        
        <script>
            var $errb = document.getElementById('notb').value;
            var $errm = document.getElementById('notm').value;
            //if (document.getElementById('book')) {if (document.getElementById('book').options.length == 0) document.write($errb);} else {document.write($errb);}
            //if (document.getElementById('manuscript')) {if (document.getElementById('manuscript').options.length == 0) document.write($errm);} else {document.write($errm);}
            //if (document.getElementById('manuscript')) {if (document.getElementById('manuscript').options.length == 0) document.write('<br><p style="color:#990000">' . $errm . '.</p>');} else {document.write('<br><p style="color:#990000">' . $errm . '.</p>');}
            if (document.getElementById('book')) {
                if (document.getElementById('book').options.length == 0) {
                    document.write('<br><p style="color:#990000">');
                    document.write($errb);
                    document.write('</p>');
                    var erro = 1;
                }
            }
            if (document.getElementById('manuscript')) {
                if (document.getElementById('manuscript').options.length == 0) {
                    document.write('<br><p style="color:#990000">');
                    document.write($errm);
                    document.write('</p>');
                    var erro = 1;
                }
            }
        </script>
                
        <?php

        $x = "<script>document.write(erro);</script>";
        if ($x == "undefined") $fechaform = 2;
        
        if ($fechaform == 1) echo "<br><br><input type=submit name='link_book' value='" . txt('vincular_M') . "' class='btn'></form>";
        else echo "<br><font color='#990000'>" . txt('vinculartxt2') . ".</font>"; // "para vincular um livro a um manuscrito..."
        
        //echo $fechaform; // debug
    
    } else {
        header("location: logout.php?p=index");
        exit(0);
    }

    ?>
    </h2>
	
<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>

