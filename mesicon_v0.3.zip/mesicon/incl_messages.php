<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<?php
/*
if (isset($_SESSION['message'])) :
	<div class=message><p>
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
	</p></div>
endif
*/



/*************************************************
HOW TO USE:

1) put the below line in your code, making the necessary changes:
$_SESSION['message'] = "<msg><space><colorcode>";
2) redirect the user to a page where this file "incl_messages.php" is loaded as an include

Where:
<msg> is your personal message
<space> is a blank space
<colorcode> is a code to control the theme color of the message, that can be:
	1 (green, for success messages)
	2 (yellow, for attention messages)
	3 (red, for error messages)
	
So, for example, if you want to alert you user that he did something right, you could use:
$_SESSION['message'] = "Ok! 1";
By another side, again as an example, if something gone wrong, you could use:
$_SESSION['message'] = "Data not found 3";
To alert something:
$_SESSION['message'] = "Important info! 2";

****************************************************/



if ($_SESSION['message'] != "") {
    
    if (getLastWord($_SESSION['message']) == "1") echo "<div class=message1>"; // yellow
    if (getLastWord($_SESSION['message']) == "2") echo "<div class=message2>"; // green
    if (getLastWord($_SESSION['message']) == "3") echo "<div class=message3>"; // red
    
	echo substr($_SESSION['message'], 0, strlen($_SESSION['message'])-1) . "</div>";
	
    unset($_SESSION['message']);
}
?>