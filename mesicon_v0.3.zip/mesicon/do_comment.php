<?php
include('config.php'); // start session, open conn, set charset
include('incl_functions.php');

if ($_SESSION['user']['role'] == "Manager" || $_SESSION['user']['role'] == "Administrator") {

$username_commenter = $_POST['username_commenter'];
$id_commenter = $_POST['id_commenter'];
$creator_id = $_POST['creator_id'];
$id_post = $_POST['id_post'];
$tabela = $_POST['tabela']; // "table" is reserved word in mysql ! pay attention noob
$txt = esc($_POST['txt']); // TODO: enable
$status = 1;
    
insertUserComment($username_commenter, $id_commenter, $creator_id, $id_post, $tabela, $txt, $status);

} else {
    echo "Not authorized (Você não está autorizado a executar esta tarefa).";
}

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->
