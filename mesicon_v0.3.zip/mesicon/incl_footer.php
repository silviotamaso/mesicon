<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

</div> <!-- close div id="pagediv" opened in incl_navbar.php -->

<br><br><br>

<!--
<p align=right><a href="https://html5.validator.nu/?doc=https://statos.com<?= $_SERVER['REQUEST_URI'] ?>" target="_blank">W3C</a>&nbsp;&nbsp;&nbsp;</p>
-->

<footer>
    
<?= date('Y'); ?> &copy; statos.com&nbsp; - &nbsp;<a href="TOU.php"><?= txt('tou') ?></a>
    
&nbsp;<a href="share.php"><img src="static/share.gif" alt="Compartilhar" height="9vh" border=0></a>&nbsp;
    
<a class="resp-sharing-button__link" href="https://twitter.com/intent/tweet/?text=Lembrei%20de%20você!%20Veja:%20muito%20útil%20para%20quem%20trabalha%20com%20livros%20e%20manuscritos.&amp;url=https://statos.com/mesicon" target="_blank" rel="noopener">&nbsp;twit&nbsp;</a>
    
<a class="resp-sharing-button__link" href="https://facebook.com/sharer/sharer.php?u=http%3A%2F%2Fstatos.com%2Fmesicon" target="_blank" rel="noopener">&nbsp;face&nbsp;</a>

<a class="resp-sharing-button__link" href="whatsapp://send?text=Lembrei%20de%20você!%20Veja:%20muito%20útil%20para%20quem%20trabalha%20com%20livros%20e%20manuscritos.%20http%3A%2F%2Fstatos.com%2Fmesicon" target="_blank" rel="noopener">&nbsp;whats&nbsp;</a>

</footer>

<br><br></body> <!-- opened in incl_navbar.php -->

<script>

var menuList = document.getElementById("menuList");
//menuList.style.maxHeight = "0px"; // height of portable menu
function togglemenu() {
    if (menuList.style.maxHeight == "0px") {
        menuList.style.maxHeight = "260px"; 
    } else {
        menuList.style.maxHeight = "0px";
    }
}

function copyToClipboard(text) {
    var dummy = document.createElement("textarea");
    // to avoid breaking orgain page when copying more words
    // cant copy when adding below this code
    // dummy.style.display = 'none'
    document.body.appendChild(dummy);
    //Be careful if you use texarea. setAttribute('value', value), which works with "input" does not work with "textarea". – Eduard
    dummy.value = text;
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
}
//copyToClipboard('https://statos.com/mesicon');

// intercept control+C
document.addEventListener('keydown', evt => {
    if (evt.key === 'c' && evt.ctrlKey) {
        //alert('Ctrl+C was pressed');
        copyToClipboard('https://statos.com/mesicon');
    //} else if (evt.key === 'v' && evt.ctrlKey) {
        //alert('Ctrl+V was pressed');
    }
});

// intercept right-click
window.addEventListener('click', (event) => { // left button detection
    //console.log(event.button);
    //alert('yes' + event.button);
});
window.addEventListener('contextmenu', (event) => { // right button detection
    //console.log(event.button);
    //alert('no' + event.button);
});
window.addEventListener('contextmenu', (event) => { // avoids context menu
    event.preventDefault();
    //alert('preventedDefault');
});

// forbids form resubmission message
if ( window.history.replaceState ) {
    window.history.replaceState( null, null, window.location.href );
}

</script>

</html> <!-- opened in incl_header.php -->

