<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug

// check if it is needed to show some user profile
if (stripos($_SERVER['REQUEST_URI'], '?') !== false) {
	$str_url = $_SERVER['REQUEST_URI'];
	$int_urlLen = strlen($str_url);
	$int_posAt = strpos($_SERVER['REQUEST_URI'], '?');
	$str_user2find = substr($str_url, $int_posAt+1, $int_urlLen);
	header('Location: finduser.php?u=' . $str_user2find);
	exit();
}

include('incl_header.php'); // open html and head, load css
include('incl_functions.php');
?>

<!--

///////////	///////////	////////	///////////
	//		//		//	//		//	//		//
	//		//		//	//		//	//		//
	//		//		//	//	////	//		//
	//		///////////	//////		///////////

/////////// TODO: page titles
/////////// TODO: re make a check for all session[messages] and querystrings sent from pages
/////////// TODO: page views in DB
/////////// TODO: advanced search - field ETC (to read anything in any field of DB)
/////////// TODO: insert field TOMO ("volume") in DB; transform ints in tinyints
/////////// TODO: review button EDIT/EDITAR in the begining of every post
/////////// TODO: verify which comments can be inserted in PHP (better)
/////////// TODO: link username update with the "creator" in his records
/////////// TODO: verify which answers do not appear as "not specified", in the "manuscripts", for example
/////////// TODO: verify where it is possible to insert some "share" link, maybe in the post confirmation email, in post.php etc
/////////// TODO: verify very well who can what, where, authorized or in evaluation etc
/////////// TODO: many functions in get register and save into array are the same - redundant code - improve this lazy guy!
/////////// TODO: the same in the email sendings, try to create only one multiuser/multiused sendmail()
/////////// TODO: when user = suspended, block all his actions
/////////// TODO: review all fields type ENUM in DB and see where all of them are used in phps - to better implement english/portuguese funcionality
/////////// TODO: when, in the book editings, user turn off "manuscript", alert him and, in case he proceeds, turn zero to the "link_id" collumn in "books" and in "manuscripts" (DB)
/////////// TODO: create historic/provenance and collection to books
/////////// TODO: show error msg if user try to find user profile via personal address "?"


/////////// "published" field values in tables 02_mesicon_books_temp and 02_mesicon_books
/////////// 0: default
/////////// 1: published (post is visible and can be edited by user and admin)
/////////// 2: waits revision from the user (invisible to admin)
/////////// 3: waits revision from ADM (user can't edit)
/////////// 4: user is editing post (ADM receives a flag to wait - old post, and, duplicated, enabled, the post user is updating)

-->

<meta name="url" content="https://www.statos.com/mesicon">
<LINK REL="Bookmark" HREF="favicon.ico">
<LINK REL="Shortcut Icon" HREF="favicon.ico" type="image/x-icon">
<meta name="title" content="MESICON - Manuscritos e Edições SIstema de CONtrole">
<meta name="description" content="MESICON - Manuscritos e Edições SIstema de CONtrole">
<meta name="keywords" content="MESICON - Sistema de controle de edições e manuscritos elaborado por Statos.com em maio de 2022.">
<meta name="generator" content="www.statos.com">
<meta name="author" content="www.statos.com">
<meta name="rating" content="general">
<meta name="revisit-after" content="15 days">
<meta name="language" content="portuguese">
<meta name="robots" content="index, follow">
<meta name="googlebot" content="index, follow">
<meta name="audience" content="all">
<link rel="preload" href="https://statos.com/mesicon/static/menu.png" as="image">

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Start Page/Página Inicial</title>
    
<style>
.busca li:hover {
    cursor: pointer;
    background-color: #ffffff;
}
.busca li {
    width: 100%;
    font-size: 1.3em;
    margin: 1px;
    padding: 9px 9px;
    background-color: #dddddd;
    display: block;
    box-sizing: border-box;
    border-radius: 20px;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script src="static/search_ajax.js"></script>
<!-- fecha search -->

<script>
function vai(el,m) {alert(m);el.focus();}
function valida(f) {
	if (f.busca.value.length < 2) { vai(f.busca,'MESICON\n\nNome inválido.\n\nInvalid name.');return false; }
    else if ((f.busca.value=="") || (f.busca.value==" ")) {
        vai(f.busca,"MESICON\n\nNome?\n\nName?");return false;
    } else {
        return true;
	}
}
</script>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->   
    
<?php
    include('incl_messages.php');
    
    global $conn;
    
    echo "<center><table><tr><td>";
    $sql = "SELECT COUNT(*) as total FROM 02_mesicon_books WHERE published=1 OR published=4";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    echo "<br><h3>" . $row['total'] . " " . txt('livros') . ".<br>";
    
    $sql = "SELECT COUNT(*) as total FROM 02_mesicon_manuscripts WHERE published=1 OR published=4";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    echo $row['total'] . " " . txt('manuscritos') . ".<br>";
    
    $sql = "SELECT COUNT(*) as total FROM 02_mesicon_users";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    echo $row['total'] . " " . txt('usuarios_cadastrados') . ".</h3>";
    
    echo "</font></td></tr></table></center>";
    
    ?>

    <br>
    <!-- <h1><?= txt('buscar') ?></h1> -->
    <form name="statosdotcomForm" method="post" action="search.php" onSubmit="return valida(this);" style="display: inline; margin: 0;">
        <!-- below line: ID MUST BE "SEARCH" OR AUTOCOMPLETE CAN'T WORK !!! -->
        <input type="text" id="search" name="busca" placeholder="<?= txt('buscarautor') ?>" style="display: inline; margin: 0;"> <a href=# onclick="javascript:statosdotcomForm.reset();">x</a>
        <div id="display" class="busca"></div>
        <!-- <input type="hidden" name="p" value="1"> TODO: try to resolve - commented because it was raigins HADOUKEN with "back" -->
        <br><img src="static/spacer.gif" width=1 height=9><br><button type="submit" class="btn" name="login-btn"><?= txt('buscar_M') ?></button><br>
    </form>
    <h4><a href="advanced_search.php"><?= txt('busca_avancada') ?></a><br><br></h4>
    
        

    <div id="layout_4col">
    
    
    
<div class="col1">
<h1><?= txt('ultimas_atualizacoes') ?></h1>
    <?php
    $count = 0;
    $posts = getLatestBAM();
    foreach ($posts as $post): ?>
        <br><a href="post.php?id=<?= $post['original_id'] ?>&t=<?= $post['tabela'] ?>">
            <?php
    // TODO: try to show also manuscripts in home page - stoped here
            echo "<img width=50 height=50 src='static/ico";
            if ($post['tabela'] == 1) {
                if ($post['manuscript'] == 1) echo "both";
                else echo "book";
            }
            if ($post['tabela'] == 3) echo "manuscript";
            echo ".gif'><br>";
            if ($post['title']) {
                ?>
                <!-- <p class="tit"> -->
                    <?php
                    echo '"';
                    if (strlen($post['title']) > 36) echo substr($post['title'],0,35) . "...";
                    else echo $post['title'];
                    echo '"';
                    ?>
                    <?php if ($post['ed_number'] != 0) echo $post['ed_number'] . ".ed."; ?>
                <br>
                <!-- </p> -->
                <?php
            }
            ?>
            <!-- <p class="aut"> -->
                <?php
                if (strlen($post['author']) > 36) echo substr($post['author'],0,35) . "...";
                else echo $post['author'];
                ?>
            <!-- </p> -->
            <p style="text-align: right;"><font style="font-size: 0.6em;"><?= $post['creator'] ?> (<?= date("j F Y, g:i", strtotime($post["created_at"])) . ")</font>"; ?></p>
        </a><br>
    <?php
    if ($count++ > 21) break;
    endforeach;
    ?>
</div> <!-- updates -->

    
<div class="col2">
<h1><?= txt('ultimos_comentarios') ?></h1><br>
    <?php
    $count = 0;
    $posts = getComments("todos","index"); // which comments will be displayed, which states they are (1: waiting revision; 2: waiting revision from GOD; 3: approved)
    foreach ($posts as $post): ?>
        <a href="post.php?id=<?= $post['id_post'] ?>&t=1">
            <?= $post['username_commenter'] ?> (<?= date("j F Y, g:i", strtotime($post["created_at"])) ?>):<br>
            <p>"<?php
            if (strlen($post['txt']) > 150) echo substr($post['txt'],0,150) . "...";
            else echo $post['txt'];
            ?>".</p><br>
            <!-- TODO: try to show also where comment was done -->
        </a>
    <?php
    if ($count++ > 20) break; // in "02_mesicon_comments" stay only 25 records, always, the oldest being deleted when the newer appears
    endforeach;
    ?>
</div> <!-- comments -->
    

<div class="col3">
<h1><?= txt('novos_usuarios') ?></h1><br>
    <?php
    $count = 0;
    $users = getLatestUsers();
    foreach ($users as $user):
        $count++;
        if ($count < 20) {
            // oldest - echo "<a href='user.php?id=" . $user['id'] . "&v=p'>" . $user['username'] . " (<font size='-1'>" . date("j F Y, g:i", strtotime($post["created_at"])) . "</font>)</a><br><br>";
            // old - echo "<a href='user.php?id=" . $user['id'] . "&v=p'>" . $user['username'] . " (" . (new DateTime($user["created_at"]))->format('d/m/Y') . ")</a><br><br>";
            echo "<a href='https://statos.com/mesicon?" . $user['username'] . "'>" . $user['username'] . " (" . (new DateTime($user["created_at"]))->format('d/m/Y') . ")</a><br><br>";
        } else {
            break;
        }
    endforeach;
    ?>
</div> <!-- users -->
    
 

<style>
.mySlides {display: none;}

/* Slideshow container */
.col4 {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 9px;
  width: 9px;
  margin: 0 1px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>


 
<div class="col4">

<div style="text-align:center">
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
</div>

<div class="mySlides">
    <table width="100%">
    <tr><td align="left">
    <h3><?= txt('idx_col4_oque') ?>?</h3> <h4><?= txt('idx_col4_1') ?>.</h4>
    </td></tr></table><br>
</div>
<div class="mySlides">
    <table width="100%">
    <tr><td align="right">
    <h3><?= txt('idx_col4_como') ?>?</h3> <h4><?= txt('idx_col4_2') ?>.</h4>
    </td></tr></table><br>
</div>
<div class="mySlides">
    <table width="100%">
    <tr><td align="left">
    <h3><?= txt('idx_col4_paraquem') ?>?</h3> <h4><?= txt('idx_col4_3') ?>.</h4>
    </td></tr></table><br>
</div>
<div class="mySlides">
    <table width="100%">
    <tr><td align="right">
    <h3><?= txt('idx_col4_quemais') ?>?</h3> <h4><?= txt('idx_col4_4') ?>.</h4>
    </td></tr></table><br>
</div>
<div class="mySlides">
    <table width="100%">
    <tr><td align="left">
    <h3><?= txt('manuscritos') ?>?</h3> <h4><?= txt('idx_col4_5') ?>.</h4>
    </td></tr></table><br>
</div>
<div class="mySlides">
    <table width="100%">
    <tr><td align="right">
    <h3><?= txt('idx_col4_periodicos') ?>?</h3> <h4><?= txt('idx_col4_6') ?>.</h4>
    </td></tr></table><br>
</div>
<div class="mySlides">
    <table width="100%">
    <tr><td align="left">
    <h3><?= txt('idx_col4_free') ?>!</h3> <h4><?= txt('idx_col4_7') ?>.</h4>
    </td></tr></table><br>
</div>

</div>

<script> 
var slideIndex = 0;
carousel();
function carousel() {
	let i;
	let slides = document.getElementsByClassName("mySlides");
	let dots = document.getElementsByClassName("dot");
	for (i = 0; i < slides.length; i++) {
	slides[i].style.display = "none";  
	}
	slideIndex++;
	if (slideIndex > slides.length) {slideIndex = 1}    
	for (i = 0; i < dots.length; i++) {
	dots[i].className = dots[i].className.replace(" active", "");
	}
	slides[slideIndex-1].style.display = "block";  
	dots[slideIndex-1].className += " active";
	setTimeout(carousel, 9999); // Change every 10 sec
}
</script>
	
<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>

    
    
    