<?php
include('config.php');
// include('incl_debug.php');

//$p = htmlspecialchars($_GET["p"]);
$p = $_POST["p"];
$temp = $_POST["temp"];
$oquemuda = $_POST["oquemuda"]; // if = 1 change email, if = 2 change pass, if = 3 change both (if = 0 then HADOUKEN)

if ($p === "statos") { // only runs if password is present

	$email_to = $_POST["email_to"];
	$pass_to = $_POST["pass_to_sha3"];
	$ok = 0;

	/*
	$conn = mysqli_connect("localhost", "statos_user2", "501247xr", "statos_dbase");	 
	if ($conn === false) {
		echo "(changemail_do.php) ERROR: Could not connect (Falha de conexao)."; 
		die ("(changemail_do.php) ERROR: Could not connect (Erro de conexao): " . mysqli_connect_error());
	}
	// echo "Connect Successfully. Host info: " . mysqli_get_host_info($conn); // print detailed host info
	*/

	$sql = "SELECT temp FROM 02_mesicon_users WHERE temp = '" . $temp . "'";
	
	if ($result = mysqli_query($conn, $sql)) {
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_array($result)) {
				
				/*
				echo "<br>temp " . $temp;
				echo "<br>oquemuda " . $oquemuda;
				echo "<br>email_to " . $email_to;
				echo "<br>pass_to " . $pass_to;
				*/
				
				if ($oquemuda == 1) {$sql = "UPDATE 02_mesicon_users SET email = '$email_to' WHERE temp = '$temp'";}
				if ($oquemuda == 2) {$sql = "UPDATE 02_mesicon_users SET password = '$pass_to' WHERE temp = '$temp'";}
				if ($oquemuda == 3) {$sql = "UPDATE 02_mesicon_users SET email = '$email_to', password = '$pass_to' WHERE temp = '$temp'";}

				if (mysqli_query($conn, $sql)) { 
					//foi
					$ok++;
				} else {
					echo "ERROR: email not updated (changemail_do.php).";
				}
				
			}
			
			// Free result set
			mysqli_free_result($result);

		}
		
	} else {
		echo "ERROR: Could not able to execute $sql.<br>" . mysqli_error($conn);
	}
	
	
	mysqli_close($conn);
	
	
	echo "<html><body><center><h1><br><br>MESICON<br><br>";
	if ($ok == 1) {
		echo "Ok, updated (Informações atualizadas com sucesso)!";
	} else {
		echo "Not authorized (Não autorizado).";
	}
	echo "<br><br>------------------------------------<br><br><a href='https://statos.com/mesicon/logout.php?p=login'>statos.com/mesicon</a><br><br></h1></center></body></html>";


} else {
	echo "403: forbidden"; // closes if password not present
}

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->
