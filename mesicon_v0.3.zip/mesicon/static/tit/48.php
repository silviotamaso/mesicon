M"""""`'"""`YM MM""""""""`M MP""""""`MM M""M MM'""""'YMM MMP"""""YMM M"""""""`YM 
M  mm.  mm.  M MM  mmmmmmmM M  mmmmm..M M  M M' .mmm. `M M' .mmm. `M M  mmmm.  M 
M  MMM  MMM  M M`      MMMM M.      `YM M  M M  MMMMMooM M  MMMMM  M M  MMMMM  M 
M  MMM  MMM  M MM  MMMMMMMM MMMMMMM.  M M  M M  MMMMMMMM M  MMMMM  M M  MMMMM  M 
M  MMM  MMM  M MM  MMMMMMMM M. .MMM'  M M  M M. `MMM' .M M. `MMM' .M M  MMMMM  M 
M  MMM  MMM  M MM        .M Mb.     .dM M  M MM.     .dM MMb     dMM M  MMMMM  M 
MMMMMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMMM MMMM MMMMMMMMMMM MMMMMMMMMMM MMMMMMMMMMM