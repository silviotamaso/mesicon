`7MMM.     ,MMF'`7MM"""YMM   .M"""bgd `7MMF' .g8"""bgd   .g8""8q. `7MN.   `7MF'
  MMMb    dPMM    MM    `7  ,MI    "Y   MM .dP'     `M .dP'    `YM. MMN.    M  
  M YM   ,M MM    MM   d    `MMb.       MM dM'       ` dM'      `MM M YMb   M  
  M  Mb  M' MM    MMmmMM      `YMMNq.   MM MM          MM        MM M  `MN. M  
  M  YM.P'  MM    MM   Y  , .     `MM   MM MM.         MM.      ,MP M   `MM.M  
  M  `YM'   MM    MM     ,M Mb     dM   MM `Mb.     ,' `Mb.    ,dP' M     YMM  
.JML. `'  .JMML..JMMmmmmMMM P"Ybmmd"  .JMML. `"bmmmd'    `"bmmd"' .JML.    YM