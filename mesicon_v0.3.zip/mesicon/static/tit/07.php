d88b_o8b   ,d8PPPP 88888888     8888 doooooo 88888888 888  ,d8 
d88 8'8b   d88ooo  88ooooPp     8888 d88     888  888 888_dPY8 
d88   8b ,88'             d8    8888 d88     888  888 8888' 88 
Y88   8P 88bdPPP   8888888P     8888 d888888 888oo888 Y8P   Y8