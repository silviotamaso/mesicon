<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<?php

$errors = [];

if (isset($_POST['admin_update_book'])) adminUpdateBook($_POST);
if (isset($_POST['admin_update_manuscript'])) adminUpdateManuscript($_POST);
if (isset($_POST['create_book'])) createBook($_POST); // coming from create_book.php
if (isset($_POST['create_manuscript'])) createManuscript($_POST); // coming from create_manuscript.php
if (isset($_POST['edit_book'])) { $post_id = $_POST['id']; editBook($post_id); } // coming from review_book.php
if (isset($_POST['edit_manuscript'])) { $post_id = $_POST['id']; editManuscript($post_id); } // coming from review_manuscript.php
if (isset($_POST['update_book_from_review'])) updateBookFromReview($_POST); // saves book revision and waits for approval; "published = 3"
if (isset($_POST['update_manuscript_from_review'])) updateManuscriptFromReview($_POST); // saves manuscript revision and waits for approval; "published = 3"
if (isset($_POST['update_reviewing_book'])) updateReviewingBook($_POST); // update book being edited by user; "published = 2"
if (isset($_POST['update_reviewing_manuscript'])) updateReviewingManuscript($_POST); // update manuscript being edited by user; "published = 2"
if (isset($_POST['update_user'])) { updateUser($_POST); }
if (isset($_GET['admin_editing_user'])) {
	$id = $_GET['admin_editing_user'];
	adminEditingUser($id);
}
if (isset($_GET['approve_comments'])) {
    if ($_SESSION['user']['role'] == "Administrator" || $_SESSION['user']['role'] == "Manager") {
        $id = $_GET['approve_comments'];
        $type = $_GET['t'];
        if ($type == 1) userApproveComments($id);
        if ($type == 2) godApproveComments($id);
    } else echo txt('proibido') . ".";
}
if (isset($_GET['delete_post'])) {
	$post_id = $_GET['delete_post'];
	$table = $_GET['t']; // 0 = books_temp; 1 = books; 2 = man_temp; 3 = man; 4 = comments; 5 = users; 6 = latest >>> PAY ATTENTION MOFO !
	$go2 = $_GET['go2']; // return page
	deletePost($post_id, $table, $go2);
}
if (isset($_GET['edit_user'])) {
	$id = $_GET['edit_user'];
	editUser($id);
}
if (isset($_GET['link_book'])) {
    $b = $_GET['book'];
    $m = $_GET['manuscript'];
    $t = $_GET['link_title'];
    linkBook($b, $m, $t);
}
if (isset($_GET['change_lang'])) {
    if ($_SESSION['user']['lang'] == "pt") {
        $_SESSION['user']['lang'] = "en";
    } else {
        $_SESSION['user']['lang'] = "pt";
    }
    header('location: https://statos.com/mesicon');
    exit;
}
if (isset($_GET['publish']) || isset($_GET['unpublish'])) {
    $table = $_GET['t'];
    if (isset($_GET['publish'])) {
        $post_id = $_GET['publish'];
        $creator_id = $_GET['c']; // useful in historic update
        $author = $_GET['a']; // useful in sendmail
        publishPost($post_id, $creator_id, $table, $author);
    } else if (isset($_GET['unpublish'])) {
        $post_id = $_GET['unpublish'];
        unpublishPost($post_id, $table);
    }
}

function adminUpdateBook($request_values) {
    global $conn;
    $errors = [];
    $id = $request_values['id'];
    $table = $request_values['tabela'];
    $title = esc($request_values['title']);
    $author = esc($request_values['author']);
    //$org = isset($request_values['org']) ? 1 : 0; // it was this way when "org" was commanded by a checkbox
    $org = $request_values['org'];
    $ed_number = $request_values['ed_number'];
    $tomos = $request_values['tomos'];
    $series = esc($request_values['series']);
    $num_series = esc($request_values['num_series']);
    $publisher = esc($request_values['publisher']);
    $city = esc($request_values['city']);
    $state = esc($request_values['state']);
    $country = esc($request_values['country']);
    $month = $request_values['month'];
    $year = $request_values['year'];
    $idiom = esc($request_values['idiom']);
    $more_idioms = esc($request_values['more_idioms']);
    $pages = $request_values['pages'];
    $isbn = $request_values['isbn'];
    $width = $request_values['width'];
    $height = $request_values['height'];
    $front_illustrator = esc($request_values['front_illustrator']);
    $inside_illustrator = esc($request_values['inside_illustrator']);
    $translator = esc($request_values['translator']);
    $preface = esc($request_values['preface']);
    $paperback = $request_values['paperback'];
    $digital = $request_values['digital'];
    $exlibris = $request_values['exlibris'];
    $manuscript = $request_values['manuscript'];
    $printed_dedication = esc($request_values['printed_dedication']);
    $first_ear = esc($request_values['first_ear']);
    $second_ear = esc($request_values['second_ear']);
    $back = esc($request_values['back']);
    $add_info = esc($request_values['add_info']);
    $updated_at = $request_values['updated_at'];
    
    $creator_id = $request_values['creator_id'];
    $sql = "SELECT email from 02_mesicon_users WHERE id = $creator_id";
    $result = mysqli_query($conn, $sql);
	$admin = mysqli_fetch_assoc($result);
    $email_creator = $admin['email']; 
        
    if (empty($title)) { array_push($errors, "Título?/Title?"); }
    if (empty($author)) { array_push($errors, "Autor?/Author?"); } // TODO: if errors = 0 ?
    if ($table == 0) $table = "02_mesicon_books_temp";
    if ($table == 1) $table = "02_mesicon_books";
    $sql = "UPDATE $table SET title='$title', author='$author', org='$org', ed_number='$ed_number', tomos='$tomos', series='$series', num_series='$num_series', publisher='$publisher', city='$city', state='$state', country='$country', month='$month', year='$year', idiom='$idiom', more_idioms='$more_idioms', pages='$pages', isbn='$isbn', width='$width', height='$height', front_illustrator='$front_illustrator', inside_illustrator='$inside_illustrator', translator='$translator', preface='$preface', paperback='$paperback', digital='$digital', exlibris='$exlibris', manuscript='$manuscript', printed_dedication='$printed_dedication', first_ear='$first_ear', second_ear='$second_ear', back='$back', add_info='$add_info', updated_at='$updated_at', published=";
    if ($table == "02_mesicon_books") $sql = $sql . "1 WHERE id=$id"; // user is admin, publishes presto!
    else $sql = $sql . "3 WHERE id=$id"; // not admin user, send to revision
    // attach topic to post on post_topic table
    if (mysqli_query($conn, $sql)) {
        if ($table == "02_mesicon_books") {

            sendMail_postPublished($id, $email_creator, $author, "1");

            $_SESSION['message'] = "Publicado/Published 2";
            header('location: posts_adm.php');
            exit(0);
        } else {
            if ($_SESSION['user']['role'] == "Administrator") {
                $_SESSION['message'] = "Ok! Publique agora/Publish now 2";
                header('location: posts_adm.php');
            } else {
                $_SESSION['message'] = "Ok! Aguarde revisão/Wait revision 2";
                header('location: posts.php');
            }
            exit(0);
        }
    }
}

function adminUpdateManuscript($request_values) {
    global $conn;
    $errors = [];

    $id = $request_values['id'];
    $table = $request_values['tabela'];
    
    $author = esc($request_values['author']);
    $author_type = $request_values['author_type'];
    $original = $request_values['original'];
    $copy = esc($request_values['copy']);
    $title = esc($request_values['title']);
    $title_type = $request_values['title_type'];
    $signature = esc($request_values['signature']);
    $source_local = esc($request_values['source_local']);
    $source_local_type = $request_values['source_local_type'];
    $recipient = esc($request_values['recipient']);
    $recipient_type = $request_values['recipient_type'];
    $destination = esc($request_values['destination']);
    $destination_type = $request_values['destination_type'];
    $treatment = esc($request_values['treatment']);
    $postscript = esc($request_values['postscript']);
    $data = $request_values['data'];
    $data_type = $request_values['data_type'];
    $idiom = $request_values['idiom'];
    $gender = $request_values['gender'];
    $species = $request_values['species'];
    $type = $request_values['type'];
    $items = $request_values['items'];
    $description = esc($request_values['description']);
    $contents = esc($request_values['contents']);
    $autograph = $request_values['autograph'];
    $autograph_color = esc($request_values['autograph_color']);
    $typewritten = $request_values['typewritten'];
    $typewritten_color = esc($request_values['typewritten_color']);
    $medium = $request_values['medium'];
    $watermark = esc($request_values['watermark']);
    $pages = $request_values['pages'];
    $leafs = $request_values['leafs'];
    $width = $request_values['width'];
    $height = $request_values['height'];
    $anex = esc($request_values['anex']);
    $envelope = esc($request_values['envelope']);
    $stamp = esc($request_values['stamp']);
    $imprint = esc($request_values['imprint']);
    $post = $request_values['post'];
    $post_type = $request_values['post_type'];
    $receipt = $request_values['receipt'];
    $receipt_type = $request_values['receipt_type'];
    $carrier = esc($request_values['carrier']);
    $in_hands = $request_values['in_hands'];
    $notes_recipient = esc($request_values['notes_recipient']);
    $notes_third = esc($request_values['notes_third']);
    $conservation = $request_values['conservation'];
    $address = esc($request_values['address']);
    $collection = esc($request_values['collection']);
    $ref = esc($request_values['ref']);
    $onomastic = esc($request_values['onomastic']);
    $pseudonyms = esc($request_values['pseudonyms']);
    $mentioned_works = esc($request_values['mentioned_works']);
    $periodics = esc($request_values['periodics']);
    $historic = esc($request_values['historic']);
    $acquisition = $request_values['acquisition'];
    $acq_date = $request_values['acq_date'];
    $add_info = esc($request_values['add_info']);
    $creator = $request_values['creator'];

    $updated_at = $request_values['updated_at'];
    $creator_id = $request_values['creator_id'];
    $sql = "SELECT email from 02_mesicon_users WHERE id = $creator_id";
    $result = mysqli_query($conn, $sql);
	$admin = mysqli_fetch_assoc($result);
    $email_creator = $admin['email'];
        
    if (empty($author)) { array_push($errors, "Autor?/Author?"); } // TODO: if errors = 0 ? // TODO: catch those empty author!!!
    if ($table == 2) $table = "02_mesicon_manuscripts_temp";
    if ($table == 3) $table = "02_mesicon_manuscripts";
    $sql = "UPDATE $table SET author='$author', author_type='$author_type', original='$original', copy='$copy', title='$title', title_type='$title_type', signature='$signature', source_local='$source_local', source_local_type='$source_local_type', recipient='$recipient', recipient_type='$recipient_type', destination='$destination', destination_type='$destination_type', treatment='$treatment', postscript='$postscript', data='$data', data_type='$data_type', idiom='$idiom', gender='$gender', species='$species', type='$type', items='$items', description='$description', contents='$contents', autograph='$autograph', autograph_color='$autograph_color', typewritten='$typewritten', typewritten_color='$typewritten_color', medium='$medium', watermark='$watermark', pages='$pages', leafs='$leafs', width='$width', height='$height', anex='$anex', envelope='$envelope', stamp='$stamp', imprint='$imprint', post='$post', post_type='$post_type', receipt='$receipt', receipt_type='$receipt_type', carrier='$carrier', in_hands='$in_hands', notes_recipient='$notes_recipient', notes_third='$notes_third', conservation='$conservation', address='$address', collection='$collection', ref='$ref', onomastic='$onomastic', pseudonyms='$pseudonyms', mentioned_works='$mentioned_works', periodics='$periodics', historic='$historic', acquisition='$acquisition', acq_date='$acq_date', add_info='$add_info', updated_at='$updated_at', published=";
    if ($table == "02_mesicon_manuscripts") $sql = $sql . "1 WHERE id=$id"; // user is admin, publishes presto!
    else $sql = $sql . "3 WHERE id=$id"; // not admin user, send to revision
    // attach topic to post on post_topic table
    // echo $sql; // debug
    if (mysqli_query($conn, $sql)) {
        if ($table == "02_mesicon_manuscripts") {

            sendMail_postPublished($id, $email_creator, $author, "3");

            $_SESSION['message'] = "Editado, publicado/Edited, published 2";
            header('location: posts_adm.php');
            exit(0);
        } else {
            if ($_SESSION['user']['role'] == "Administrator") {
                $_SESSION['message'] = "Ok! Publique agora/publish now 2";
                header('location: posts_adm.php');
            } else {
                $_SESSION['message'] = "Ok! Aguarde revisão/Wait revision 2";
                header('location: posts.php');
            }
            exit(0);
        }
    }
}

function createBook($request_values) {
    global $conn;
    $errors = [];
    $title = esc($request_values['title']);
    $author = esc($request_values['author']);
    // <it was this way when "org" was a checkbox> $org = isset($request_values['org']) ? 1 : 0; // this is the checkbox verification
    $org = $request_values['org'];
    $ed_number = $request_values['ed_number'];
    $tomos = $request_values['tomos'];
    if (esc($request_values['series']) == "") $series = 0;
    else $series = esc($request_values['series']);
    $num_series = $request_values['num_series'];
    if ($request_values['publisher'] != NULL) $publisher = esc($request_values['publisher']);
    else $publisher = "0";
    if ($request_values['city'] != NULL) $city = esc($request_values['city']);
    else $city = "0";
    $state = $request_values['state'];
    $country = $request_values['country'];
    $month = $request_values['month'];
    $year = $request_values['year'];
    $idiom = $request_values['idiom'];
    if ($request_values['more_idioms'] != NULL) $more_idioms = esc($request_values['more_idioms']);
    else $more_idioms = "0";
    $pages = $request_values['pages'];
    $isbn = $request_values['isbn'];
    $width = $request_values['width'];
    $height = $request_values['height'];
    if ($request_values['front_illustrator'] != NULL) $front_illustrator = esc($request_values['front_illustrator']);
    else $front_illustrator = "0";
    if ($request_values['inside_illustrator'] != NULL) $inside_illustrator = esc($request_values['inside_illustrator']);
    else $inside_illustrator = "0";
    if ($request_values['translator'] != NULL) $translator = esc($request_values['translator']);
    else $translator = "0";
    if ($request_values['preface'] != NULL) $preface = esc($request_values['preface']);
    else $preface = "0";
    $paperback = $request_values['paperback'];
    $digital = $request_values['digital'];
    $exlibris = $request_values['exlibris'];
    $manuscript = $request_values['manuscript'];
    if ($request_values['printed_dedication'] != NULL) $printed_dedication = esc($request_values['printed_dedication']);
    else $printed_dedication = "0";
    if ($request_values['first_ear'] != NULL) $first_ear = esc($request_values['first_ear']);
    else $first_ear = "0";
    if ($request_values['second_ear'] != NULL) $second_ear = esc($request_values['second_ear']);
    else $second_ear = "0";
    if ($request_values['back'] != NULL) $back = esc($request_values['back']);
    else $back = "0";
    if ($request_values['add_info'] != NULL) $add_info = esc($request_values['add_info']);
    else $add_info = "0";
    //if ($request_values['creator'] != NULL) $creator = esc($request_values['creator']);
    //else $creator = "0";
    $creator = $request_values['creator'];
    $creator_id = $request_values['creator_id'];
    $updated_at = $request_values['updated_at'];
    $published = "2"; // sinaliza 2 para revisar
    if (empty($title)) { array_push($errors, "Título do livro é obrigatório"); }
    if (empty($author)) { array_push($errors, "Autor do livro é obrigatório"); }
    if (count($errors) == 0) {
        $sql = "INSERT INTO 02_mesicon_books_temp (title, author, org, ed_number, tomos, series, num_series, publisher, city, state, country, month, year, idiom, more_idioms, pages, isbn, width, height, front_illustrator, inside_illustrator, translator, preface, paperback, digital, exlibris, manuscript, printed_dedication, first_ear, second_ear, back, add_info, creator, creator_id, created_at, updated_at, published) VALUES ('$title', '$author', '$org', '$ed_number', '$tomos', '$series', '$num_series', '$publisher', '$city', '$state', '$country', '$month', '$year', '$idiom', '$more_idioms', '$pages', '$isbn', '$width', '$height', '$front_illustrator', '$inside_illustrator', '$translator', '$preface', '$paperback', '$digital', '$exlibris', '$manuscript', '$printed_dedication', '$first_ear', '$second_ear', '$back', '$add_info', '$creator', '$creator_id', now(), '$updated_at', '$published')";
        if (mysqli_query($conn, $sql)) {
            // TODO: make it work! // $_SESSION['message'] = txt('confira') . " 1"; // 1 flag that color is yellow
            $_SESSION['message'] = "Confira/Review 1"; // 1 flag that color is yellow
            header('location: review_book.php?c=' . $updated_at);
            exit(0);
        } else echo "Error 1: createBook()";
    } else echo "Error 2: createBook()";
}

function createManuscript($request_values) {
    global $conn;
    $errors = [];
    $author = esc($request_values['author']);
    $author_type = $request_values['author_type'];
    $original = $request_values['original'];
    $copy = esc($request_values['copy']);
    $title = esc($request_values['title']);
    $title_type = $request_values['title_type'];
    $signature = esc($request_values['signature']);
    $source_local = esc($request_values['source_local']);
    $source_local_type = $request_values['source_local_type'];
    $recipient = esc($request_values['recipient']);
    $recipient_type = $request_values['recipient_type'];
    $destination = esc($request_values['destination']);
    $destination_type = $request_values['destination_type'];
    $treatment = esc($request_values['treatment']);
    $postscript = esc($request_values['postscript']);
    $data = $request_values['data'];
    $data_type = $request_values['data_type'];
    $idiom = $request_values['idiom'];
    $gender = $request_values['gender'];
    $species = $request_values['species'];
    $type = $request_values['type'];
    $items = $request_values['items'];
    $description = esc($request_values['description']);
    $contents = esc($request_values['contents']);
    $autograph = $request_values['autograph'];
    $autograph_color = esc($request_values['autograph_color']);
    $typewritten = $request_values['typewritten'];
    $typewritten_color = esc($request_values['typewritten_color']);
    $medium = $request_values['medium'];
    $watermark = esc($request_values['watermark']);
    $pages = $request_values['pages'];
    $leafs = $request_values['leafs'];
    $width = $request_values['width'];
    $height = $request_values['height'];
    $anex = esc($request_values['anex']);
    $envelope = esc($request_values['envelope']);
    $stamp = esc($request_values['stamp']);
    $imprint = esc($request_values['imprint']);
    $post = $request_values['post'];
    $post_type = $request_values['post_type'];
    $receipt = $request_values['receipt'];
    $receipt_type = $request_values['receipt_type'];
    $carrier = esc($request_values['carrier']);
    $in_hands = $request_values['in_hands'];
    $notes_recipient = esc($request_values['notes_recipient']);
    $notes_third = esc($request_values['notes_third']);
    $conservation = $request_values['conservation'];
    $address = esc($request_values['address']);
    $collection = esc($request_values['collection']);
    $ref = esc($request_values['ref']);
    $onomastic = esc($request_values['onomastic']);
    $pseudonyms = esc($request_values['pseudonyms']);
    $mentioned_works = esc($request_values['mentioned_works']);
    $periodics = esc($request_values['periodics']);
    $historic = esc($request_values['historic']);
    $acquisition = $request_values['acquisition'];
    $acq_date = $request_values['acq_date'];
    $add_info = esc($request_values['add_info']);
    $updated_at = $request_values['updated_at'];
    $creator = $request_values['creator'];
    $creator_id = $request_values['creator_id'];
    $published = "2"; // flag 2 to review
    if (empty($author)) { array_push($errors, "Author?/Autor do manuscrito é obrigatório"); }
    if (count($errors) == 0) {
        $sql = "INSERT INTO 02_mesicon_manuscripts_temp (author, author_type, original, copy, title, title_type, signature, source_local, source_local_type, recipient, recipient_type, destination, destination_type, treatment, postscript, data, data_type, idiom, gender, species, type, items, description, contents, autograph, autograph_color, typewritten, typewritten_color, medium, watermark, pages, leafs, width, height, anex, envelope, stamp, imprint, post, post_type, receipt, receipt_type, carrier, in_hands, notes_recipient, notes_third, conservation, address, collection, ref, onomastic, pseudonyms, mentioned_works, periodics, historic, acquisition, acq_date, add_info, updated_at, creator, created_at, creator_id, published) VALUES ('$author', '$author_type', '$original', '$copy', '$title', '$title_type', '$signature', '$source_local', '$source_local_type', '$recipient', '$recipient_type', '$destination', '$destination_type', '$treatment', '$postscript', '$data', '$data_type', '$idiom', '$gender', '$species', '$type', '$items', '$description', '$contents', '$autograph', '$autograph_color', '$typewritten', '$typewritten_color', '$medium', '$watermark', '$pages', '$leafs', '$width', '$height', '$anex', '$envelope', '$stamp', '$imprint', '$post', '$post_type', '$receipt', '$receipt_type', '$carrier', '$in_hands', '$notes_recipient', '$notes_third', '$conservation', '$address', '$collection', '$ref', '$onomastic', '$pseudonyms', '$mentioned_works', '$periodics', '$historic', '$acquisition', '$acq_date', '$add_info', '$updated_at', '$creator', now(), '$creator_id', '$published')";
        if (mysqli_query($conn, $sql)) {
            // TODO: do it MOFO! // $_SESSION['message'] = txt('confira') . " 1"; // 1 color yellow
            $_SESSION['message'] = "Confira/Review 1"; // 1 color yellow
            header('location: review_manuscript.php?c=' . $updated_at);
            exit(0);
        } else echo "Error 1: createManuscript()";
    } else echo "Error 2: createManuscript()";
}

function deletePost($post_id, $table, $go2) {
    
    if (($_SESSION['user']['role'] == "Administrator") || ($_SESSION['user']['role'] == "Manager")) {

        global $conn;
        if ($table == 0) $table = "02_mesicon_books_temp";
        if ($table == 1) $table = "02_mesicon_books";
        if ($table == 2) $table = "02_mesicon_manuscripts_temp";
        if ($table == 3) $table = "02_mesicon_manuscripts";
        if ($table == 4) $table = "02_mesicon_comments_temp";
        if ($table == 5) $table = "02_mesicon_users";
        if ($table == 6) $table = "02_mesicon_latest";
        $sql = "DELETE FROM $table WHERE id=$post_id";
        if (mysqli_query($conn, $sql)) {

            if ($table == "02_mesicon_books") { // se livro vinculaldo a manuscrito, desfaz vínculo / if book linked to manuscript, cuts the link
                $sql = "UPDATE 02_mesicon_manuscripts SET link_id=0, link_title=0 WHERE link_id = $post_id";
                if (mysqli_query($conn, $sql)) {
                    echo "OK: deletou de Livros/deleted from Books<br>OK: desvinculou de Manuscritos/unlinked from Manuscripts";
                    $_SESSION['message'] = "Excluído/Excluded 2";
                } else {
                    echo "OK: deletou de Livros/deleted from Books<br>NOT OK: não desvinculou de Manuscritos/not unlinked from Manuscripts";
                    $_SESSION['message'] = "Erro/Error 3";
                }
            }

            if ($table == "02_mesicon_manuscripts") { // se manuscrito vinculaldo a livro, desfaz vínculo / if manuscript linked to book, cuts the link
                $sql = "UPDATE 02_mesicon_books SET link_id=0 WHERE link_id = $post_id";
                if (mysqli_query($conn, $sql)) {
                    echo "OK: deletou de Manuscritos/deleted from Manuscripts<br>OK: desvinculou de Livros/unlinked from Books";
                    $_SESSION['message'] = "Excluído/Excluded 2";
                } else {
                    echo "OK: deletou de Manuscritos/deleted from Manuscripts<br>NOT OK: não desvinculou de Livros/not unlinked from Books";
                    $_SESSION['message'] = "Erro/Error 3";
                }
            }

        }
    
    } else echo txt('proibido') . ".";

}

function editBook($role_id) {
    global $conn;
    $sql = "SELECT * FROM 02_mesicon_books_temp WHERE id=$role_id LIMIT 1";
    $result = mysqli_query($conn, $sql);
    $post = mysqli_fetch_assoc($result);
    // set form values on the form to be updated
    $title = esc($post['title']);
    $author = esc($post['author']);
    $org = $post['org'];
    $ed_number = $post['ed_number'];
    $tomos = $post['tomos'];
    $series = esc($post['series']);
    $num_series = $post['num_series'];
    $publisher = esc($post['publisher']);
    $city = esc($post['city']);
    $state = esc($post['state']);
    $country = esc($post['country']);
    $month = $post['month'];
    $year = $post['year'];
    $idiom = esc($post['idiom']);
    $more_idioms = esc($post['more_idioms']);
    $pages = $post['pages'];
    $isbn = $post['isbn'];
    $width = $post['width'];
    $height = $post['height'];
    $front_illustrator = esc($post['front_illustrator']);
    $inside_illustrator = esc($post['inside_illustrator']);
    $translator = esc($post['translator']);
    $preface = esc($post['preface']);
    $paperback = $post['paperback'];
    $digital = $post['digital'];
    $exlibris = $post['exlibris'];
    $manuscript = $post['manuscript'];
    $printed_dedication = esc($post['printed_dedication']);
    $first_ear = esc($post['first_ear']);
    $second_ear = esc($post['second_ear']);
    $back = esc($post['back']);
    $add_info = esc($post['add_info']);
    $creator = esc($post['creator']);
    $created_at = $post['created_at'];
    $updated_at = $post['updated_at'];
    header('location: edit_book.php?i=' . $role_id . "&t=0"); 
    exit(0);
}

function editManuscript($role_id) {
    global $conn;
    $sql = "SELECT * FROM 02_mesicon_manuscripts_temp WHERE id=$role_id LIMIT 1";
    $result = mysqli_query($conn, $sql);
    $io = mysqli_fetch_assoc($result);
    //echo $sql; // debug
    $author = esc($io['author']);
    $author_type = $io['author_type'];
    $original = $io['original'];
    $copy = esc($io['copy']);
    $title = esc($io['title']);
    $title_type = $io['title_type'];
    $signature = esc($io['signature']);
    $source_local = esc($io['source_local']);
    $source_local_type = $io['source_local_type'];
    $recipient = esc($io['recipient']);
    $recipient_type = $io['recipient_type'];
    $destination = esc($io['destination']);
    $destination_type = $io['destination_type'];
    $treatment = esc($io['treatment']);
    $postscript = esc($io['postscript']);
    $data = $io['data'];
    $data_type = $io['data_type'];
    $idiom = esc($io['idiom']);
    $gender = $io['gender'];
    $species = $io['species'];
    $type = esc($io['type']);
    $items = $io['items'];
    $description = esc($io['description']);
    $contents = esc($io['contents']);
    $autograph = $io['autograph'];
    $autograph_color = esc($io['autograph_color']);
    $typewritten = $io['typewritten'];
    $typewritten_color = esc($io['typewritten_color']);
    $medium = $io['medium'];
    $watermark = esc($io['watermark']);
    $pages = $io['pages'];
    $leafs = $io['leafs'];
    $width = $io['width'];
    $height = $io['height'];
    $anex = esc($io['anex']);
    $envelope = esc($io['envelope']);
    $stamp = esc($io['stamp']);
    $imprint = esc($io['imprint']);
    $post = $io['post'];
    $post_type = $io['post_type'];
    $receipt = $io['receipt'];
    $receipt_type = $io['receipt_type'];
    $carrier = esc($io['carrier']);
    $in_hands = $io['in_hands'];
    $notes_recipient = esc($io['notes_recipient']);
    $notes_third = esc($io['notes_third']);
    $conservation = $io['conservation'];
    $address = esc($io['address']);
    $collection = esc($io['collection']);
    $ref = esc($io['ref']);
    $onomastic = esc($io['onomastic']);
    $pseudonyms = esc($io['pseudonyms']);
    $mentioned_works = esc($io['mentioned_works']);
    $periodics = esc($io['periodics']);
    $historic = esc($io['historic']);
    $acquisition = $io['acquisition'];
    $acq_date = $io['acq_date'];
    $add_info = esc($io['add_info']);
    $creator = esc($io['creator']);
    $created_at = $io['created_at'];
    $updated_at = $io['updated_at'];
    header('location: edit_manuscript.php?i=' . $role_id . "&t=2"); // 2 = manuscripts_temp; 3 = manuscripts
    exit(0);
}

function encodeURI($url) { // not yet used but it can be usefull // source: https://stackoverflow.com/questions/34249842/how-to-encode-only-queryparams-in-a-url-string
// https://php.net/manual/en/function.rawurlencode.php
// https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/encodeURI
/* 
$unescaped = array(
    '%2D'=>'-','%5F'=>'_','%2E'=>'.','%21'=>'!', '%7E'=>'~',
    '%2A'=>'*', '%27'=>"'", '%28'=>'(', '%29'=>')'
);
$reserved = array(
    '%3B'=>';','%2C'=>',','%2F'=>'/','%3F'=>'?','%3A'=>':',
    '%40'=>'@','%26'=>'&','%3D'=>'=','%2B'=>'+','%24'=>'$'
);
$score = array(
    '%23'=>'#'
);
return strtr(rawurlencode($url), array_merge($reserved,$unescaped,$score));
*/
}

function esc(String $value) { // php v. 7
    // function esc($value) // php v. 5
	global $conn;
    // if (strpos($val, "'") >= 0 || strpos($val, '"') >= 0 || strpos($val, '´') >= 0 || strpos($val, '`') >= 0) {
    // array_push($errors, "Não uses aspas nem simples nem duplas.");
    // echo $errors . " - Não uses aspas nem simples nem duplas.";
    // return false; // if found
	$val = trim($value); // remove empty space sorrounding string
	$val = str_replace('"','',$val); // del "
    $val = str_replace("'","",$val); // del '
    $val = str_replace("´","",$val); // del ´
    $val = str_replace("`","",$val); // del `
    $val = str_replace("<","-",$val);
    $val = str_replace(">","-",$val);
    $val = str_replace("\r","\ r",$val);
    $val = str_replace("\n","\ n",$val);
    $val = str_replace("http","",$val);
    $val = str_replace("https","",$val);
    $val = str_replace("javascript","",$val);
    $val = str_replace("href","",$val);
    $val = str_replace("onclick","",$val);
    $val = str_replace("onkeyup","",$val);
    $val = str_replace("onkeydown","",$val);
    $val = str_replace("onfocus","",$val);
    $val = str_replace("onlostfocus","",$val);
    $val = str_replace("onload","",$val);
	$val = mysqli_real_escape_string($conn, $val);
	return $val;
} // escapes values submitted from form, hence, preventing SQL injection // there is a copy of this function in "incl_registration_login.php", when this one changes, chnage there also MOFOOOOOOOOOO

function getAllBAM(string $table, string $order, string $asc_or_desc) { // used by posts.php, posts_adm.php and link_books.php
	global $conn;
    $contador = 1;
    $user_id = $_SESSION['user']['id'];
    $data = array();
    if ($table == "0") $table = array('02_mesicon_latest');
    if ($table == "1") $table = array('02_mesicon_books_temp', '02_mesicon_books', '02_mesicon_manuscripts_temp', '02_mesicon_manuscripts');
    if ($table == "2") $table = array('02_mesicon_books','02_mesicon_manuscripts');
    foreach ($table as $tbl) {
        $sql = "SELECT * FROM `{$tbl}` ORDER BY $order $asc_or_desc";
        // abre meu
        //if ($_SESSION['user']['role'] == "Manager") {
            //$sql = $sql . " WHERE creator_id = $user_id";
        //}
        //$sql = $sql . " ORDER BY $order" . " " . $asc_or_desc;
        // fecha meu
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $data[$tbl][] = $row;
            }
        }
    }
    return $data;
}

function getAllBooksFromUser($user_id, $order, $asc_or_desc) {
    global $conn;
    $num_registros = 0;
    $sql = "SELECT id, title, author, created_at, creator, creator_id FROM 02_mesicon_books WHERE creator_id=$user_id ORDER BY " . $order . " " . $asc_or_desc;
    $result = mysqli_query($conn, $sql);
	if ($result === FALSE) {
		echo "Error at incl_functions - getAllBooksFromUser().";
		die(); // TODO: better error handling
	} else {
		$posts = array();
		while ($row = $result->fetch_assoc()) {
            $posts[] = $row;
            $num_registros++;
		}
	}
    echo txt('publicacoes');
    if ($num_registros > 0) echo "<br><h2>" . txt('publicacoes') . " " . txt('de') . " <a href='user.php?id=" . $posts[0]['creator_id'] . "&v=p'>" . $posts[0]['creator'] . "</a></h2><br>";
    else echo ": " . txt('nenhuma') . ".<br>";
    echo "<p align=left>";
    for ($contador = 0; $contador < $num_registros; $contador++) {
        echo "<img src='static/spacer.gif' width='5%' height='1px'>" . $contador+1 . ". <a href='post.php?id=" . $posts[$contador]['id'] . "&t=1'>" . $posts[$contador]['author'] . ". <i>" . $posts[$contador]['title'] . ".</i> (" . $posts[$contador]['created_at'] . ")</a><br><br>";
	}
    echo "</p>";
    echo "<br>--------------------<br>";
    echo "<a href=https://statos.com" . $_SERVER['REQUEST_URI'] . ">https://statos.com" . $_SERVER['REQUEST_URI'] . "</a><br>(<font size='-1'>" . date('F j, Y, g:i a') . "</font>)<br>";
	echo "Manuscritos e Edições SIstema de CONtrole<br>";
    echo date('Y') . " &copy; MESICON<br></font>";
}

function getBAMfromUser($user_id, $order, $asc_or_desc) { // BAM = books and manuscripts; used by user.php
    global $conn;
    $num_registros = 0;
    $sql = "SELECT * FROM 02_mesicon_books WHERE creator_id=$user_id ORDER BY " . $order . " " . $asc_or_desc;
    if (mysqli_query($conn, $sql)) {
		$result = mysqli_query($conn, $sql);
		if ($result === FALSE) {
			echo "Error at incl_functions - getBAMfromUser().";
			die(); // TODO: better error handling
		} else {
			$posts = array();
			while ($row = $result->fetch_assoc()) {
				$posts[] = $row;
				$num_registros++;
			}
		}
		echo "<br><p align=left><img src='static/spacer.gif' width='5%' height='1px'>";
		if ($num_registros > 0) echo txt('publicacoesrecentes') . ":<br><br>";
		else echo txt('publicacoes') . ": " . txt('nenhuma') . "."; // info displayed in user profile
		for ($contador = 0; $contador < $num_registros; $contador++) {
			echo "<img src='static/spacer.gif' width='5%' height='1px'>" . $contador + 1 . ". <a href='post.php?t=1&id=" . $posts[$contador]['id'] . "'>" . $posts[$contador]['author'] . ". <i>" . $posts[$contador]['title'] . ".</i> (" . $posts[$contador]['created_at'] . ")</a><br><br>";
			if ($contador >= 2) {
				echo "<img src='static/spacer.gif' width='5%' height='1px'><a href='posts_user.php?id=" . $user_id . "'>&gt;&gt; see all/ver todas &gt;&gt;</a><br>";
				$contador = 9999;
				break;
			}
		}
		echo "</p>";
	} else {
		// user not found, do nothing here, only avoid errors (matter will be dealed in the next steps
	}
}

function getBAM($post_id, $table) {
	global $conn; // use global $conn object in function
    if ($table == 0) $table = "02_mesicon_books_temp";
    if ($table == 1) $table = "02_mesicon_books";
    if ($table == 2) $table = "02_mesicon_manuscripts_temp";
    if ($table == 3) $table = "02_mesicon_manuscripts";
	$sql = "SELECT * FROM " . $table . " WHERE id = $post_id";
    // echo $sql; // debug
	$result = mysqli_query($conn, $sql);
	if ($result === FALSE) {
		echo "Error at incl_functions - getBAM().";
		die(); // TODO: better error handling
	} else {
		$posts = array();
		while ($row = $result->fetch_assoc()) {
		  $posts[] = $row;
		}
	}
	$final_posts = array();
	foreach ($posts as $post) {
		array_push($final_posts, $post);
	}
	return $final_posts;
}

function getBook2Review($criadoem) {
	global $conn; // use global $conn object in function
	$sql = "SELECT * FROM 02_mesicon_books_temp WHERE updated_at = '$criadoem'";
	$result = mysqli_query($conn, $sql);
	if ($result === FALSE) {
		echo "Error at incl_functions - getBook2Review().";
		die(); // TODO: better error handling
	} else {
		$posts = array();
		while ($row = $result->fetch_assoc()) {
		  $posts[] = $row;
		}
	}
	$final_posts = array();
	foreach ($posts as $post) {
		array_push($final_posts, $post);
	}
	return $final_posts;
}

function getComments($creator_id, $status) {
	global $conn;
    if ($creator_id == "todos") {
        if ($status == "todos") $sql = "SELECT * FROM 02_mesicon_comments_temp WHERE status = 1 OR status = 2 ORDER BY created_at DESC";
        else if ($status = "index") $sql = "SELECT * FROM 02_mesicon_comments ORDER BY created_at DESC";
        else $sql = "SELECT * FROM 02_mesicon_comments_temp WHERE status = $status ORDER BY created_at DESC";
    } else $sql = "SELECT * FROM 02_mesicon_comments_temp WHERE creator_id = $creator_id AND status = 1 ORDER BY created_at";
    $result = mysqli_query($conn, $sql);
	$comments = array();
    while ($row = $result->fetch_assoc()) {
        //echo "--> " . $row; // debug
        $comments[] = $row;
    }
    return $comments;
    // echo $sql . " " . $comments['0'] . "<br>"; // debug
}

function getHistory($user_id) { // user.php
	global $conn;
	$sql = "SELECT history, username FROM 02_mesicon_users WHERE id=$user_id LIMIT 1";
	$result = mysqli_query($conn, $sql);
	$io = mysqli_fetch_assoc($result);
    echo "<h2>" . $io['username'] . "</h2>"; 
    if ($io['history'] != 0) echo "<p style='text-align: justify; font-size: 8px;'><br>" . $io['history'] . "</p>";
    else echo "<br><h3>" . txt('historicovazio') . ".</h3>";
}

function getLastWord($estringue) {
    $pieces = preg_split('/\s+/', $estringue); // regular expression to create array from white spaces split words
    //print_r($pieces);
    $lastword = array_pop($pieces);
    return $lastword;
} // there is a copy of this in "login.php", if change here - change there also youthful !

function getLatestBAM() { // index.php
	global $conn; // use global $conn object in function
	$sql = "SELECT tabela, original_id, title, author, ed_number, manuscript, creator, created_at FROM 02_mesicon_latest ORDER BY created_at DESC";
	$result = mysqli_query($conn, $sql);
	if ($result === FALSE) {
		echo "Error getLatestBAM().";
		die(); // TODO: better error handling
	} else {
		$posts = array();
		while ($row = $result->fetch_assoc()) {
		  $posts[] = $row;
		}
	}
	$final_posts = array();
	foreach ($posts as $post) {
		array_push($final_posts, $post);
	}
	return $final_posts;
}

function getLatestUsers() {
	global $conn; // use global $conn object in function
	//ql = "SELECT * FROM 02_mesicon_users WHERE status = 'Authorized'";
	$sql = "SELECT id, username, created_at FROM 02_mesicon_users ORDER BY created_at DESC"; // TODO: above line: only authorized
	$result = mysqli_query($conn, $sql);
	if ($result === FALSE) {
		echo "Error at incl_functions - getLatestUsers().";
		die(); // TODO: better error handling
	} else {
		$users = array();
		while ($row = $result->fetch_assoc()) {
		  $users[] = $row;
		}
	}
	$final_users = array();
	foreach ($users as $user) {
		array_push($final_users, $user);
	}
	return $final_users;
}

function getManuscript2Review($criadoem) {
	global $conn; // use global $conn object in function
	$sql = "SELECT * FROM 02_mesicon_manuscripts_temp WHERE updated_at = '$criadoem'";
    $result = mysqli_query($conn, $sql);
    //echo $sql; // debug
	if ($result === FALSE) {
		echo "Error at incl_functions - getManuscript2Review().";
		die(); // TODO: better error handling
	} else {
		$posts = array();
		while ($row = $result->fetch_assoc()) {
		  $posts[] = $row;
		}
	}
	$final_posts = array();
	foreach ($posts as $post) {
		array_push($final_posts, $post);
	}
	return $final_posts;
}

function getMonth($month) {
    if ($month == 1) return "Jan/Janeiro";
    if ($month == 2) return "Feb/Fevereiro";
    if ($month == 3) return "Mar/Março";
    if ($month == 4) return "Apr/Abril";
    if ($month == 5) return "May/Maio";
    if ($month == 6) return "Jun/Junho";
    if ($month == 7) return "Jul/Julho";
    if ($month == 8) return "Aug/Agosto";
    if ($month == 9) return "Sep/Setembro";
    if ($month == 10) return "Oct/Outubro";
    if ($month == 11) return "Nov/Novembro";
    if ($month == 12) return "Dec/Dezembro";
}

function getUser($id) { // user.php
    global $conn;
    $sql = "SELECT * FROM 02_mesicon_users WHERE id=$id LIMIT 1";
	
	if (mysqli_query($conn, $sql)) { // only runs if user exists

		$result = mysqli_query($conn, $sql);
		$admin = mysqli_fetch_assoc($result);

		//$_SESSION['user']['username'] = $admin['username'];

		if (($_SESSION['user']['id'] == $id) && ($_SESSION['user']['role'] == "Manager") || ($_SESSION['user']['role'] == "Administrator")) { // who is accessing is the profile owner or ADM

			echo "<h1>" . txt('perfil') . "</h1><h3><a href='control_panel.php'>&lt;&lt; " . txt('voltar') . " " . txt('paineldecontrole') . "</a></h3>";
			
			if ($admin['id'] != "") { // only runs if logged

				echo "<br><form method='post' name='statosdotcomForm' action='user.php?v=p&updated=0' onsubmit='return i(this);'>";

				echo "ID: " . $admin['id'] . "<input type=hidden name=admin_id value=" . $admin['id'] . "><br><br>";

				echo txt('nomedeusuario_M') . ":<br>";
				?>
				<div id='lusername' class='ct'></div>
				<input onkeyup="statosdotcom_Count(this,8);" type=text id=username name=username value="<?= $admin['username'] ?>" placeholder="<?= txt('nome') ?>" maxlength="8" onkeyup="this.value=this.value.replace(/[\d]/g, '');" onchange="this.value=this.value.replace(/[\d]/g, '');"> <!-- regex forbid numbers -->
				<?php
				//echo "EMAIL <input type=text name=email value=" . $admin['email'] . ">";
				echo "<br>BIO:<br><div id='lbio' class='ct'></div><textarea onkeyup='statosdotcom_Count(this,255);' style='resize:none' rows=5 name=bio id=bio placeholder='" . txt('bioplaceholder') . "' maxlength=255>" . $admin['bio'] . "</textarea><br>";

				// mt_rand(min,max), função php na liha abaixo, é 4 vezes mais rápida que a default "rand()". Ambas geram 10 caracteres e em "mt" se max < min dá pau
				// echo "<a href='user.php?id=" . $admin['id'] . "&v=h&rnd=" . mt_rand(0000000000,9999999999) . "&updated=0'>HISTÓRICO</a><br><br>";
				echo "<a href='user.php?id=" . $admin['id'] . "&v=h'>" . txt('historico_M') . "</a><br><br>";

				echo txt('grupo_M') . ": " . $admin['role'] . "<input type=hidden name=role value='" . $admin['role'] . "'><br>";
				if ($_SESSION['user']['role'] == "Administrator") {
					?>
					<select name="role">
						<?php
						if ($admin['role'] == "") echo '<option value=0 selected>Grupo?</option>';
						else echo "<option selected value=" . $admin['role'] . ">" . $admin['role'] . "</option>";
						?>
						<option value=''><?= txt('grupo') ?>?</option>
						<option value='Manager'>Manager</option>
						<option value='User'>User</option>
						?>
					</select><br>
					<?php
				}

				echo "<br>STATUS: " . $admin['status'] . "<input type=hidden name=status value='" . $admin['status'] . "'><br>";
				if ($_SESSION['user']['role'] == "Administrator") {
					?>
					<select name="status">
						<?php
						if ($admin['status'] == "") echo '<option value=0 selected>Status?</option>';
						else echo "<option selected value=" . $admin['status'] . ">" . $admin['status'] . "</option>";
						?>
						<option value=''>Status?</option>
						<option value='Authorized'>Authorized</option>
						<option value='Waiting'>Waiting</option>
						<option value='Suspended'>Suspended</option>
						?>
					</select><br>
					<?php
				}

				echo "<br>EMAIL: " . $admin['email'] . "<br>";
				if ($_SESSION['user']['role'] == "Administrator") echo "<input type=text name=email value=" . $admin['email'] . "><br>";
				else echo "<input type=hidden name=email value=" . $admin['email'] . "><br>";
				//echo "SENHA: " . $admin['password'] . "<br><br>";
				echo txt('senha_M') . ": ********<br><br>";
				echo "<font class=''>" . txt('paraalterar1') . " <a href='login.php'>" . txt('aqui_M') . "</a><br>" . txt('paraalterar2') . ".</font><br><br>";

				echo "<table width='100%'><tr align=center><td>" . txt('criado_M') . "<br>" . $admin['created_at'] . "<br><br></td>";
				echo "<td>" . txt('atualizado_M') . "<br>" . $admin['updated_at'] . "<br><br></td>";
				echo "</tr></table>";
				//echo "<button type=submit class=btn name=update-btn>ATUALIZAR</button>";
				echo "<button type=submit class=btn name=update_user id=id_update_user>" . txt('atualizar_M') . "</button>";
				echo "</form>";

			} else {
				header("location: logout.php?p=index");
				exit(0);
			}

		} else { // who is accessing is not the profile owner NOR adm
			echo "<h1>" . txt('perfil') . "</h1><br><br><h3>";
			echo txt('usuario_M') . ":<br>" . $admin['username'] . "<br><br>";
			echo "PERSONAL URL:<BR><a href=https://statos.com/mesicon?" . $admin['username'] . ">https://statos.com/mesicon?" . $admin['username'] . "</a><br><br>";
			if ($admin['bio'] != "") echo "BIO:<br>" . $admin['bio'] . "<br><br>";
			echo txt('grupo_M') . ":<br>" . $admin['role'] . "<br><br>";
			echo "STATUS:<br>" . $admin['status'] . "<br><br>";
			echo "<font class=statos_fonte_cinza>" . txt('registro_M') . ": " . $admin['created_at'] . "<br>";
			echo txt('atualizado_M') . ": " . $admin['updated_at'] . "</font><br><br>";
			echo "<a href='user.php?id=" . $admin['id'] . "&v=h'>" . txt('historico_M') . "</a><br></h3>";
		} 
	
	} else {
		// user not found - do nothing here, only avoids to show error. finduser.php will deal with the rest of matter
	}
}

function getUserBio($user_id) {
	global $conn;
	$sql = "SELECT * FROM 02_mesicon_users WHERE id=$user_id LIMIT 1";
	$result = mysqli_query($conn, $sql);
	$admin = mysqli_fetch_assoc($result);
	echo "<br><b>" . txt('responsavelpeloregistro') . ":</b><br>";
	echo "<a href='user.php?id=" . $user_id . "&v=p'>&nbsp;";
	//echo utf8_encode($admin['username']);
	echo $admin['username'];
	if ($admin['bio'] != "") echo "<br>" . trim($admin['bio']);
	echo "&nbsp;</a><br>";
}

function getUsers() {
	global $conn, $roles;
	//$sql = "SELECT * FROM 02_mesicon_users WHERE role IS NOT NULL ORDER BY created_at DESC";
	$sql = "SELECT * FROM 02_mesicon_users ORDER BY id DESC";
	$result = mysqli_query($conn, $sql);
	//$users = mysqli_fetch_all($result, MYSQLI_ASSOC); // original code - 5 below lines are from Aug. 2021
	$users = array();
	//$result = $conn->query($sql);
	while ($row = $result->fetch_assoc()) {
	  $users[] = $row;
	}
	return $users;
}

function godApproveComments($id) {
	global $conn;
    $err = 0;
    
    // 1. recover data from table comments
        $sql = "SELECT * FROM 02_mesicon_comments_temp WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            $out = mysqli_query($conn, $sql);
            $my = mysqli_fetch_assoc($out);
            $username_commenter = $my['username_commenter'];
            $id_commenter = $my['id_commenter'];
            $creator_id = $my['creator_id'];
            $id_post = $my['id_post'];
            $tabela = $my['tabela'];
            $num_tabela = $my['tabela']; // will be used only in sendmail time
            if ($tabela == 1) $tabela = "02_mesicon_books";
            $txt = $my['txt'];
            $created_at = $my['created_at'];
            $err++;
        } else echo "Erro 1 GAComments";
    
    // 1.1. get email of the post's owner
        if ($err == 1) {
        $sql = "SELECT email FROM 02_mesicon_users WHERE id = $creator_id";
        if (mysqli_query($conn, $sql)) {
            $out = mysqli_query($conn, $sql);
            $my = mysqli_fetch_assoc($out);
            $email_creator = $my['email'];
            $err++;
        } else echo "Erro 2 GAComments";
        }
    
    // 1.2. get commentator's email
        if ($err == 2) {
        $sql = "SELECT email FROM 02_mesicon_users WHERE id = $id_commenter";
        if (mysqli_query($conn, $sql)) {
            $out = mysqli_query($conn, $sql);
            $my = mysqli_fetch_assoc($out);
            $email_commenter = $my['email'];
            $err++;
        } else echo "Erro 3 GAComments";
        }
    
    // 2. creates string to be inserted in field "comments" of the correspondent post on the final table (can be books or manuscripts, for a while)
        if ($err == 3) {
            //$new_comments = "nadanao";
            $new_comments = "<a href=user.php?id=" . $id_commenter . "&v=p>" . $username_commenter . "</a> (" . $created_at . "): " . $txt . "<br><br>";
            $err++;
        }
    
    // 3. read field "comments" on the final table (books or manuscritos, for a while)
        if ($err == 4) {
        $sql = "SELECT comments FROM $tabela WHERE id = $id_post";
        if (mysqli_query($conn, $sql)) {
            $out = mysqli_query($conn, $sql);
            $my = mysqli_fetch_assoc($out);
            $old_comments = $my['comments'];
            if ($old_comments != "") $new_comments = $new_comments . $old_comments;
            $err++;
        } else echo "Erro 4 GAComments";
        }
    
    // 4. update the official table adding "new_comment" in the begining of the comments session
        if ($err == 5) {
        $sql = "UPDATE $tabela SET comments='" . $new_comments . "' WHERE id=$id_post";
        if (mysqli_query($conn, $sql)) {
            // do something here;
            $err++;
        } else echo " Erro 5 GAComments";
        }

    // 5. confirms comment publication by email to the post owner and also to the commenter
        if ($err == 6) {
        $emailsender = "apps@statos.com";
        $emailSubject = "(OK COMENTÁRIO/COMMENT) MESICON";
        $msg = "Esta é uma mensagem automática, por favor não a responda.\nThis is an automatic message, please do not respond to it.";
        $msg .= "\n\n----------\n";
        $msg .= "Comentário aprovado em:\nApproved comment in:\n\n";
        $msg .= "https://statos.com/mesicon/post.php?id=$id_post&t=$num_tabela";
            $msg .= "\n----------\n\n";
            $msg .= "Manuscritos e Edições SIstema de CONtrole - MESICON\n";
            $msg .= "statos.com/mesicon\n\n";
            $msg .= "Se você considera esta mensagem um erro, delete-a sem problemas.\nIf you consider this message an error, please delete it.\n\n\n\n";
        $headers = "MIME-Version: 1.1\n";
        $headers .= "Content-type: text/plain; charset=UTF-8\n";
        $headers .= "X-Priority: 1\n"; // send with max priority
        $headers .= "From: " . $emailsender . "\n"; // sender
        $headers .= "Return-Path: " . $emailsender . "\n"; // return-path
        // post owner
        if(!mail($email_creator, $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Postfix
            // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // not Postfix
            mail($email_creator, $emailSubject, $msg, $headers );
            // sent
        } else { } // error - TODO: error message!
        // comentator
        if(!mail($email_commenter, $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Postfix
            // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // not Postfix
            mail($email_commenter, $emailSubject, $msg, $headers );
            // foi
        } else { } // error - TODO: error message!

        $sql = "UPDATE 02_mesicon_users SET history = CONCAT(';c " . date('Y-m-d H:i') . "',02_mesicon_users.history) WHERE id = $id_commenter"; // update history
        mysqli_query($conn, $sql);
        $err++;
        }

    //5.1. forbid that "comments" table have more than 25 records, the older get deleted
        if ($err == 7) {

        $sql = "SELECT COUNT(*) as total FROM 02_mesicon_comments";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        $limit = $row['total'] - 24;
        $sql = "DELETE FROM 02_mesicon_comments ORDER BY id DESC LIMIT $limit";
        if ($conn->query($sql) === TRUE) echo "Tabela comments sanitizada"; // delete ever record but the 24 newer
        else echo "Tabela comments não requereu sanitização"; // nothing deleted BC there is less than 24 records
        $err++;
        }
    
    //6. copy "temp_comments" contents to "comments" so the home page info gets updated
        if ($err == 8) {
        $sql = "INSERT INTO 02_mesicon_comments SELECT * FROM 02_mesicon_comments_temp WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            // do something here;
            $err++;
        } else echo " Erro 6 GAComments";
        }
    
    //7. delete comment from the table "comments" - have to be the last step to run because the below function directs to another page
        if ($err == 9) {
            deletePost($id, "02_mesicon_comments_temp", "comments");
        }
}

function insertUserComment($username_commenter, $id_commenter, $creator_id, $id_post, $tabela, $txt, $status) {
    global $conn;
    $errors = [];
    if (empty($username_commenter)) { array_push($errors, "Erro: insertUserComment(): username_commenter?"); }
    if (empty($id_commenter)) { array_push($errors, "Erro: insertUserComment(): id_commenter?"); }
    if (empty($id_post)) { array_push($errors, "Erro: insertUserComment(): id_post?"); }
    if (empty($creator_id)) { array_push($errors, "Erro: insertUserComment(): creator_id?"); }
    if (empty($tabela)) { array_push($errors, "Erro: insertUserComment(): table?"); }
    if (empty($txt)) { array_push($errors, "Erro: insertUserComment(): txt?"); }
    if (empty($status)) { array_push($errors, "Erro: insertUserComment(): status?"); }

        $sql = "SELECT email from 02_mesicon_users WHERE id = $creator_id";
        $result = mysqli_query($conn, $sql);
        $io = mysqli_fetch_assoc($result);
        $emailfromcreator = $io['email'];

    if (count($errors) == 0) {
        $mynow = date('Y-m-d H:i:s');
        $sql = "INSERT INTO 02_mesicon_comments_temp (username_commenter, id_commenter, creator_id, id_post, tabela, status, txt, created_at) VALUES ('$username_commenter', '$id_commenter', '$creator_id', '$id_post', '$tabela', '$status', '$txt', '$mynow')";
        if (mysqli_query($conn, $sql)) {
            $emailsender = "apps@statos.com";
            $emailSubject = "(NOVO/NEW) MESICON";
            $msg = "Esta é uma mensagem automática, por favor não a responda.\nThis is an automatic message, please do not respond to it.\n\n";
            $msg .= "----------\n";
            $msg .= "'$username_commenter' comentou/commented.\n\n";
            $msg .= "Aprove ou rejeite:\nApprove or reject:\n\n";
            $msg .= "https://statos.com/mesicon/review_comment.php?c=" . substr($mynow,11,19);
            $msg .= "\n----------\n\n";
            $msg .= "Manuscritos e Edições SIstema de CONtrole - MESICON\n";
            $msg .= "statos.com/mesicon\n\n";
            $msg .= "Se você considera esta mensagem um erro, delete-a sem problemas.\nIf you consider this message an error, please delete it.\n\n\n\n";
            $headers = "MIME-Version: 1.1\n";
            $headers .= "Content-type: text/plain; charset=UTF-8\n";
            $headers .= "X-Priority: 1\n"; // send with max priority
            $headers .= "From: " . $emailsender . "\n"; // sendetr
            $headers .= "Return-Path: " . $emailsender . "\n"; // return-path
            if (!mail($emailfromcreator, $emailSubject, $msg, $headers ,"-r".$emailsender)) { // Postfix
                // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // not Postfix
                mail($emailfromcreator, $emailSubject, $msg, $headers);
                // sent
            } else {
                // echo "Error insertUserComment() 1."; // TODO: why email goes even in "else"???????
            }
        } else {
            $_SESSION['message'] = "Ref. 2 error: Comments 3";
            echo "Erro insertUserComment() 2.";
        }
        $_SESSION['message'] = "Comentário enviado/Comment sent 2";
        header("location: index.php");
        exit(0);
    } else {
        $_SESSION['message'] = "Ref. 3 error: Comments 3";
        echo "Erro insertUserComment() 3.";
    }
}

function linkBook($id_book, $id_manuscript, $link_title) {
    if ($_SESSION['user']['role'] == "Administrator" || $_SESSION['user']['role'] == "Manager") {
        global $conn;
        $errors = [];
        if (empty($id_book) || empty($id_manuscript)) { array_push($errors, "linkBook() error"); }
        if (count($errors) == 0) {
            $sql = "UPDATE 02_mesicon_books SET link_id='$id_manuscript' WHERE id=$id_book";
            mysqli_query($conn, $sql);
            $sql = "UPDATE 02_mesicon_manuscripts SET link_id='$id_book', link_title='$link_title' WHERE id=$id_manuscript";
            mysqli_query($conn, $sql);
            $sql = "UPDATE 02_mesicon_users SET history = CONCAT(';l " . date('Y-m-d H:i') . "',02_mesicon_users.history) WHERE id = $id_book"; // atualiza historico
            mysqli_query($conn, $sql);
            $_SESSION['message'] = "Vinculado com sucesso 2"; // debug only, the confirmation msg is given by "updated=1", who is will be built in "user.php"
            header('location: control_panel.php');
            exit(0);
        }
    } else {
        header('location: logout.php?p=index');
        exit(0);
    }
}

function myUrlEncode($string) {
    // source: comment from davis.peixoto@gmail.com in https://www.php.net/manual/en/function.urlencode.php
    $entities = array('%21', '%2A', '%27', '%28', '%29', '%3B', '%3A', '%40', '%26', '%3D', '%2B', '%24', '%2C', '%2F', '%3F', '%25', '%23', '%5B', '%5D');
    $replacements = array('!', '*', "'", "(", ")", ";", ":", "@", "&", "=", "+", "$", ",", "/", "?", "%", "#", "[", "]");
    return str_replace($entities, $replacements, urlencode($string));
}

function publishPost($post_id, $creator_id, $table, $author) {
    if ($_SESSION['user']['role'] == "Administrator") {
        global $conn;
        $ok = 1;
        $new_record = 0;
        // copy row from one table to another:
        // INSERT INTO final_table
        // SELECT * FROM original_table WHERE id = 1
        // If tables have different column number, other layout etc., you have to specify columns:
        // INSERT INTO final_table(field1, field2, field3) SELECT field7, field8, field9 FROM original_table WHERE id = 1    

        if ($table == 0 || $table == 1) {
            $tabletemp = "02_mesicon_books_temp";
            $tableofficial = "02_mesicon_books";
            $str_historic = "cb"; // create book
        }
        if ($table == 2 || $table == 3) {
            $tabletemp = "02_mesicon_manuscripts_temp";
            $tableofficial = "02_mesicon_manuscripts";
            $str_historic = "cm"; // create manuscript
        }

        if ($table == 0 || $table == 2) { // (0 = books; 2 = manuscripts) record comes from one of the "temp" tables, so user is creating a new post

            
            if ($ok == 1) {
                // below: select * from temp except "id" (to avoid overwrite of "id" in final/official table)
                if ($table == 0) { // books
                    $sql = "INSERT INTO " . $tableofficial;
                    $sql = $sql . " (link_id, title, author, org, ed_number, tomos, series, num_series, publisher, city, state, country, month, year, idiom, more_idioms, pages, isbn, width, height, front_illustrator, inside_illustrator, translator, preface, paperback, digital, exlibris, manuscript, printed_dedication, first_ear, second_ear, back, add_info, comments, creator, creator_id, created_at, updated_at, pageviews, published)";
                    $sql = $sql . " SELECT";
                    $sql = $sql . " $post_id, title, author, org, ed_number, tomos, series, num_series, publisher, city, state, country, month, year, idiom, more_idioms, pages, isbn, width, height, front_illustrator, inside_illustrator, translator, preface, paperback, digital, exlibris, manuscript, printed_dedication, first_ear, second_ear, back, add_info, comments, creator, creator_id, created_at, now(), pageviews, 1";
                    $sql = $sql . " FROM $tabletemp WHERE id = $post_id";
                }
                if ($table == 2) { // manuscripts
                    $sql = "INSERT INTO " . $tableofficial . "(link_id, link_title, author, author_type, original, copy, title, title_type, signature, source_local, source_local_type, recipient, recipient_type, destination, destination_type, treatment, postscript, data, data_type, idiom, gender, species, type, items, description, contents, autograph, autograph_color, typewritten, typewritten_color, medium, watermark, pages, leafs, width, height, anex, envelope, stamp, imprint, post, post_type, receipt, receipt_type, carrier, in_hands, notes_recipient, notes_third, conservation, address, collection, ref, onomastic, pseudonyms, mentioned_works, periodics, historic, acquisition, acq_date, add_info, comments, creator, creator_id, created_at, updated_at, pageviews, published) SELECT $post_id, link_title, author, author_type, original, copy, title, title_type, signature, source_local, source_local_type, recipient, recipient_type, destination, destination_type, treatment, postscript, data, data_type, idiom, gender, species, type, items, description, contents, autograph, autograph_color, typewritten, typewritten_color, medium, watermark, pages, leafs, width, height, anex, envelope, stamp, imprint, post, post_type, receipt, receipt_type, carrier, in_hands, notes_recipient, notes_third, conservation, address, collection, ref, onomastic, pseudonyms, mentioned_works, periodics, historic, acquisition, acq_date, add_info, comments, creator, creator_id, created_at, now(), pageviews, 1 FROM $tabletemp WHERE id = $post_id";
                }
                if (mysqli_query($conn, $sql)) $ok = 2;
                else echo "Error publishPost() 1<br>";
            }

            if ($ok == 2) {
                $sql = "DELETE FROM $tabletemp WHERE id = $post_id";
                if (mysqli_query($conn, $sql)) {
                    /////////////////////// $post_id until now was from TEMP table
                    $sql = "SELECT id FROM $tableofficial WHERE link_id = $post_id";
                    $result = mysqli_query($conn, $sql);
                    $io = mysqli_fetch_assoc($result);
                    $post_id = 0;
                    $post_id = $io['id'];
                    if ($post_id == 0) {
                        echo "Error publishPost() 2";
                    } else {
                        ////////////////////// $post_id is now the fresh new ID created in OFFICIAL table
                        $ok = 3;
                        $new_record = 1;
                    }
                }
            }
            
            if ($ok == 3) ; // everything gone fine
            else echo "Error publishPost() ref. " . $ok; // ends process
            
            echo "<br>ok1 (has to be = 3): " . $ok;

        } else { // update official table

            $sql = "UPDATE $tableofficial SET published=1 WHERE id=$post_id";
            if (mysqli_query($conn, $sql)) $ok = 3;
            
        }

        if ($ok == 3) {
            $sql = "SELECT email FROM 02_mesicon_users WHERE id = $creator_id";
            $result = mysqli_query($conn, $sql);
            $admin = mysqli_fetch_assoc($result);
            $emailfromcreator = $admin['email'];
            if ($tableofficial == "02_mesicon_books") $tablehere = "1";
            if ($tableofficial == "02_mesicon_manuscripts") $tablehere = "3";
            sendMail_postPublished($post_id, $emailfromcreator, $author, $tablehere);
            $_SESSION['message'] = "Publicado/Published 2";

        
        
            // update creator history
            // UPDATE Table SET Field=CONCAT(IFNULL(Field, ''), 'Your extra HTML') // original format to append in a field
            // $sql = "UPDATE 02_mesicon_users SET history = CONCAT(IFNULL(history, ''), ';cre " . mb_substr($title, 0, 3) . " " . date('Y-m-d H:i:s') . "') WHERE id=$creator_id"; // old format: append was at the end of field, changed to the below line, now appending in the begining of the field
            // mysql_query("UPDATE add_info set likes = CONCAT('".$ben."',add_info.likes) WHERE id ='".$id."'") // original format
            $sql = "UPDATE 02_mesicon_users SET history = CONCAT(';$str_historic " . $post_id . " " . date('Y-m-d H:i') . "',02_mesicon_users.history) WHERE id = $creator_id";
            // TODO: make it PDO, next 2 lines - advantages: it is more uptaded and anti-sql-injection
            // $Stm = $PDO->prepare("UPDATE add_info set likes = CONCAT(?,add_info.likes) WHERE id =?");
            // $Stm->execute([$ben,$id]);
            if (mysqli_query($conn, $sql)) $ok = 5;
            else echo "Error publishPost() 5";
            
            echo "<br>ok2 (has to be = 5): " . $ok;

            // read data to update index
            if ($table == 0 || $table == 1) $table = "02_mesicon_books";
            if ($table == 2 || $table == 3) $table = "02_mesicon_manuscripts";
            if (substr($table,11,1) == "b") { $sql1 = "SELECT id, title, author, ed_number, manuscript, creator FROM $table WHERE id = $post_id"; $ok = 6; }
            if (substr($table,11,1) == "m") { $sql1 = "SELECT id, title, author, creator FROM $table WHERE id = $post_id"; $ok = 7; }
            
            //echo "<br>sql1: " . $sql1;
            echo "<br>ok3 (has to be = 6 or 7): " . $ok;
            
            $result = mysqli_query($conn, $sql1);
            $io = mysqli_fetch_assoc($result);
            if ($io['title']) $title = $io['title'];
            else $title = "";
            if ($io['author']) $author = $io['author'];
            else $author = "";
            if ($io['ed_number']) $ed_number = $io['ed_number'];
            else $ed_number = "";
            if ($io['manuscript']) $manuscript = $io['manuscript'];
            else $manuscript = "";
            if ($io['creator']) $creator = $io['creator'];
            else $creator = "";
            $original_id = $io['id'];

            echo "<br>title: " . $title . "<br>";
            echo "author: " . $author . "<br>";
            echo "ed_number: " . $ed_number . "<br>";
            echo "manuscript: " . $manuscript . "<br>";
            echo "creator (mesicon poster): " . $creator . "<br>";
            echo "original_id: " . $original_id . "<br>";

            if (substr($table,11,1) == "b") $sql2 = "INSERT INTO 02_mesicon_latest (tabela, original_id, title, author, ed_number, manuscript, creator, created_at) VALUES (1, '$original_id', '$title', '$author', '$ed_number', '$manuscript', '$creator', now())";
            if (substr($table,11,1) == "m") $sql2 = "INSERT INTO 02_mesicon_latest (tabela, original_id, title, author, creator, created_at) VALUES (3, '$original_id', '$title', '$author', '$creator', now())";

            echo "sql2: " . $sql2;

            // update last publications table to show on index
            if (mysqli_query($conn, $sql2)) $ok = 8;
            else echo "Error publishPost() 8";

            echo "<br>ok4 (has to be = 8): " . $ok;
            
            if (($ok == 8) && ($new_record == 1)) {
                $sql = "UPDATE $tableofficial SET link_id = 0 WHERE id = $post_id";
                if (mysqli_query($conn, $sql)) {
                    $ok = 9;
                    echo "<br>ok5 (has to be = 9): " . $ok;
                }
                else echo "Error publishPost() 9";
            }
            
            // TODO: important: verify if there is ID equivalence, i.e., always in both table they have the same id
            
            //header("location: posts_adm.php?i=" . $_SESSION['user']['id'] . "#" . mt_rand(0000000000,9999999999));
            //exit(0);
        
        } else $_SESSION['message'] = "Error/Algo deu errado/Error 3";

        
        
        
    } else {
        echo "Not authorized/Você não está autorizado a efetuar esta tarefa.";
    }
    
} // admin autoriza post

function randomDate() {
    // function randomDate($sStartDate, $sEndDate, $sFormat = 'Y-m-d H:i:s') {
    // to make the revision work --> $updated_at = date('Y-m-d H:i:s'); <-- this works
    $sFormat = 'Y-m-d H:i:s';
    $fMin = strtotime("1970-12-08 00:00:00"); // the day Silvio D'Onofrio was born - lowest value for unix timestamps is 1970-01-01 00:00:01
    $fMax = strtotime("2019-07-29 04:00:00"); // the day Maria Marta Tamaso, Silvio's mother, passed away, lefting a big hole in the heart of her son - highest value for unix timestamps is 2038-01-19 03:14:07
    // Generate a random number from the start and end dates
    $fVal = mt_rand($fMin, $fMax);
    // Convert back to the specified date format
    return date($sFormat, $fVal);
}

function sendMail_postPublished($post_id, $emailfromcreator, $author, $table) {
    $emailsender = "apps@statos.com";
    $emailSubject = "(POST OK) MESICON";
    $msg = "Esta é uma mensagem automática, por favor não a responda\nThis is an automatic message, please do not respond to it.\n\n";
    $msg .= "----------\n";
    $msg .= "Sua postagem/Your post ('" . urlDecode($author) . "') foi aprovada/was approved:\n\n";
    $msg .= "https://statos.com/mesicon/post.php?id=$post_id&t=$table";
            $msg .= "\n----------\n\n";
            $msg .= "Manuscritos e Edições SIstema de CONtrole - MESICON\n";
            $msg .= "statos.com/mesicon\n\n";
            $msg .= "Se você considera esta mensagem um erro, delete-a sem problemas.\nIf you consider this message an error, please delete it.\n\n\n\n";
    $headers = "MIME-Version: 1.1\n";
    $headers .= "Content-type: text/plain; charset=UTF-8\n";
    $headers .= "X-Priority: 1\n"; // send with max priority
    $headers .= "From: " . $emailsender . "\n"; // sender
    $headers .= "Return-Path: " . $emailsender . "\n"; // return-path
    if(!mail($emailfromcreator, $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Postfix
        // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // Postfix
        mail($emailfromcreator, $emailSubject, $msg, $headers );
        // sent
    } else { } // error - TODO: error message
}

function unpublishPost($post_id, $table) {
    if ($_SESSION['user']['role'] == "Administrator") {
        global $conn;	
        // $sql = "UPDATE posts SET published=!published WHERE id=$post_id"; - below line seems better - ago. 2021
        if ($table == 0) $sql = "UPDATE 02_mesicon_books_temp SET published = 0 WHERE id = $post_id";
        if ($table == 1) $sql = "UPDATE 02_mesicon_books SET published = 0 WHERE id = $post_id";
        if ($table == 2) $sql = "UPDATE 02_mesicon_manuscripts_temp SET published = 0 WHERE id = $post_id";
        if ($table == 3) $sql = "UPDATE 02_mesicon_manuscripts SET published = 0 WHERE id = $post_id";
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "Despublicado/Unpublished 2";
            header("location: posts_adm.php?i=" . $_SESSION['user']['id'] . "#" . mt_rand(0000000000,9999999999));
            exit(0);
        }
    } else {
        echo "Not authorized/Você não está autorizado a efetuar esta tarefa.";
    }
} // admin unpublishes post

function updateBookFromReview($request_values) {
    global $conn;
    $id = $request_values['id'];
    $creator_id = $request_values['creator_id'];
    $title = $request_values['title'];
    $author = $request_values['author'];
    $org = $request_values['org'];
    $ed_number = $request_values['ed_number'];
    $tomos = $request_values['tomos'];
    $series = $request_values['series'];
    $num_series = $request_values['num_series'];
    $publisher = $request_values['publisher'];
    $city = $request_values['city'];
    $state = $request_values['state'];
    $country = $request_values['country'];
    $month = $request_values['month'];
    $year = $request_values['year'];
    $idiom = $request_values['idiom'];
    $more_idioms = $request_values['more_idioms'];
    $pages = $request_values['pages'];
    $isbn = $request_values['isbn'];
    $width = $request_values['width'];
    $height = $request_values['height'];
    $front_illustrator = $request_values['front_illustrator'];
    $inside_illustrator = $request_values['inside_illustrator'];
    $translator = $request_values['translator'];
    $preface = $request_values['preface'];
    $paperback = $request_values['paperback'];
    $digital = $request_values['digital'];
    $exlibris = $request_values['exlibris'];
    $manuscript = $request_values['manuscript'];
    $printed_dedication = $request_values['printed_dedication'];
    $first_ear = $request_values['first_ear'];
    $second_ear = $request_values['second_ear'];
    $back = $request_values['back'];
    $add_info = $request_values['add_info'];
    $updated_at = $request_values['updated_at'];
    if (empty($title)) { array_push($errors, "Título é obrigatório"); }
    if (empty($author)) { array_push($errors, "Autor é obrigatório"); } // TODO: if errors = 0 ?
    $sql = "UPDATE 02_mesicon_books_temp SET title='$title', author='$author', org='$org', ed_number='$ed_number', tomos='$tomos', series='$series', num_series='$num_series', publisher='$publisher', city='$city', state='$state', country='$country', month='$month', year='$year', idiom='$idiom', more_idioms='$more_idioms', pages='$pages', isbn='$isbn', width='$width', height='$height', front_illustrator='$front_illustrator', inside_illustrator='$inside_illustrator', translator='$translator', preface='$preface', paperback='$paperback', digital='$digital', exlibris='$exlibris', manuscript='$manuscript', printed_dedication='$printed_dedication', first_ear='$first_ear', second_ear='$second_ear', back='$back', add_info='$add_info', updated_at='$updated_at', published=3 WHERE id=$id";
    // attach topic to post on post_topic table
    if (mysqli_query($conn, $sql)) { 
        // TODO: do jeito que está atualmente, primeiro eu preciso autorizar a publicação de uma postagem 
        // feita pelo zéruela para depois poder editá-la
        // o ideal seria primeiro eu editar para depois aprovar, corrigir
        if ($_SESSION['user']['role'] == "Administrator") $_SESSION['message'] = "Ok! 2";
        else $_SESSION['message'] = "Ok! Aguarde revisão/Wait revision 2";
        //$sql = "UPDATE 02_mesicon_users SET history = CONCAT(IFNULL(history, ''), ';upd " . mb_substr($title, 0, 3) . " " . date('Y-m-d H:i:s') . "') WHERE id = $creator_id";
        $sql = "UPDATE 02_mesicon_users SET history = CONCAT(';ub " . $id . " " . date('Y-m-d H:i') . "',02_mesicon_users.history) WHERE id = $creator_id";
        if (mysqli_query($conn, $sql)) {

            $emailsender = "apps@statos.com";
            $emailSubject = "(MESICON) evaluate (POST $id POSTER $creator_id)";
            $msg = "https://statos.com/mesicon/posts_adm.php";
            $headers = "MIME-Version: 1.1\n";
            $headers .= "Content-type: text/plain; charset=UTF-8\n";
            $headers .= "X-Priority: 1\n"; // para enviar a mensagem em prioridade máxima
            $headers .= "From: " . $emailsender . "\n"; // remetente
            $headers .= "Return-Path: " . $emailsender . "\n"; // return-path
            if(!mail("opeltrezero@gmail.com", $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Se for Postfix
                // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // Se "não for Postfix"
                mail("opeltrezero@gmail.com", $emailSubject, $msg, $headers );
                // foi
            } else { } // erro - TODO: mensagem de erro aqui
            
            header('location: posts.php');
            exit(0);
        }
    }
}

function updateManuscriptFromReview($request_values) {
    global $conn;
    $id = $request_values['id'];
    $creator_id = $request_values['creator_id'];    
    $author = $request_values['author'];
    $author_type = $request_values['author_type'];
    $original = $request_values['original'];
    $copy = $request_values['copy'];
    $title = $request_values['title'];
    $title_type = $request_values['title_type'];
    $signature = $request_values['signature'];
    $source_local = $request_values['source_local'];
    $source_local_type = $request_values['source_local_type'];
    $recipient = $request_values['recipient'];
    $recipient_type = $request_values['recipient_type'];
    $destination = $request_values['destination'];
    $destination_type = $request_values['destination_type'];
    $treatment = $request_values['treatment'];
    $postscript = $request_values['postscript'];
    $data = $request_values['data'];
    $data_type = $request_values['data_type'];
    $idiom = $request_values['idiom'];
    $gender = $request_values['gender'];
    $species = $request_values['species'];
    $type = $request_values['type'];
    $items = $request_values['items'];
    $description = $request_values['description'];
    $contents = $request_values['contents'];
    $autograph = $request_values['autograph'];
    $autograph_color = $request_values['autograph_color'];
    $typewritten = $request_values['typewritten'];
    $typewritten_color = $request_values['typewritten_color'];
    $medium = $request_values['medium'];
    $watermark = $request_values['watermark'];
    $pages = $request_values['pages'];
    $leafs = $request_values['leafs'];
    $width = $request_values['width'];
    $height = $request_values['height'];
    $anex = $request_values['anex'];
    $envelope = $request_values['envelope'];
    $stamp = $request_values['stamp'];
    $imprint = $request_values['imprint'];
    $post = $request_values['post'];
    $post_type = $request_values['post_type'];
    $receipt = $request_values['receipt'];
    $receipt_type = $request_values['receipt_type'];
    $carrier = $request_values['carrier'];
    $in_hands = $request_values['in_hands'];
    $notes_recipient = $request_values['notes_recipient'];
    $notes_third = $request_values['notes_third'];
    $conservation = $request_values['conservation'];
    $address = $request_values['address'];
    $collection = $request_values['collection'];
    $ref = $request_values['ref'];
    $onomastic = $request_values['onomastic'];
    $pseudonyms = $request_values['pseudonyms'];
    $mentioned_works = $request_values['mentioned_works'];
    $periodics = $request_values['periodics'];
    $historic = $request_values['historic'];
    $acquisition = $request_values['acquisition'];
    $acq_date = $request_values['acq_date'];
    $add_info = $request_values['add_info'];
    $updated_at = $request_values['updated_at'];
    if (empty($author)) { array_push($errors, "Autor é obrigatório/Author is mandatory"); } // TODO: if errors = 0 ?
    $sql = "UPDATE 02_mesicon_manuscripts_temp SET author='$author', author_type='$author_type', original='$original', copy='$copy', title='$title', title_type='$title_type', signature='$signature', source_local='$source_local', source_local_type='$source_local_type', recipient='$recipient', recipient_type='$recipient_type', destination='$destination', destination_type='$destination_type', treatment='$treatment', postscript='$postscript', data='$data', data_type='$data_type', idiom='$idiom', gender='$gender', species='$species', type='$type', items='$items', description='$description', contents='$contents', autograph='$autograph', autograph_color='$autograph_color', typewritten='$typewritten', typewritten_color='$typewritten_color', medium='$medium', watermark='$watermark', pages='$pages', leafs='$leafs', width='$width', height='$height', anex='$anex', envelope='$envelope', stamp='$stamp', imprint='$imprint', post='$post', post_type='$post_type', receipt='$receipt', receipt_type='$receipt_type', carrier='$carrier', in_hands='$in_hands', notes_recipient='$notes_recipient', notes_third='$notes_third', conservation='$conservation', address='$address', collection='$collection', ref='$ref', onomastic='$onomastic', pseudonyms='$pseudonyms', mentioned_works='$mentioned_works', periodics='$periodics', historic='$historic', acquisition='$acquisition', acq_date='$acq_date', add_info='$add_info', updated_at='$updated_at', published=3 WHERE id=$id";
    echo $sql; // debug
    
    // attach topic to post on post_topic table
    if (mysqli_query($conn, $sql)) { 
        // TODO: the way it is today, firstly I need to approve the post done by anyone to only after be enabled to edit it
        // better would be first edit and later publish/correct
        if ($_SESSION['user']['role'] == "Administrator") $_SESSION['message'] = "Ok! 2";
        else $_SESSION['message'] = "Ok! Aguarde revisão/Wait revision 2";
        //$sql = "UPDATE 02_mesicon_users SET history = CONCAT(IFNULL(history, ''), ';upd " . mb_substr($title, 0, 3) . " " . date('Y-m-d H:i:s') . "') WHERE id = $creator_id";
        $sql = "UPDATE 02_mesicon_users SET history = CONCAT(';um " . $id . " " . date('Y-m-d H:i') . "',02_mesicon_users.history) WHERE id = $creator_id";
        echo "<br>entrou 1<br>" . $sql; // debug
        if (mysqli_query($conn, $sql)) {

            echo "<br>entrou 2"; // debug
            $emailsender = "apps@statos.com";
            $emailSubject = "(MESICON) evaluate (POST $id POSTER $creator_id)";
            $msg = "https://statos.com/mesicon/posts_adm.php";
            $headers = "MIME-Version: 1.1\n";
            $headers .= "Content-type: text/plain; charset=UTF-8\n";
            $headers .= "X-Priority: 1\n"; // send with max priority
            $headers .= "From: " . $emailsender . "\n"; // sender
            $headers .= "Return-Path: " . $emailsender . "\n"; // return-path
            if(!mail("opeltrezero@gmail.com", $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Postfix
                // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // not Postfix
                mail("opeltrezero@gmail.com", $emailSubject, $msg, $headers );
                // sent
            } else { } // error - TODO: error message
            
            echo "<br><br><center><font size=+2>Ok!</font><br><br><a href=posts.php><b>- CLICK HERE to finish -</b></a></center>"; // TODO: improve this lazy guy
            header('location: posts.php');
            exit(0);
        }
    } else echo "<br>Error updateManuscriptFromReview()";
}

function updateReviewingBook($request_values) {
    global $conn;
    $ok = 0;
    $id = $request_values['id'];
    $err = "";
    
    $sql = "INSERT INTO 02_mesicon_books_temp SELECT * FROM 02_mesicon_books WHERE id = $id";
    if (mysqli_query($conn, $sql)) $ok = 1;
    //else $err = "Err 1 updateReviewingBook)";
    
    // flag in official table that post is in update process, i. e., "published = 4"
    if ($ok == 1) {
        $sql = "UPDATE 02_mesicon_books SET published=4 WHERE id=$id";
        if (mysqli_query($conn, $sql)) $ok = 2;
        //else $err = $err . "Err 2 updateReviewingBook)";
    }
    
    $title = esc($request_values['title']);
    $author = esc($request_values['author']);
    // $org = isset($request_values['org']) ? 1 : 0; // it was this way when "org" was commanded by a checkbox
    $org = $request_values['org'];
    $ed_number = $request_values['ed_number'];
    $tomos = $request_values['tomos'];
    $series = esc($request_values['series']);
    $num_series = $request_values['num_series'];
    $publisher = esc($request_values['publisher']);
    $city = esc($request_values['city']);
    $state = esc($request_values['state']);
    $country = esc($request_values['country']);
    $month = $request_values['month'];
    $year = $request_values['year'];
    $idiom = esc($request_values['idiom']);
    $more_idioms = esc($request_values['more_idioms']);
    $pages = $request_values['pages'];
    $isbn = $request_values['isbn'];
    $width = $request_values['width'];
    $height = $request_values['height'];
    $front_illustrator = esc($request_values['front_illustrator']);
    $inside_illustrator = esc($request_values['inside_illustrator']);
    $translator = esc($request_values['translator']);
    $preface = esc($request_values['preface']);
    $paperback = $request_values['paperback'];
    $digital = $request_values['digital'];
    $exlibris = $request_values['exlibris'];
    $manuscript = $request_values['manuscript'];
    $printed_dedication = esc($request_values['printed_dedication']);
    $first_ear = esc($request_values['first_ear']);
    $second_ear = esc($request_values['second_ear']);
    $back = esc($request_values['back']);
    $add_info = esc($request_values['add_info']);
    $creator = $request_values['creator'];
    $creator_id = $request_values['creator_id'];
    $updated_at = $request_values['updated_at'];
    $published = 2;
    $sql = "UPDATE 02_mesicon_books_temp SET title='$title', author='$author', org='$org', ed_number='$ed_number', tomos='$tomos', series='$series', num_series='$num_series', publisher='$publisher', city='$city', state='$state', country='$country', month='$month', year='$year', idiom='$idiom', more_idioms='$more_idioms', pages='$pages', isbn='$isbn', width='$width', height='$height', front_illustrator='$front_illustrator', inside_illustrator='$inside_illustrator', translator='$translator', preface='$preface', paperback='$paperback', digital='$digital', exlibris='$exlibris', manuscript='$manuscript', printed_dedication='$printed_dedication', first_ear='$first_ear', second_ear='$second_ear', back='$back', add_info='$add_info', creator='$creator', creator_id='$creator_id', published='$published' WHERE updated_at='$updated_at'";
    // attach topic to post on post_topic table
    if (mysqli_query($conn, $sql)) {
        // TODO: sendmail ADM warning post waiting for revision
        // TODO: do it // $_SESSION['message'] = txt('confira') . " 1"; // 1 color yellow
        $_SESSION['message'] = "Confira/Review 1";
        header('location: review_book.php?c=' . $updated_at);
        exit(0);
    }

}

function updateReviewingManuscript($request_values) {
    global $conn;
    $ok = 0;
    $id = $request_values['id'];
    $err = "";
    
    $sql = "INSERT INTO 02_mesicon_manuscripts_temp SELECT * FROM 02_mesicon_manuscripts WHERE id = $id";
    if (mysqli_query($conn, $sql)) $ok = 1;
    else $err = "Err 1 updateReviewingManuscript)";
    
    // flag in official table that post is in evaluation mode, i. e., "published = 4"
    if ($ok == 1) {
        $sql = "UPDATE 02_mesicon_manuscripts SET published=4 WHERE id=$id";
        if (mysqli_query($conn, $sql)) $ok = 2;
        else $err = $err . "Err 2 updateReviewingManuscript)";
    }   
    
    $author = $request_values['author'];
    $author_type = $request_values['author_type'];
    $original = $request_values['original'];
    $copy = $request_values['copy'];
    $title = $request_values['title'];
    $title_type = $request_values['title_type'];
    $signature = $request_values['signature'];
    $source_local = $request_values['source_local'];
    $source_local_type = $request_values['source_local_type'];
    $recipient = $request_values['recipient'];
    $recipient_type = $request_values['recipient_type'];
    $destination = $request_values['destination'];
    $destination_type = $request_values['destination_type'];
    $treatment = $request_values['treatment'];
    $postscript = $request_values['postscript'];
    $data = $request_values['data'];
    $data_type = $request_values['data_type'];
    $idiom = $request_values['idiom'];
    $gender = $request_values['gender'];
    $species = $request_values['species'];
    $type = $request_values['type'];
    $items = $request_values['items'];
    $description = $request_values['description'];
    $contents = $request_values['contents'];
    $autograph = $request_values['autograph'];
    $autograph_color = $request_values['autograph_color'];
    $typewritten = $request_values['typewritten'];
    $typewritten_color = $request_values['typewritten_color'];
    $medium = $request_values['medium'];
    $watermark = $request_values['watermark'];
    $pages = $request_values['pages'];
    $leafs = $request_values['leafs'];
    $width = $request_values['width'];
    $height = $request_values['height'];
    $anex = $request_values['anex'];
    $envelope = $request_values['envelope'];
    $stamp = $request_values['stamp'];
    $imprint = $request_values['imprint'];
    $post = $request_values['post'];
    $post_type = $request_values['post_type'];
    $receipt = $request_values['receipt'];
    $receipt_type = $request_values['receipt_type'];
    $carrier = $request_values['carrier'];
    $in_hands = $request_values['in_hands'];
    $notes_recipient = $request_values['notes_recipient'];
    $notes_third = $request_values['notes_third'];
    $conservation = $request_values['conservation'];
    $address = $request_values['address'];
    $collection = $request_values['collection'];
    $ref = $request_values['ref'];
    $onomastic = $request_values['onomastic'];
    $pseudonyms = $request_values['pseudonyms'];
    $mentioned_works = $request_values['mentioned_works'];
    $periodics = $request_values['periodics'];
    $historic = $request_values['historic'];
    $acquisition = $request_values['acquisition'];
    $acq_date = $request_values['acq_date'];
    $add_info = esc($request_values['add_info']);
    $creator = $request_values['creator'];
    $creator_id = $request_values['creator_id'];
    $updated_at = $request_values['updated_at'];
    $published = 2;
    
    $sql = "UPDATE 02_mesicon_manuscripts_temp SET author='$author', author_type='$author_type', original='$original', copy='$copy', title='$title', title_type='$title_type', signature='$signature', source_local='$source_local', source_local_type='$source_local_type', recipient='$recipient', recipient_type='$recipient_type', destination='$destination', destination_type='$destination_type', treatment='$treatment', postscript='$postscript', data='$data', data_type='$data_type', idiom='$idiom', gender='$gender', species='$species', type='$type', items='$items', description='$description', contents='$contents', autograph='$autograph', autograph_color='$autograph_color', typewritten='$typewritten', typewritten_color='$typewritten_color', medium='$medium', watermark='$watermark', pages='$pages', leafs='$leafs', width='$width', height='$height', anex='$anex', envelope='$envelope', stamp='$stamp', imprint='$imprint', post='$post', post_type='$post_type', receipt='$receipt', receipt_type='$receipt_type', carrier='$carrier', in_hands='$in_hands', notes_recipient='$notes_recipient', notes_third='$notes_third', conservation='$conservation', address='$address', collection='$collection', ref='$ref', onomastic='$onomastic', pseudonyms='$pseudonyms', mentioned_works='$mentioned_works', periodics='$periodics', historic='$historic', acquisition='$acquisition', acq_date='$acq_date', add_info='$add_info', creator='$creator', creator_id='$creator_id', published='$published' WHERE updated_at='$updated_at'";
        //echo "sql: " . $sql;
        //echo "<br>Error: " . $err;
    
    // attach topic to post on post_topic table
    if (mysqli_query($conn, $sql)) {
        // TODO: sendmail to ADM to warn post waiting for revision
        // TODO: tentar fazer isso funfar pq ate agora não rolou // $_SESSION['message'] = txt('confira') . " 1"; // 1 color yellow
        $_SESSION['message'] = "Confira/Review 1";
        //header('location: review_manuscript.php?c=' . $updated_at);
        //exit(0);
    }

}

function updateUser($request_values) { // user.php - user updating own profile
	global $conn, $role, $status, $username, $id, $bio, $email;
    $errors = [];
	$id = $request_values['admin_id'];
	$username = esc($request_values['username']);
	$email = esc($request_values['email']);
	$bio = esc($request_values['bio']);
	//$password = esc($request_values['password']);
	//$passwordConfirmation = esc($request_values['passwordConfirmation']);
	//if (isset($request_values['role'])) {
		$role = $request_values['role'];
		$status = $request_values['status'];
	//}
    if (empty($username)) { array_push($errors, "Name can not be empty/Nome de usuário não pode ficar vazio"); }
	if (count($errors) == 0) {
		//$sql = "UPDATE 02_mesicon_users SET username='$username', email='$email', role='$role', password='$password' WHERE id=$id";
		$sql = "UPDATE 02_mesicon_users SET username='$username', email='$email', role='$role', status='$status', bio='$bio', updated_at=now() WHERE id=$id";
		mysqli_query($conn, $sql);
		$_SESSION['message'] = "Ok! 2"; // here only as a debug, confirmation msg is given by "updated=1", build in "user.php"
		if ($_SESSION['user']['role'] != "Administrator") $_SESSION['user']['username'] = $username;
        $sql = "UPDATE 02_mesicon_users SET history = CONCAT(';p " . date('Y-m-d H:i') . "',02_mesicon_users.history) WHERE id = $id"; // atualiza historico
        if (mysqli_query($conn, $sql)) {
            header('location: user.php?id=' . $id . '&v=p&updated=1');
            exit(0);
        }
	}
}

function userApproveComments($id) {
	global $conn;
    $sql = "SELECT id, status FROM 02_mesicon_comments_temp WHERE status=1 AND id=$id";
    if (mysqli_query($conn, $sql)) {
    
        $sql = "UPDATE 02_mesicon_comments_temp SET status=2 WHERE id=$id";
        //mysqli_query($conn, $sql);
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "Ok! Aguarde revisão/Wait revision 2";
            $emailsender = "apps@statos.com"; // send only to me
            $emailSubject = "(APROVAR COMMENT id $id) MESICON";
            $msg = "https://statos.com/mesicon/comments.php";
            $headers = "MIME-Version: 1.1\n";
            $headers .= "Content-type: text/plain; charset=UTF-8\n";
            $headers .= "X-Priority: 1\n"; // send with max priority
            $headers .= "From: " . $emailsender . "\n"; // sender
            $headers .= "Return-Path: " . $emailsender . "\n"; // return-path
            if(!mail("opeltrezero@gmail.com", $emailSubject, $msg, $headers ,"-r".$emailsender)){ // Postfix
                // $headers .= "Return-Path: " . $emailsender . $quebra_linha; // not Postfix
                mail("opeltrezero@gmail.com", $emailSubject, $msg, $headers );
                // sent
            } else { } // error - TODO: error message
            header('location: comments.php');
            exit(0);
        }

    } else {
        "Already evaluated/Este comentário já foi avaliado.";
    }
}

?>
















