<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');
?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Simple Search/Busca Simples</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<?php

// TODO: see if can resolve - removed because it was raising HADOUKEN with "back"
//if ($_POST['p'] != 1) { // runs only with password
    //echo "<h2><br>Not authorized.</h2>";
//} else {

echo "<br><h2><a href=index.php>&lt;&lt; " . txt('voltar') . "</a></h2><br>";

if ($_POST['busca']) { // runs only if called by "search" button, if returning after a "back" button, goes straight to home

    global $conn;
    $i = 0;

    while($i <= 1) {
        
        echo "<h2><br>";

        if ($i==0) { // books
            $sql = "SELECT id, title, author, created_at, creator, creator_id, city, publisher, year, ed_number FROM 02_mesicon_books"; 
            echo txt('livros');
        }
        
        if ($i==1) { // manuscripts
            $sql = "SELECT id, title, author, created_at, creator, creator_id, link_title, recipient FROM 02_mesicon_manuscripts"; 
            echo txt('manuscritos');
        }
        
        echo "</h2><br><br>";
        
        $sql = $sql . " WHERE author LIKE '%" . esc($_POST['busca']) . "%' ORDER BY ";
        if ($i==0) $sql = $sql . "title ASC";
        if ($i==1) $sql = $sql . "author ASC";
        $num_registros = 0;
        $result = mysqli_query($conn, $sql);
        if ($result === FALSE) {
            echo "Error at search.php";
            die(); // TODO: better error handling
        } else {
            $posts = array();
            while ($row = $result->fetch_assoc()) {
                $posts[] = $row;
                $num_registros++;
            }
        }

        if ($num_registros > 0) echo "<br><h2>" . txt('regscomautor') . " ~= '" . esc($_POST['busca']) . "'</a>";
        else echo "<h2>" . txt('regssemautor') . " ~= '" . esc($_POST['busca']) . "'";
        if ($i==0) echo " " . txt('em') . " " . txt('livros');
        if ($i==1) echo " " . txt('em') . " " . txt('manuscritos');

        echo "<br><br></h2><p align=left>";
        for ($contador = 0; $contador < $num_registros; $contador++) {
            
            echo "<img src='static/spacer.gif' width='5%' height='1px'>" . $contador+1 . ". <a href='";
            if ($i==0) echo "post.php?t=1";
            else echo "man.php?t=3";
            echo "&id=" . $posts[$contador]['id'] . "' target='_blank'>" . $posts[$contador]['author'] . ".";

            if ($i==0) echo " '" . $posts[$contador]['title'] . "'.";

            if ($i==0) {
                if ($posts[$contador]['ed_number'] != 0) echo " " . $posts[$contador]['ed_number'] . ". ed.";

                if ($posts[$contador]['city'] != 0) echo " " . $posts[$contador]['city'];

                if (($posts[$contador]['city'] != 0) && ($posts[$contador]['publisher'] != 0)) echo ":";
                else echo ".";

                if ($posts[$contador]['publisher'] != 0) echo " " . $posts[$contador]['publisher'];

                if (($posts[$contador]['publisher'] != 0) && ($posts[$contador]['year'] != 0)) echo ",";
                else echo ".";

                if ($posts[$contador]['year'] != 0) echo " " . $posts[$contador]['year'];
            }

            if ($i==1) {
                if ($posts[$contador]['recipient'] != 0) echo " " . $posts[$contador]['recipient'] . ".";
                if ($posts[$contador]['link_title'] != 0) echo " '" . $posts[$contador]['link_title'] . "'.";
            }

            echo " (" . txt('cadastradoem') . " " . $posts[$contador]['created_at'] . ", " . txt('por') . "</a> <a href='user.php?id=" . $posts[$contador]['creator_id'] . "&v=p'>" . $posts[$contador]['creator'] . ")</a><br><br>";

        }
        echo "</p>";
        
        $i++;
        
    }

    echo "<br><br><h2><a href=index.php>&lt;&lt; " . txt('voltar') . "</a></h2>";
    echo "<br><br><h4><a href='advanced_search.php'>" . txt('busca_avancada') . "</a><br><br></h4>";
    
} else {
    header('location: index.php');
    exit(0);
}

// }

?>

<?php include('incl_footer.php'); ?> <!-- closes div id="pagediv", body, html and adds JSs -->
