<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');
?>

<script>
window.addEventListener('load', 
  function() { 
    //alert('pg ended loading!');
    document.statosdotcomForm.title.focus();
  }, false);
function vai(el,m) {alert(m);el.focus();}
var _formConfirm_submitted = false; // help block multi post
function i(f) {
	if (f.title.value=="") {vai(f.title,"MESICON\n\Entre com um título.\n\nEnter title.");return false;}
	else if (f.author.value=="") {vai(f.author,"MESICON\n\nEntre com um autor.\n\nEnter author.");return false;}
	else if (_formConfirm_submitted == false ) { 
        //var objForm = document.getElementById("statosdotcomForm");
        var objBtn = document.getElementById('idBtnSend');
        objBtn.style = "color: #000000; background: #00ff00; cursor: not-allowed;";
        objBtn.textContent = 'Aguarde/Wait...';
        _formConfirm_submitted = true;
        return true;
    } else {
        alert('MESICON\n\nAguarde/Wait...');
        return false;
    }
}
function statosdotcom_Count(obj,max) { if ((max-10) < obj.value.length) { document.getElementById("l"+obj.name).innerHTML = '<span style="color: red;">'+(max-obj.value.length)+'</span>'; } else { document.getElementById("l"+obj.name).innerHTML = (max-obj.value.length); }}
</script>

<style>
.ct { position: absolute; }
</style>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON | Register Book/Cadastrar Livro</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<h1><?= txt('cadastrar') ?> <?= txt('livro') ?></h1>

<?php echo "<h3><a href=control_panel.php>&lt;&lt; " . txt('voltar') . " " . txt('paineldecontrole') . "</a></h3>"; ?>

<?php if (($_SESSION['user']['role'] == "Manager") || ($_SESSION['user']['role'] == "Administrator")) { ?>

<form name="statosdotcomForm" method="post" action="" onsubmit="return i(this);">
    
<h4>
<?php include('incl_errors.php') ?>

<input type="hidden" name="creator_id" value="<?php echo $_SESSION['user']['id']; ?>">
<input type="hidden" name="creator" value="<?php echo $_SESSION['user']['username']; ?>">

<br><?= txt('casohajainfo') ?>.<br><br>
				
<br><font color="red">*</font> <?= txt('titulo') ?>:<br>
<div id='ltitle' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="title" name="title" placeholder="<?= txt('titulo') ?>" maxlength="199">

<br><br><font color="red">*</font> <?= txt('autor') ?><sup><a href="javascript:alert('MESICON\n\nUse \';\' para separar nomes.\n\nUse \';\' to separate names.');">&nbsp;&#9432;&nbsp;</a></sup> (<?= txt('sobrenome') ?>, <?= txt('nome') ?>):<br>
<div id='lauthor' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="author" name="author" placeholder="<?= txt('autor') ?>" maxlength="199">

<br><br><?= txt('ehorganizador') ?>?<br>
<select name="org" id="org">
<option value="0"><?= txt('orged') ?>?</option>
<option value="1"><?= txt('expressamente') ?></option>
<option value="2"><?= txt('presumivelmente') ?></option>
</select>

<br><br><?= txt('numeroedicao') ?>:<br>
<select name="ed_number" id="ed_number">
    <option value=0><?= txt('numeroedicao') ?>?</option>
    <?php
    $contador = 0;
    while ($contador<99){
        $contador++;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
    }
    ?>
</select>

<br><br>Volumes:<br>
<select name="tomos" id="tomos">
<option value=0>Volumes?</option>
    <?php
    $contador = 0;
    while ($contador<9){
        $contador++;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
    }
    ?>
</select>

<br><br><?= txt('series') ?>:
<div id='lseries' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="series" name="series" placeholder="<?= txt('series') ?>" maxlength="99">

<br><br><?= txt('numseries') ?>:<br>
<select name="num_series" id="num_series">
<option value=0><?= txt('numseries') ?>?</option>
    <?php
    $contador = 0;
    while ($contador<99){
        $contador++;
        echo "<option value=" . $contador . ">" . $contador . "</option>";
    }
    ?>
</select>

<br><br><?= txt('editora') ?>:<br>
<div id='lpublisher' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="publisher" name="publisher" placeholder="<?= txt('editora') ?>" maxlength="99">

<br><br><?= txt('cidade') ?>:<br>
<div id='lcity' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="city" name="city" placeholder="<?= txt('cidade') ?>" maxlength="99">

<br><br><?= txt('estado') ?>:<br>
<!-- <label for="state">Estado:</label> -->
<select name="state" id="state">
    <option value="0"><?= txt('estado') ?>?</option>
    <option value="AC">Acre</option>
    <option value="AL">Alagoas</option>
    <option value="AP">Amapá</option>
    <option value="AM">Amazonas</option>
    <option value="BA">Bahia</option>
    <option value="CE">Ceará</option>
    <option value="DF">Distrito Federal</option>
    <option value="ES">Espirito Santo</option>
    <option value="GO">Goiás</option>
    <option value="MA">Maranhão</option>
    <option value="MS">Mato Grosso do Sul</option>
    <option value="MT">Mato Grosso</option>
    <option value="MG">Minas Gerais</option>
    <option value="PA">Pará</option>
    <option value="PB">Paraíba</option>
    <option value="PR">Paraná</option>
    <option value="PE">Pernambuco</option>
    <option value="PI">Piauí</option>
    <option value="RJ">Rio de Janeiro</option>
    <option value="RN">Rio Grande do Norte</option>
    <option value="RS">Rio Grande do Sul</option>
    <option value="RO">Rondônia</option>
    <option value="RR">Roraima</option>
    <option value="SC">Santa Catarina</option>
    <option value="SP">São Paulo</option>
    <option value="SE">Sergipe</option>
    <option value="TO">Tocantins</option>
</select>
				
<br><br><?= txt('paisdepublicacao') ?>:<br>
<!-- <label for="country">País:</label> -->
<select id="country" name="country">
<option value="0"><?= txt('paisdepublicacao') ?>?</option>
<option value="Brasil">Brasil</option>
<option value="Afganistan">Afghanistan</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="Angola">Angola</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia & Herzegovina">Bosnia &amp; Herzegovina</option>
<option value="Brasil">Brasil</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Cape Verde">Cape Verde</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Colombia">Colombia</option>
<option value="Congo">Congo</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Cote DIvoire">Cote DIvoire</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<option value="Denmark">Denmark</option>
<option value="East Timor">East Timor</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Estonia">Estonia</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="French Guiana">French Guiana</option>
<option value="Germany">Germany</option>
<option value="Great Britain">Great Britain</option>
<option value="Greece">Greece</option>
<option value="Grenada">Grenada</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Hawaii">Hawaii</option>
<option value="Honduras">Honduras</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="Indonesia">Indonesia</option>
<option value="India">India</option>
<option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
<option value="Ireland">Ireland</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Korea South">Korea South</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Libya">Libya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Macau">Macau</option>
<option value="Macedonia">Macedonia</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Martinique">Martinique</option>
<option value="Mexico">Mexico</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands (Holland)</option>
<option value="New Zealand">New Zealand</option>
<option value="Nigeria">Nigeria</option>
<option value="Norway">Norway</option>
<option value="Pakistan">Pakistan</option>
<option value="Panama">Panama</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Phillipines">Philippines</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Qatar">Qatar</option>
<option value="Republic of Montenegro">Republic of Montenegro</option>
<option value="Republic of Serbia">Republic of Serbia</option>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Sao Tome & Principe">Sao Tome & Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="South Africa">South Africa</option>
<option value="Spain">Spain</option>
<option value="Sudan">Sudan</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Taiwan">Taiwan</option>
<option value="Thailand">Thailand</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Uganda">Uganda</option>
<option value="United Kingdom">United Kingdom</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Erimates">United Arab Emirates</option>
<option value="United States of America">United States of America</option>
<option value="Uruguay">Uruguay</option>
<option value="Vatican City State">Vatican City State</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Zimbabwe">Zimbabwe</option>
</select>
            
<br><br><?= txt('anodepublicacao') ?>:<br>
<!-- <label for="year">Ano:</label> -->
<select name="year" id="year">
<option value="0"><?= txt('anodepublicacao') ?>?</option>
    <?php 
        $contador = date("Y") + 1;
        while ($contador>1882){
            $contador--;
            echo "<option value=" . $contador . ">" . $contador . "</option>";
        }
    ?>
</select>

<br><br><?= txt('mesdepublicacao') ?>:<br>
<!-- <label for="month">Mês:</label> -->
<select name="month" id="month">
    <option value="0"><?= txt('mesdepublicacao') ?>?</option>
    <option value="1">Janeiro</option>
    <option value="2">Fevereiro</option>
    <option value="3">Março</option>
    <option value="4">Abril</option>
    <option value="5">Maio</option>
    <option value="6">Junho</option>
    <option value="7">Julho</option>
    <option value="8">Agosto</option>
    <option value="9">Setembro</option>
    <option value="10">Outubro</option>
    <option value="11">Novembro</option>
    <option value="12">Dezembro</option>
</select>

<br><br><?= txt('edimpressaoudig') ?>?<br>
<!-- <label for="digital">Impresso ou digital?:</label> -->
<select name="digital" id="digital">
<option value="0"><?= txt('edimpressaoudig') ?>?</option>
<option value="1"><?= txt('impressa') ?></option>
<option value="2">Digital</option>
</select>

<br><br><?= txt('paginas') ?>:<br>
<div id='lpages' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,4);" type="tel" id="pages" name="pages" placeholder="<?= txt('paginas') ?>" maxlength="4" onChange="this.value=this.value.replace(/[^0-9]+/g, '');"> <!-- regex refuses everything but numbers - "eins, zwei, drei, vier, fünf, sechs, sieben, acht" (Kraftwerk) -->

<br><br>ISBN:<br>
<div id='lisbn' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,13);" type="tel" id="isbn" name="isbn" placeholder="ISBN" maxlength="13" onChange="this.value=this.value.replace(/[^0-9]+/g, '');">

<br><br><?= txt('largura') ?> (cm.):<br>
<div id='lwidth' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,2);" type="tel" id="width" name="width" placeholder="<?= txt('largura') ?>" maxlength="2" onChange="this.value=this.value.replace(/[^0-9]+/g, '');">

<br><br><?= txt('altura') ?> (cm.):<br>
<div id='lheight' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,2);" type="tel" id="height" name="height" placeholder="<?= txt('altura') ?>" maxlength="2" onChange="this.value=this.value.replace(/[^0-9]+/g, '');">

<br><br><?= txt('encadernacao') ?>?<br>
<!-- <label for="paperback">Capa Dura:</label> -->
<select name="paperback" id="paperback">
    <option value="0"><?= txt('encadernacao') ?>?</option>
    <option value="1"><?= txt('capadura') ?></option>
    <option value="2"><?= txt('brochura') ?></option>
</select>

<br><br><?= txt('haexlibris') ?>?<sup><a href="javascript:alert('MESICON\n\nLogomarca do proprietário do livro.\n\nKind of logo from the book\'s owner.');">&#9432;&nbsp;</a></sup><br>
<!-- <label for="exlibris">Apresenta ex-libris do proprietário?</label> -->
<select name="exlibris" id="exlibris">
    <option value="0"><?= txt('haexlibris') ?>?</option>
    <option value="1"><?= txt('sim') ?></option>
    <option value="2"><?= txt('nao') ?></option>
</select>
 
<br><br><?= txt('idioma') ?>:<br>
<!-- <label for="idiom">Idioma:</label> -->
<select id="idiom" name="idiom">
<option value="0"><?= txt('idioma') ?>?</option>
<option value="pt">Português</option>
<option value="af">Afrikaans</option>
<option value="sq">Albanian</option>
<option value="ar">Arabic</option>
<option value="hy">Armenian</option>
<option value="az">Azerbaijani</option>
<option value="eu">Basque</option>
<option value="be">Belarusian</option>
<option value="bs">Bosnian</option>
<option value="bg">Bulgarian</option>
<option value="ca">Catalan</option>
<option value="zh">Chinese</option>
<option value="hr">Croatian</option>
<option value="cs">Czech</option>
<option value="da">Danish</option>
<option value="nl">Dutch</option>
<option value="en">English</option>
<option value="eo">Esperanto</option>
<option value="et">Estonian</option>
<option value="fl">Filipino</option>
<option value="fi">Finnish</option>
<option value="fr">French</option>
<option value="de">German</option>
<option value="el">Greek</option>
<option value="gn">Guarani</option>
<option value="hn">Hawaiian</option>
<option value="he">Hebrew</option>
<option value="hi">Hindi</option>
<option value="hu">Hungarian</option>
<option value="is">Icelandic</option>
<option value="id">Indonesian</option>
<option value="ga">Irish</option>
<option value="it">Italian</option>
<option value="ja">Japanese</option>
<option value="kk">Kazakh</option>
<option value="ko">Korean</option>
<option value="la">Latin</option>
<option value="lv">Latvian</option>
<option value="lt">Lithuanian</option>
<option value="mk">Macedonian</option>
<option value="ms">Malay</option>
<option value="mt">Maltese</option>
<option value="mn">Mongolian</option>
<option value="ne">Nepali</option>
<option value="no">Norwegian</option>
<option value="fa">Persian</option>
<option value="pl">Polish</option>
<option value="pt">Português</option>
<option value="pa">Punjabi</option>
<option value="qu">Quechua</option>
<option value="ro">Romanian</option>
<option value="rm">Romansh</option>
<option value="ru">Russian</option>
<option value="gd">Scottish Gaelic</option>
<option value="sr">Serbian</option>
<option value="sk">Slovak</option>
<option value="sl">Slovenian</option>
<option value="es">Spanish</option>
<option value="su">Sundanese</option>
<option value="sw">Swahili</option>
<option value="sv">Swedish</option>
<option value="th">Thai</option>
<option value="tp">Tupi</option>
<option value="tr">Turkish</option>
<option value="uk">Ukrainian</option>
<option value="uz">Uzbek</option>
<option value="vi">Vietnamese</option>
<option value="cy">Welsh</option>
<option value="yi">Yiddish</option>
<option value="yo">Yoruba</option>
<option value="zu">Zulu</option>
</select>

<br><br><?= txt('tradutor') ?>:<br>
<div id='ltranslator' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="translator" name="translator" placeholder="<?= txt('tradutor') ?>" maxlength="99">

<br><br><?= txt('outroidioma') ?>?<br>
<div id='lmore_idioms' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,199);" type="text" id="more_idioms" name="more_idioms" placeholder="<?= txt('outroidioma') ?>" maxlength="199">

<br><br><?= txt('dedicatoriaimpressa') ?>?<br>
<div id='lprinted_dedication' class='ct'></div>
<textarea onkeyup="statosdotcom_Count(this,65535);" id="printed_dedication" name="printed_dedication" rows=9 placeholder="<?= txt('dedicatoriaimpressa') ?>" maxlength="65535"></textarea>

<br><br><?= txt('haprefaciador') ?>:<br>
<div id='lpreface' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="preface" name="preface" placeholder="<?= txt('haprefaciador') ?>" maxlength="99">

<br><br><?= txt('hamanuscrito') ?>?<br>
<!-- <label for="manuscript">Apresenta dedicatória manuscrita, anotações, marginália?</label> -->
<select name="manuscript" id="manuscript">
<option value="0"><?= txt('manuscritos') ?>?</option>
<option value="1"><?= txt('sim') ?></option>
<option value="2"><?= txt('nao') ?></option>
</select>

<!-- TODO: manuscript dedication - transcript here or go to the manuscript area - think how to do it -->

<br><br><?= txt('hailustracapa') ?>:<br>
<div id='lfront_illustrator' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="front_illustrator" name="front_illustrator" placeholder="<?= txt('hailustracapa') ?>" maxlength="99">

<br><br><?= txt('hailustrainterno') ?>:<br>
<div id='linside_illustrator' class='ct'></div>
<input onkeyup="statosdotcom_Count(this,99);" type="text" id="inside_illustrator" name="inside_illustrator" placeholder="<?= txt('hailustrainterno') ?>" maxlength="99">

<br><br><?= txt('haprimaaba') ?>?<br>
<div id='lfirst_ear' class='ct'></div>
<textarea onkeyup="statosdotcom_Count(this,65535);" name="first_ear" id="first_ear" rows=9 placeholder="<?= txt('haprimaaba') ?>" maxlength="65535"></textarea>

<br><br><?= txt('hasegundaaba') ?>?<br>
<div id='lsecond_ear' class='ct'></div>
<textarea onkeyup="statosdotcom_Count(this,65535);" name="second_ear" id="second_ear" rows=9 placeholder="<?= txt('hasegundaaba') ?>" maxlength="65535"></textarea>

<br><br><?= txt('haverso') ?>?<br>
<div id='lback' class='ct'></div>
<textarea onkeyup="statosdotcom_Count(this,65535);" name="back" id="back" rows=9 placeholder="<?= txt('haverso') ?>" maxlength="65535"></textarea>

<br><br><?= txt('notadapesquisa') ?>:<br>
<div id='ladd_info' class='ct'></div>
<textarea onkeyup="statosdotcom_Count(this,65535);" name="add_info" id="add_info" rows=20 placeholder="<?= txt('notapesqtxt') ?>." maxlength="65535"></textarea>

<input type="hidden" name="updated_at" value="<?= randomDate() ?>">

<br>

<button type="submit" class="btn" name="create_book" id="idBtnSend"><?= txt('revisar_M') ?></button>
</h4>
<br>
<br>
</form>

<?php
} else {
    header("location: index.php");
    exit(0);
}

include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>
