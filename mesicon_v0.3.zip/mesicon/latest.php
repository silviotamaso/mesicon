<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

$order = "created_at";
$asc_or_desc = "DESC";
$table = "0"; // here only the "latest"

$posts = getAllBAM($table, $order, $asc_or_desc);

$contador = 1;
$contabela = 0;

?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Latest updates/Últimas atualizações</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<h1>Latest Updates/Últimas Atualizações<br></h1><h3><a href="control_panel.php">&lt;&lt; Return/Volta Painel</a></h3>

<?php include('incl_messages.php') ?>

<?php if (empty($posts)): 
// this one only will be true if DB absolutelly empty - pay attention juvenile
else: ?>


<br><table border="1" cellspacing="0" cellpadding="0" bordercolor="#cccccc" align="center" width="100%">

<tr>
<td align="center"><font size="-1">#</font></td>
<td align="center"><font size="-1">title</font></td>
<td align="center"><font size="-1">author</font></td>
<td align="center"><font size="-1">del</font></td>
<tr>
 <!-- table top -->

    
    
<?php
foreach ($posts as $key => $post) :

    while ($contabela < count($post)) {

        if ($_SESSION['user']['role'] == "Administrator") :
        ?>
        <tr style="height: 50px;">

            <td><font size="-2"><?= $contador++ ?></font></td>
            
            <td><font size="-1">
                <?php
                // echo $post[$contabela]['title'];
                if (strlen($post[$contabela]['title']) > 13) {
                    echo substr($post[$contabela]['title'],0,13) . "...";
                    if ($post[$contabela]['ed_number'] != 0) echo "<sup>" . $post[$contabela]['ed_number'] . "<font size='-2'>ed</font></sup>";
                }
                else if (strlen($post[$contabela]['title']) < 2 || $post[$contabela]['title'] == "") echo "-";
                else echo $post[$contabela]['title'];
                ?>
            </font></td>
            
            <td><font size="-1">
                <?php
                if (strlen($post[$contabela]['author']) > 15) echo substr($post[$contabela]['author'],0,15) . "...";
                else echo $post[$contabela]['author'];
                ?>
            </font></td>

            <td align="center">
                <script> function vai(i) {return confirm('Excluir - ' + i + ' - ?');} </script>
                <a href="latest.php?delete_post=<?= $post[$contabela]['id'] ?>&t=6&go2=latest" onclick="return vai('<?= $post[$contabela]['title'] ?>');">del</a>
            </td> <!-- del -->

        </tr> <!-- main content -->
        <?php
        endif;
        $contabela++;
    
    }    
    
endforeach;
?>

    
</table> <!-- main table, it is where is the main content fo the page -->





<?php
    endif;
    if ($contador == 1) echo "<br><h3>There is no posts/Você ainda não postou.</h3>";
?> <!-- controls if displays the entire content or not depending on the posts, if there is no one, shows nothing, if there is one or more, shows all -->

<?php
include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>


