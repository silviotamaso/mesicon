<?php
include('config.php');
//include('incl_debug.php');
include('incl_header.php'); // open html and head, load css

//error_reporting(0); // turn of errors to debug-run, to see if variables got posted (only in browser)

//if ($_SERVER['REQUEST_METHOD']=='POST') { // only run if vars are posted

	$temp = $_GET['HelloHAL']; 
    // (above) value sent to the fields "temp", inside tables "users" and "passemailchange", required to make the final check before the update of email or password
	$p = $_GET['DoYouReadMe']; // password, without if page can't run

	if ($p === "statos") { // only runs if password is present


			$id = "";
			$username = "";
			$email_from = "";
			$pass_from = "";



		if ($conn === false) {
			echo "(changemail.php) ERROR: Could not connect (Falha de conexao)."; 
			die ("(changemail.php) ERROR: Could not connect (Erro de conexao): " . mysqli_connect_error());
		}

		//echo "Connect Successfully. Host info: " . mysqli_get_host_info($conn); // print detailed host info
		
		// find out who is asking for change
		$sql = "SELECT * FROM 02_mesicon_users WHERE temp=$temp LIMIT 1";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($result);

	if ($row) { // if user exists

			$id = trim($row['id']);
			$username = trim($row['username']);
			$email_from = trim($row['email']);
			$pass_from = trim($row['password']);

			//$sql = "INSERT INTO 02_mesicon_passemailchange (iduser, temp, username, email_from, email_to, pass_from, pass_to, created_at) 
						//VALUES ('$id', '$temp', '$username', '$email_from', '$email_to', '$pass_from', '$pass_to', now())";
			
			//if (mysqli_query($conn, $sql)) {

			//echo "OK!<br><br>";

			// show form with data to enable the changing by the user and later posts
			?>


<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Change Email or Pass/Alterar Email ou Senha</title>

<script src="static/sha3-min.js"></script>

</head> <!-- opening of html and head is in "incl_head_section.php" -->
<body>
<?php include('incl_navbar.php'); ?>
<div id="pagediv">


	<div style="width: 70%; margin: 20px auto; align: center;">
		
		<?php
		?>
		<center>
		<h1>Use the form to change your email and-or password/Use o formulário abaixo para alterar seu email e/ou sua senha.<br><br></h1>
		<form name="statosdotcomForm" method="post" action="changemailpass_do.php">
		<center><h2>
		<input name="p" value="statos" type="hidden">
		<input name="temp" value="<?= $temp ?>" type="hidden">
		<input name="id" value="<?= $id ?>" type="hidden">
		<input name="username" value="<?= $username ?>" type="hidden">
		Email antigo:<br><?= $email_from ?><input name="email_from" value="<?= $email_from ?>" type="hidden"><br><br>
		Novo email: <input name="email_to" placeholder="(max. 99 caract.)" type="text" maxlength="99"><br>
		Senha antiga:<br>********<br><br>
		Nova senha: <input name="pass_to" placeholder="(max. 8 caract.)" type="text" maxlength="8">
		<input name="pass_to_sha3" type="hidden"><input name="oquemuda" type="hidden"><br>
		<center>
		<button type="button" name="statosButton" class="btn" onclick="javascript: i(document.statosdotcomForm);">UPDATE/ATUALIZAR</button>
		<!-- TODO: ver o que esse botão escondido está fazendo aqui e impedir dupla submissão -->
        <button type="button" name="statosRefresh" class="btn" onclick="javascript: location.reload();" style="display: none;">RELOAD PAGE/RECARREGAR PÁGINA</button>
		</center><br>
		</h2></center></form></center>

			<script>
			<!--
			var int_oquemuda = 0;

			window.addEventListener('load', 
			  function() { 
				//alert('pg ended loading!');
				document.statosdotcomForm.email_to.focus();
			  }, false);

			function vai(el,m) {alert(m);el.focus();}

			function i(f)
			{
				if ((f.email_to.value=="") && (f.pass_to.value=="")) {
					vai(f.email_to,"MESICON\n\nDo not change anything?/Não quer mudar nem seu email nem sua senha?"); int_oquemuda = 0;
				}
				
				if (f.email_to.value=="") {
					// ok, deixa vazio
				} else {
					// user quer mudar email; verifica abaixo se email segue padrão
					if (f.email_to.value.indexOf("@")==-1 || f.email_to.value.indexOf(".")==-1 || f.email_to.value.indexOf(" ")==1 || f.email_to.value.indexOf("/")==1 || f.email_to.value.indexOf("@.")==1 || f.email_to.value.indexOf(".@")==1) {
						vai(f.email_to,"MESICON\n\nInvalid email/Email inválido.");
					} else { // sinaliza mudança de email
						int_oquemuda = 1;
					}
				}
				
				if (f.pass_to.value=="") {
					// ok, deixa vazia
				} else {
					// user quer mudar senha
					if (isBlank(f.pass_to.value.trim())) { // verifica se não tem caracteres nulos
						vai(f.pass_to,"MESICON\n\nPassword must be 1 to 8 chars in lenght/A senha deve ter entre 1 e 8 caracteres.");
					} else { // sinaliza mudança de senha
						int_oquemuda = int_oquemuda + 2;
					}
				}

				if (int_oquemuda > 0) { // something is going to change, so enter here
					if (int_oquemuda > 1) f.pass_to_sha3.value = sha3_224(f.pass_to.value); // changed password, so do this to me baby
					//alert(int_oquemuda);
					f.oquemuda.value = int_oquemuda; // if only email changes, val = 1; if only pass, val = 2; if both, 3
					f.statosButton.style.opacity = 0.35;
					f.statosButton.disabled = true;
					f.statosButton.textContent = "Aguarde/Wait...";
					f.statosRefresh.style.display = "block";
					f.submit();
				}

			}
			
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			/*
			 * Will return:
			 * False for: for all strings with chars
			 * True for: false, null, undefined, 0, 0.0, "", " ".
			 *
			 * @param str
			 * @returns {boolean}
			 */
			function isBlank(str){
				return (!!!str || /^\s*$/.test(str));
			}

			/*
			// tests
			console.log("isBlank TRUE variants:");
			console.log(isBlank(false));
			console.log(isBlank(undefined));
			console.log(isBlank(null));
			console.log(isBlank(0));
			console.log(isBlank(0.0));
			console.log(isBlank(""));
			console.log(isBlank(" "));

			console.log("isBlank FALSE variants:");
			console.log(isBlank("0"));
			console.log(isBlank("0.0"));
			console.log(isBlank(" 0"));
			console.log(isBlank("0 "));
			console.log(isBlank("Test string"));
			console.log(isBlank("true"));
			console.log(isBlank("false"));
			console.log(isBlank("null"));
			console.log(isBlank("undefined"));			
			*/			
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			
			//-->
			</script>
	</div>


		<?php

		} else {
			echo "<h1><center>MESICON<br><br>ERROR - details following/ERRO: dados não inseridos. Detalhes:</center></h1><br><br>" . mysqli_error($conn);
		}
		
	} else {
		echo "403: forbidden"; // closes if password not present
	}

?>

<?php
include('incl_footer.php');
?>



