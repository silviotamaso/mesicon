<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<?php

$logado = 0;

//error_reporting(0);
if ($_SESSION['user']['username'] != "") $logado = 1;
if ($_SESSION['user']['lang'] == "") $_SESSION['user']['lang'] = "pt";
//error_reporting(1);

global $lang;
$lang = $_SESSION['user']['lang'];

$tit = mt_rand(1,50); // rand from 1 to 50 both inclusive
if ($tit < 10) $tit = "0" . $tit;
?>

</head> <!-- aberto em incl_header.php -->

<body> <!-- will be closed only in incl_footer -->

<div class="barradenavegacao">
<div class="logotop"><a href="index.php"><h1><?php include('static/tit/' . $tit . '.php'); ?></h1></a>
		<?php
        // style='max-width:2vw; max-height:5vh;' - ex atributes from flag - TODO later - variable size
        //echo "<a href='index.php?change_lang'><img src='static/2lang" . $_SESSION['user']['lang'] . ".gif' height=9 border=0 alt=IDIOM></a> ";
		if ($logado == 1) {
            //echo $_SESSION['user']['role'] . " (" . $_SESSION['user']['status'] . ") " . $_SESSION['user']['username'];
            echo $_SESSION['user']['username'];
            // if ($_SESSION['user']['status'] == "Authorized") echo " (" . txt('autorizado') . ") ";
            echo " (";
            if ($_SESSION['user']['role'] == "Manager") echo txt('gerente');
            else echo txt('administrador');
            echo ")";
        }
		else echo txt('mesicon');
		?>
	</div>
	<nav><ul id="menuList">
		<?php
        // height of portable menu is controled in footer.php
        echo "<li><a href='index.php#" . mt_rand(0000000000,9999999999) . "'>" . txt('inicio_M') . "</a></li>";
        if ($logado == 1) {
			if ($_SESSION['user']['role'] != "Usuário") echo "<li><a href=control_panel.php>" . txt('painel_M') . "</a></li>";
			echo "<li><a href='index.php?change_lang'>" . txt('language_M') . "</a></li>";
			echo "<li><a href=logout.php?p=index>" . txt('sair_M') . "</a></li>";
		} else {
			echo "<li><a href='index.php?change_lang'>" . txt('language_M') . "</a></li>";
			echo "<li><a href=login.php>" . txt('entrar_M') . "</a></li>";
		}
		?>
	</ul></nav>
	<img src="static/menu.png" class="menu-icon" alt="MENU" onclick="togglemenu()">
</div>

<script>
var menuList = document.getElementById("menuList");
menuList.style.maxHeight = "0px";
</script>

<div id="pagediv"> <!-- will be closed only in incl_footer -->