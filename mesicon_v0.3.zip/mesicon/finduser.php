<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_functions.php');
?>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<html>
<head><title>MESICON - Personal URL</title></head>
<body>

<?php 

global $conn;
$str_user = htmlspecialchars($_GET["u"]); // get querystring named "u"
$sql = "SELECT * FROM 02_mesicon_users WHERE username='$str_user'";
if (mysqli_query($conn, $sql)) {
	$admin = mysqli_fetch_assoc(mysqli_query($conn, $sql));
	$str_user = $admin['id'];
	echo("<script>this.document.location = 'https://statos.com/mesicon/user.php?id=" . $str_user . "&v=p';</script>");
} else {
	$_SESSION['message'] = "Usuário não encontrado/User not found 3";
	echo("<script>this.document.location = 'https://statos.com/mesicon';</script>");
	exit();
}
?>

</body></html>