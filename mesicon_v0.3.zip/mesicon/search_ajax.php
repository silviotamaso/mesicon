<?php

//////////////////////////////////////////////////
// https://github.com/silviotamaso/mesicon
// Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio
//
// This file is part of MESICON.
//
// MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////

// initial source: https://www.cloudways.com/blog/live-search-php-mysql-ajax

//Including Database configuration file
include "config.php";

//Getting value of "search" variable from "script.js"
if (isset($_POST['search'])) {

//Search box value assigning to $Name variable
   $Name = $_POST['search'];

//Search query
   $Query = "SELECT DISTINCT author FROM 02_mesicon_books WHERE author LIKE '%$Name%' LIMIT 5";

//Query execution
   $ExecQuery = MySQLi_query($conn, $Query);

//Creating unordered list to display result
   echo '

<ul>

   ';

   //Fetching result from database
   while ($Result = MySQLi_fetch_array($ExecQuery)) {

       ?>

   <!-- Creating unordered list items

        Calling javascript function named as "fill" found in "script.js" file by passing fetched result as parameter -->

   <li onclick='fill("<?php echo $Result['author']; ?>")'>
       <a>
           <!-- Assigning searched result in "Search box" in "search.php" file -->
           <?php echo $Result['author']; ?>
       </a>
    </li>

   <!-- Below php code is just for closing parenthesis. Don't be confused -->

   <?php

}}

?>

</ul>