<?php
include('config.php'); // start session, open conn, set charset
//include('incl_debug.php'); // debug
include('incl_header.php'); // open html and head, load css
include('incl_functions.php');

if ($_GET['t'] == 3) {
    header('location: man.php?id=' . $_GET['id']);
    exit;
} // if post is a manuscript, send user to there

if ($_GET['id']) $posts = getBAM($_GET['id'], $_GET['t']); // t is the table to be read
$entrou = 0;
?>

<style>
.comments {
    width: 100%;
    font-size: 1.3em;
    margin: 1px;
    padding: 9px 9px;
    background-color: #dddddd;
    display: none;
    box-sizing: border-box;
    border-radius: 20px;
}
</style>

<!--
//////////////////////////////////////////////////
https://github.com/silviotamaso/mesicon
Copyright 2022, 2023 Silvio Cesar Tamaso D'Onofrio

This file is part of MESICON.

MESICON is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

MESICON is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with MESICON. If not, see <https://www.gnu.org/licenses/>.
//////////////////////////////////////////////////
-->

<title>MESICON - Post</title>

<?php include('incl_navbar.php'); ?> <!-- close head, open body and pagediv -->

<?php 
    foreach ($posts as $post):

    $entrou = 1;
    if (($post['creator_id'] == $_SESSION['user']['id']) || ($_SESSION['user']['role'] == "Administrator")) {
        if ($_GET['t'] == 1 || ($_SESSION['user']['role'] == "Administrator")) echo "<a href='edit_book.php?i=" . $post['id'] . "&t=" . $_GET['t'] . "'>EDIT</a>";
    }
    ?>

    <div class="copyright">
    <img src="static/copyright.gif" width="100%">
    <div class="copyright crdiv">

    <?php 

	//echo "<div class='post-wrapper'>";
	/*
    if (($_SESSION['user']['role'] == "Administrator") || ($_SESSION['user']['role'] == "Manager")) {
		echo "<h2>";
		if ($post['published'] == 0) echo "<font color=red>Não </font>";
		echo "Publicado<br></h2>";
	}
    */
        
    echo "<b>" . txt('titulo') . ":</b> <h2 class='title'>";
    if ($post['title'] != 0) echo $post['title'];
        else echo txt('semtitulo');
	echo "</h2><b>" . txt('autor') . ":</b> <h3>" . $post['author'] . "</h3><br>";
	if ($post['org'] == 1) echo txt('ehorganizador') . ".<br><br>";
	if ($post['ed_number'] != 0) echo "<b>" . txt('numeroedicao') . ":</b> " . $post['ed_number'] . "<br>";
	if ($post['tomos'] != 0) echo "<b>Volumes:</b> " . $post['tomos'] . "<br>";
	if (strlen($post['series']) > 2) echo "<b>" . txt('series') . ":</b> " . $post['series'] . "<br>";
	if ($post['num_series'] != 0) echo "<b>" . txt('numseries') . ":</b> " . $post['num_series'] . "<br>";
	if (strlen($post['publisher']) > 2) echo "<b>" . txt('editora') . ":</b> " . $post['publisher'] . "<br>";

    echo "<br>";
        
	if (strlen($post['city']) > 2) echo "<b>" . txt('cidade') . ":</b> " . $post['city'] . "<br>";
	if (strlen($post['state']) > 1) echo "<b>" . txt('estado') . ":</b> " . $post['state'] . "<br>";
	if ($post['country'] != 0) echo "<b>" . txt('paisdepublicacao') . ":</b> " . $post['country'] . "<br>";
	if ($post['month'] != 0) echo "<b>" . txt('mesdepublicacao') . ":</b> " . getMonth($post['month']) . "<br>";
	if (strlen($post['year']) > 1) echo "<b>" . txt('anodepublicacao') . ":</b> " . $post['year'] . "<br>";
	if ($post['digital'] != 0) {
		echo "<b>" . txt('edicao') . ":</b> ";
		if ($post['digital'] == 1) echo txt('impressa');
		if ($post['digital'] == 2) echo "digital";
		echo "<br>";
	}
	if ($post['pages'] != 0) echo "<b>" . txt('paginas') . ":</b> " . $post['pages'] . "<br>";
	if ($post['isbn'] != 0) echo "<b>ISBN:</b> " . $post['isbn'] . "<br>";
	if ($post['width'] != 0) echo "<b>" . txt('largura') . ":</b> " . $post['width'] . " cm<br>";
	if ($post['height'] != 0) echo "<b>" . txt('altura') . ":</b> " . $post['height'] . " cm<br>";
	if ($post['paperback'] != 0) {
		echo "<b>" . txt('encadernacao') . ":</b> ";
		if ($post['paperback'] == 1) echo txt('capadura');
		if ($post['paperback'] == 2) echo txt('brochura');
		echo "<br>";	
    }
	if ($post['exlibris'] != 0) {
		echo "<b>" . txt('haexlibris') . "?</b>";
        ?>
        <sup><a href="javascript:alert('MESICON\n\nLogomarca do proprietário do livro.\n\nKind of logo from the book\'s owner.');">&#9432;&nbsp;</a></sup>
        <?php
		if ($post['exlibris'] == 1) echo txt('nao');
		if ($post['exlibris'] == 2) echo txt('sim');
		echo "<br>";
	}
        
    echo "<br>";
        
    if (strlen($post['idiom']) > 1) {
        echo "<b>" . txt('idioma') . ":</b> ";
        if ($post['idiom'] == "af") echo "Afrikaans";
        if ($post['idiom'] == "sq") echo "Albanian";
        if ($post['idiom'] == "ar") echo "Arabic";
        if ($post['idiom'] == "hy") echo "Armenian";
        if ($post['idiom'] == "az") echo "Azerbaijani";
        if ($post['idiom'] == "eu") echo "Basque";
        if ($post['idiom'] == "be") echo "Belarusian";
        if ($post['idiom'] == "bs") echo "Bosnian";
        if ($post['idiom'] == "bg") echo "Bulgarian";
        if ($post['idiom'] == "ca") echo "Catalan";
        if ($post['idiom'] == "zh") echo "Chinese";
        if ($post['idiom'] == "hr") echo "Croatian";
        if ($post['idiom'] == "cs") echo "Czech";
        if ($post['idiom'] == "da") echo "Danish";
        if ($post['idiom'] == "nl") echo "Dutch";
        if ($post['idiom'] == "en") echo "English";
        if ($post['idiom'] == "eo") echo "Esperanto";
        if ($post['idiom'] == "et") echo "Estonian";
        if ($post['idiom'] == "fl") echo "Filipino";
        if ($post['idiom'] == "fi") echo "Finnish";
        if ($post['idiom'] == "fr") echo "French";
        if ($post['idiom'] == "de") echo "German";
        if ($post['idiom'] == "el") echo "Greek";
        if ($post['idiom'] == "gn") echo "Guarani";
        if ($post['idiom'] == "hn") echo "Hawaiian";
        if ($post['idiom'] == "he") echo "Hebrew";
        if ($post['idiom'] == "hi") echo "Hindi";
        if ($post['idiom'] == "hu") echo "Hungarian";
        if ($post['idiom'] == "is") echo "Icelandic";
        if ($post['idiom'] == "id") echo "Indonesian";
        if ($post['idiom'] == "ga") echo "Irish";
        if ($post['idiom'] == "it") echo "Italian";
        if ($post['idiom'] == "ja") echo "Japanese";
        if ($post['idiom'] == "kk") echo "Kazakh";
        if ($post['idiom'] == "ko") echo "Korean";
        if ($post['idiom'] == "la") echo "Latin";
        if ($post['idiom'] == "lv") echo "Latvian";
        if ($post['idiom'] == "lt") echo "Lithuanian";
        if ($post['idiom'] == "mk") echo "Macedonian";
        if ($post['idiom'] == "ms") echo "Malay";
        if ($post['idiom'] == "mt") echo "Maltese";
        if ($post['idiom'] == "mn") echo "Mongolian";
        if ($post['idiom'] == "ne") echo "Nepali";
        if ($post['idiom'] == "no") echo "Norwegian";
        if ($post['idiom'] == "fa") echo "Persian";
        if ($post['idiom'] == "pl") echo "Polish";
        if ($post['idiom'] == "pt") echo "Português";
        if ($post['idiom'] == "pa") echo "Punjabi";
        if ($post['idiom'] == "qu") echo "Quechua";
        if ($post['idiom'] == "ro") echo "Romanian";
        if ($post['idiom'] == "rm") echo "Romansh";
        if ($post['idiom'] == "ru") echo "Russian";
        if ($post['idiom'] == "gd") echo "Scottish Gaelic";
        if ($post['idiom'] == "sr") echo "Serbian";
        if ($post['idiom'] == "sk") echo "Slovak";
        if ($post['idiom'] == "sl") echo "Slovenian";
        if ($post['idiom'] == "es") echo "Spanish";
        if ($post['idiom'] == "su") echo "Sundanese";
        if ($post['idiom'] == "sw") echo "Swahili";
        if ($post['idiom'] == "sv") echo "Swedish";
        if ($post['idiom'] == "th") echo "Thai";
        if ($post['idiom'] == "tp") echo "Tupi";
        if ($post['idiom'] == "tr") echo "Turkish";
        if ($post['idiom'] == "uk") echo "Ukrainian";
        if ($post['idiom'] == "uz") echo "Uzbek";
        if ($post['idiom'] == "vi") echo "Vietnamese";
        if ($post['idiom'] == "cy") echo "Welsh";
        if ($post['idiom'] == "yi") echo "Yiddish";
        if ($post['idiom'] == "yo") echo "Yoruba";
        if ($post['idiom'] == "zu") echo "Zulu";
        echo "<br>"; 
    }
        
	if (strlen($post['translator']) > 2) echo "<b>" . txt('tradutor') . ":</b> " . $post['translator'] . "<br>";
	if (strlen($post['more_idioms']) > 2) echo "<b>" . txt('outroidioma') . ":</b> " . $post['more_idioms'] . "<br>";
        
    echo "<br>";
        
	if (strlen($post['printed_dedication']) > 2) echo "<b>" . txt('dedicatoriaimpressa') . ":</b> " . $post['printed_dedication'] . "<br><br>";
	if (strlen($post['preface']) > 2) echo "<b>" . txt('haprefaciador') . ":</b> " . $post['preface'] . "<br><br>";
	if ($post['manuscript'] != 0) {
        if ($post['manuscript'] == 2) {
            echo txt('naoman');
        } else {
            echo "<b>" . txt('manuscrito');
            if ($post['manuscript'] == 1) echo ": <a href='man.php?id=" . $post['link_id'] . "'>" . txt('acesse') . "</a></b>";
        }
        echo "<br><br>";	
    }

    if (strlen($post['front_illustrator']) > 2) echo "<b>" . txt('hailustracapa') . ":</b> " . $post['front_illustrator'] . "<br><br>";
	if (strlen($post['inside_illustrator']) > 2) echo "<b>" . txt('hailustrainterno') . ":</b> " . $post['inside_illustrator'] . "<br><br>";
        
	if (strlen($post['first_ear']) > 2) echo "<b>" . txt('haprimaaba') . ":</b> " . $post['first_ear'] . "<br><br>";
	if (strlen($post['second_ear']) > 2) echo "<b>" . txt('hasegundaaba') . ":</b> " . $post['second_ear'] . "<br><br>";
	if (strlen($post['back']) > 2) echo "<b>" . txt('haverso') . ":</b> " . $post['back'] . "<br><br>";
	if (strlen($post['add_info']) > 2) echo "<b>" . txt('notadapesquisa') . ":</b> " . $post['add_info'] . "<br><br>";
    //if ($post['add_info'] != 0) echo $post['add_info'];

	echo "<center>";
    echo "<font size='-1'>--------------------</font>";
	getUserBio($post['creator_id']);
	echo "<font size='-1'>--------------------<br>";
	echo "<font size='-2'><b>" . txt('cadastradoem') . ":</b> " . $post['created_at'] . "&nbsp;|&nbsp;<b>" . txt('atualizacao') . ":</b> ". $post['updated_at'] . "<br></font>";
	echo "<font size='-1'>--------------------<br></font>";
	
    if ((strlen($post['publisher']) > 2) && (strlen($post['city']) > 2) && (strlen($post['year']) > 1) && ($post['ed_number'] != 0)) {
        echo $post['author'] . ". <i>" . $post['title'] . "</i>. " . $post['ed_number'] . ". ed. ";
        if (strlen($post['translator']) > 2) echo " Tr. " . $post['translator'] . ". ";
        echo $post['city'] . ": " . $post['publisher'] . ", " . $post['year'] . ".";
        if (strlen($post['series']) > 2) echo " (" . $post['series'];
        if ($post['num_series'] != 0) echo ", " . $post['num_series'];
        if (strlen($post['series']) > 2) echo ").";
        echo "<br>--------------------<br>";
    }
    
    $myUrl = "https://statos.com" . $_SERVER['REQUEST_URI'];
    echo "<a href=" . $myUrl . ">" . $myUrl . "</a> <a href=# title=Share onclick=javascript:copyToClipboard('" . $myUrl . "');alert('MESICON_Copiado_Copied!');><img src='static/share2.gif' alt=Share height=9vh border=0></a><br>(<font size='-1'>" . date('F j, Y, g:i a') . "</font>)<br>";
    echo date('Y') . " &copy; MESICON<br>--------------------<br>";
        ?>
        <script>
        </script>
        <?
	echo "<b>" . txt('comentarios') . " ";

    if ($_SESSION['user']['role'] == "Administrator" || $_SESSION['user']['role'] == "Manager") {
        if ($post['published'] == 1) { // só permite inserir comentários se o post está publicado
            ?>
            (<a href="#" onclick="javascript:div_comments.style.display = 'block'; statosdotcomForm.txt.focus();" title="<?= txt('utilizeoscomments') ?>"><?= txt('adicionar') ?></a>):
            <div id='div_comments' class='comments' style='display:none'>
            <form name='statosdotcomForm' id='statosdotcomForm' method='post' action='do_comment.php' onsubmit='return valida(this);'>
            <?php
            echo $_SESSION['user']['username'] . ":";
            echo "<input type='hidden' name='username_commenter' value='" . $_SESSION['user']['username'] . "'>";
            echo "<input type='hidden' name='id_commenter' value='" . $_SESSION['user']['id'] . "'>";
            echo "<input type='hidden' name='creator_id' value='" . $post['creator_id'] . "'>";
            echo "<input type='hidden' name='id_post' value='" . $post['id'] . "'>";
            echo "<input type='hidden' name='tabela' value='1'>";
            echo "<textarea name='txt' rows='3' placeholder='" . txt('utilizeoscomments') . " (max. 255 chars.)' maxlength='255'></textarea>";
            ?>
            <table width="100%"><tr><td align="center"><input type="button" class="btn" onclick="javascript:div_comments.style.display = 'none';" value="<?= txt('cancelar_M') ?>"></td><td align="center"><button type="submit" class="btn" id="post-comment"><?= txt('enviar_M') ?></button></td></tr></table>
            </form></div>
        
            <script>
            var _formConfirm_submitted = false; // impede múltiplas postagens
            function vai(el,m) {alert(m);el.focus();}
            function valida(f) {
                if (f.txt.value.length < 16) { vai(f.txt,'MESICON\n\nNo mínimo 15 letras.\n\nAt least 15 chars.');return false; }
                else if ((f.txt.value=="") || (f.txt.value==" ")) {
                    vai(f.txt,"MESICON\n\nInserir comentário.\n\nInsert comment.");return false;
                } else {
                    var objForm = document.getElementById('statosdotcomForm');
                    var objBtn = document.getElementById('post-comment');
                    objBtn.style = 'color: #000000; background: #00ff00; cursor: not-allowed;';
                    objBtn.textContent = 'Aguarde/Wait...';
                    // document.getElementById('div_comments').innerHTML = ''; // limpa div
                    _formConfirm_submitted = true;
                    //alert('Comentário enviado/Comment sent 2');
                    return true;
                }
            }
            </script>        
        <?php
        }
        echo "<br><br>";
    } else {
        //$_SESSION['message'] = "Entre para comentar 1";
        echo "(<a href='login.php' title='" . txt('utilizeoscomments') . "'>" . txt('adicionar') . "</a>):<br><br>";
    }
        
    echo "</b><p align=left><font color='#666666'>" . $post['comments'] . "<br></font></p>";
    ?>
        
        
        
        
</center>
</div>
</div>

<?php 

endforeach;

if ($entrou == 0) echo "<br><h2>" . txt('livro_nao_cad') . "</h2><br><br><h3><a href='index.php'>&lt;&lt; " . txt('voltar') . "</a></h3>";

include('incl_footer.php'); // close div id="pagediv", body, html and add JSs
?>


